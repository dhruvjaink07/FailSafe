--
-- PostgreSQL database cluster dump
--

\restrict oXxJbFKkdboTIDzziiZG3Ykwpab4aCBkkKRjqj2XrCCBbOybVVEkvdAzwQgOhpU

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE failsafe;
ALTER ROLE failsafe WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:cX3VNR53U0wKsNqtMVLqew==$gsZ5jL8Pk13OF/cY+5IxKXwpxGnbQ7PcOr00unck0+w=:R1UvmGUBi1fhx3GnCddGC3YIvonQzuAwbqVx31WfTYk=';

--
-- User Configurations
--








\unrestrict oXxJbFKkdboTIDzziiZG3Ykwpab4aCBkkKRjqj2XrCCBbOybVVEkvdAzwQgOhpU

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict wXhYXxVRfup4JQKsuGrmyoddBAhHfsBcGthYHavK9UUevCFIuczxjq81O8pu5DX

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict wXhYXxVRfup4JQKsuGrmyoddBAhHfsBcGthYHavK9UUevCFIuczxjq81O8pu5DX

--
-- Database "failsafe" dump
--

--
-- PostgreSQL database dump
--

\restrict qBAC38PmS4AVdvOIF99gYgAsL6y9X6WVVk39HxZQJmcdbMKIQVv9m8OUqjHo7gN

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: failsafe; Type: DATABASE; Schema: -; Owner: failsafe
--

CREATE DATABASE failsafe WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE failsafe OWNER TO failsafe;

\unrestrict qBAC38PmS4AVdvOIF99gYgAsL6y9X6WVVk39HxZQJmcdbMKIQVv9m8OUqjHo7gN
\connect failsafe
\restrict qBAC38PmS4AVdvOIF99gYgAsL6y9X6WVVk39HxZQJmcdbMKIQVv9m8OUqjHo7gN

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: android_experiment_report; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.android_experiment_report (
    experiment_id uuid NOT NULL,
    target_package text,
    scenario text,
    report jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.android_experiment_report OWNER TO failsafe;

--
-- Name: android_experiment_summary; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.android_experiment_summary (
    experiment_id uuid NOT NULL,
    target_package text,
    scenario text,
    failure_type text,
    health_status text,
    severity text,
    crash_reason text,
    recovered boolean,
    auto_recovered boolean,
    stable_recovered boolean,
    manual_intervention_required boolean,
    running boolean,
    recovery_time_ms bigint,
    first_impact_at timestamp without time zone,
    recovered_at timestamp without time zone,
    crash_rate_percent double precision,
    uptime_percent double precision,
    anr_detected boolean,
    warning_signals integer,
    unexpected_restarts integer,
    validation_configured boolean,
    validation_passed boolean,
    validation_reasons jsonb,
    summary_result text,
    summary_reason text,
    summary_suggestion text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.android_experiment_summary OWNER TO failsafe;

--
-- Name: android_experiments; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.android_experiments (
    experiment_id uuid NOT NULL,
    fault_type text,
    state text,
    phase text,
    package_name text,
    activity text,
    apk_path text,
    targets jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.android_experiments OWNER TO failsafe;

--
-- Name: android_metrics_raw; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.android_metrics_raw (
    id bigint NOT NULL,
    experiment_id uuid NOT NULL,
    endpoint text,
    "timestamp" timestamp without time zone,
    app_state text,
    crash boolean,
    anr boolean,
    crash_reason text,
    memory_mb double precision,
    frame_drops integer,
    latency_ms bigint,
    status integer,
    intensity integer
);


ALTER TABLE public.android_metrics_raw OWNER TO failsafe;

--
-- Name: android_metrics_raw_id_seq; Type: SEQUENCE; Schema: public; Owner: failsafe
--

CREATE SEQUENCE public.android_metrics_raw_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.android_metrics_raw_id_seq OWNER TO failsafe;

--
-- Name: android_metrics_raw_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: failsafe
--

ALTER SEQUENCE public.android_metrics_raw_id_seq OWNED BY public.android_metrics_raw.id;


--
-- Name: android_status_metrics; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.android_status_metrics (
    experiment_id uuid NOT NULL,
    state text,
    phase text,
    health_status text,
    severity text,
    recovered boolean,
    recovery_time_ms bigint,
    validation_passed boolean,
    summary_result text,
    failsafe_score double precision,
    status_payload jsonb,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.android_status_metrics OWNER TO failsafe;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.api_keys (
    id uuid NOT NULL,
    key_hash text NOT NULL,
    environment text NOT NULL,
    role text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    owner_id uuid
);


ALTER TABLE public.api_keys OWNER TO failsafe;

--
-- Name: backend_experiments; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.backend_experiments (
    experiment_id uuid NOT NULL,
    fault_type text,
    state text,
    phase text,
    targets jsonb,
    observed_endpoints jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.backend_experiments OWNER TO failsafe;

--
-- Name: backend_metrics_raw; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.backend_metrics_raw (
    id bigint NOT NULL,
    experiment_id uuid NOT NULL,
    endpoint text,
    "timestamp" timestamp without time zone,
    latency_ms bigint,
    status integer,
    intensity integer,
    container_cpu double precision,
    container_memory double precision
);


ALTER TABLE public.backend_metrics_raw OWNER TO failsafe;

--
-- Name: backend_metrics_raw_id_seq; Type: SEQUENCE; Schema: public; Owner: failsafe
--

CREATE SEQUENCE public.backend_metrics_raw_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.backend_metrics_raw_id_seq OWNER TO failsafe;

--
-- Name: backend_metrics_raw_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: failsafe
--

ALTER SEQUENCE public.backend_metrics_raw_id_seq OWNED BY public.backend_metrics_raw.id;


--
-- Name: backend_status_metrics; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.backend_status_metrics (
    experiment_id uuid NOT NULL,
    state text,
    phase text,
    blast_radius double precision,
    cascade_depth integer,
    system_severity text,
    failsafe_score double precision,
    status_payload jsonb,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.backend_status_metrics OWNER TO failsafe;

--
-- Name: experiment_summary; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.experiment_summary (
    experiment_id uuid NOT NULL,
    blast_radius double precision,
    cascade_depth integer,
    system_severity text,
    total_requests integer
);


ALTER TABLE public.experiment_summary OWNER TO failsafe;

--
-- Name: experiments; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.experiments (
    id uuid NOT NULL,
    fault_type text,
    state text,
    phase text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    max_intensity integer,
    breaking_intensity integer,
    max_stable_intensity integer,
    baseline jsonb,
    dependency_graph jsonb,
    target_endpoint_map jsonb,
    api_key_id uuid
);


ALTER TABLE public.experiments OWNER TO failsafe;

--
-- Name: frontend_experiments; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.frontend_experiments (
    experiment_id uuid NOT NULL,
    fault_type text,
    state text,
    phase text,
    base_url text,
    metrics_endpoint text,
    target_urls jsonb,
    targets jsonb,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.frontend_experiments OWNER TO failsafe;

--
-- Name: frontend_metrics_raw; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.frontend_metrics_raw (
    id bigint NOT NULL,
    experiment_id uuid NOT NULL,
    phase text,
    page text,
    lcp double precision,
    cls double precision,
    inp double precision,
    long_tasks integer,
    errors integer,
    unhandled_rejections integer,
    api_calls jsonb,
    event_timestamp bigint,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.frontend_metrics_raw OWNER TO failsafe;

--
-- Name: frontend_metrics_raw_id_seq; Type: SEQUENCE; Schema: public; Owner: failsafe
--

CREATE SEQUENCE public.frontend_metrics_raw_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.frontend_metrics_raw_id_seq OWNER TO failsafe;

--
-- Name: frontend_metrics_raw_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: failsafe
--

ALTER SEQUENCE public.frontend_metrics_raw_id_seq OWNED BY public.frontend_metrics_raw.id;


--
-- Name: frontend_status_metrics; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.frontend_status_metrics (
    experiment_id uuid NOT NULL,
    state text,
    phase text,
    frontend_score double precision,
    frontend_status text,
    failsafe_score double precision,
    status_payload jsonb,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.frontend_status_metrics OWNER TO failsafe;

--
-- Name: metrics_aggregated; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.metrics_aggregated (
    id bigint NOT NULL,
    experiment_id uuid,
    endpoint text,
    requests_total integer,
    p50_ms double precision,
    p95_ms double precision,
    p99_ms double precision,
    avg_ms double precision,
    stddev_ms double precision,
    jitter_ms double precision,
    error_rate double precision,
    max_failure_streak integer,
    latency_ratio double precision,
    error_delta double precision,
    stability_score double precision,
    impact_order integer,
    degraded boolean,
    avg_cpu double precision,
    max_cpu double precision,
    avg_memory double precision,
    max_memory double precision
);


ALTER TABLE public.metrics_aggregated OWNER TO failsafe;

--
-- Name: metrics_aggregated_id_seq; Type: SEQUENCE; Schema: public; Owner: failsafe
--

CREATE SEQUENCE public.metrics_aggregated_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.metrics_aggregated_id_seq OWNER TO failsafe;

--
-- Name: metrics_aggregated_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: failsafe
--

ALTER SEQUENCE public.metrics_aggregated_id_seq OWNED BY public.metrics_aggregated.id;


--
-- Name: metrics_raw; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.metrics_raw (
    id bigint NOT NULL,
    experiment_id uuid,
    endpoint text,
    "timestamp" timestamp without time zone,
    latency_ms bigint,
    status integer,
    intensity integer,
    container_cpu double precision,
    container_memory double precision
);


ALTER TABLE public.metrics_raw OWNER TO failsafe;

--
-- Name: metrics_raw_id_seq; Type: SEQUENCE; Schema: public; Owner: failsafe
--

CREATE SEQUENCE public.metrics_raw_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.metrics_raw_id_seq OWNER TO failsafe;

--
-- Name: metrics_raw_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: failsafe
--

ALTER SEQUENCE public.metrics_raw_id_seq OWNED BY public.metrics_raw.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: failsafe
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email text NOT NULL,
    name text,
    password_hash text,
    role text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO failsafe;

--
-- Name: android_metrics_raw id; Type: DEFAULT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.android_metrics_raw ALTER COLUMN id SET DEFAULT nextval('public.android_metrics_raw_id_seq'::regclass);


--
-- Name: backend_metrics_raw id; Type: DEFAULT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.backend_metrics_raw ALTER COLUMN id SET DEFAULT nextval('public.backend_metrics_raw_id_seq'::regclass);


--
-- Name: frontend_metrics_raw id; Type: DEFAULT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.frontend_metrics_raw ALTER COLUMN id SET DEFAULT nextval('public.frontend_metrics_raw_id_seq'::regclass);


--
-- Name: metrics_aggregated id; Type: DEFAULT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.metrics_aggregated ALTER COLUMN id SET DEFAULT nextval('public.metrics_aggregated_id_seq'::regclass);


--
-- Name: metrics_raw id; Type: DEFAULT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.metrics_raw ALTER COLUMN id SET DEFAULT nextval('public.metrics_raw_id_seq'::regclass);


--
-- Data for Name: android_experiment_report; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.android_experiment_report (experiment_id, target_package, scenario, report, created_at, updated_at) FROM stdin;
6d2a49a5-05b8-43a1-a911-7e2f43595285	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "summary": {"reason": "App recovered only after external trigger (likely cause: kill_app)", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": false, "recovery_time_ms": 12111, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T11:45:59.969977+05:30"}, "fault_start": "2026-04-02T11:45:17.3342411+05:30", "first_impact": {"com.example.code": "2026-04-02T11:45:47.8579843+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 76, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": false, "reasons": ["app recovered but required external interaction"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 10156, "fault": "network_disable", "at_time": "2026-04-02T11:45:27.4908141+05:30"}, {"step": "inject_fault", "at_ms": 18125, "fault": "network_enable", "at_time": "2026-04-02T11:45:35.4594994+05:30"}, {"step": "inject_fault", "at_ms": 30158, "fault": "kill_app", "at_time": "2026-04-02T11:45:47.49282+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 30523, "at_time": "2026-04-02T11:45:47.8579843+05:30"}, {"step": "inject_fault", "at_ms": 40974, "fault": "foreground_app", "at_time": "2026-04-02T11:45:58.3086883+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 42635, "at_time": "2026-04-02T11:45:59.969977+05:30"}], "cascade_depth": 0, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T11:45:47.8579843+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T11:45:59.969977+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 0, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 06:16:03.325333	2026-04-02 06:16:03.325333
8588d07f-20b7-41a0-a665-7e23280a3b70	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: network_enable", "failure_type": "killed"}, "summary": {"reason": "App recovered only after external trigger (likely cause: network_enable)", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": false, "recovery_time_ms": 12031, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T11:45:59.5669281+05:30"}, "fault_start": "2026-04-02T11:45:19.0961074+05:30", "first_impact": {"com.example.code": "2026-04-02T11:45:47.535832+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 76, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": false, "reasons": ["app recovered but required external interaction"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 10129, "fault": "network_disable", "at_time": "2026-04-02T11:45:29.225289+05:30"}, {"step": "inject_fault", "at_ms": 18115, "fault": "network_enable", "at_time": "2026-04-02T11:45:37.2113335+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 28439, "at_time": "2026-04-02T11:45:47.535832+05:30"}, {"step": "inject_fault", "at_ms": 30456, "fault": "kill_app", "at_time": "2026-04-02T11:45:49.5527931+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 40470, "at_time": "2026-04-02T11:45:59.5669281+05:30"}, {"step": "inject_fault", "at_ms": 40562, "fault": "foreground_app", "at_time": "2026-04-02T11:45:59.6589782+05:30"}], "cascade_depth": 0, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T11:45:47.535832+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T11:45:59.5669281+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 0, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 06:16:04.668868	2026-04-02 06:16:04.668868
d3ea29aa-9624-48a1-a23a-56ef1bdece10	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "critical", "crash_reason": "Process became not_running during experiment", "failure_type": "killed"}, "summary": {"reason": "App recovered only after external trigger", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"status": "degraded", "thread": "", "running": true, "severity": "critical", "recovered": true, "crash_reason": "Process became not_running during experiment", "failure_type": "killed", "auto_recovered": false, "recovery_time_ms": 44166, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T11:58:14.6119614+05:30"}, "fault_start": "2026-04-02T11:57:31.9351534+05:30", "first_impact": {"com.example.code": "2026-04-02T11:57:30.4453255+05:30"}}, "stability": {"status": "degraded", "thread": "", "severity": "critical", "anr_detected": false, "crash_reason": "Process became not_running during experiment", "failure_type": "killed", "uptime_percent": 12, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": false, "reasons": ["app recovered but required external interaction"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"to": "not_running", "from": "running", "step": "state_transition", "at_ms": -1489, "at_time": "2026-04-02T11:57:30.4453255+05:30"}, {"step": "inject_fault", "at_ms": 10140, "fault": "network_disable", "at_time": "2026-04-02T11:57:42.0754363+05:30"}, {"step": "inject_fault", "at_ms": 18081, "fault": "network_enable", "at_time": "2026-04-02T11:57:50.0169872+05:30"}, {"step": "inject_fault", "at_ms": 30053, "fault": "kill_app", "at_time": "2026-04-02T11:58:01.9882435+05:30"}, {"step": "inject_fault", "at_ms": 40555, "fault": "foreground_app", "at_time": "2026-04-02T11:58:12.4904178+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 42676, "at_time": "2026-04-02T11:58:14.6119614+05:30"}], "cascade_depth": 0, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T11:57:30.4453255+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T11:58:14.6119614+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 0, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 06:28:17.504907	2026-04-02 06:28:17.504907
5ff7f176-044e-4c56-9b5e-1167c29960b7	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "critical", "crash_reason": "Process became not_running during experiment", "failure_type": "killed"}, "summary": {"reason": "App recovered only after external trigger", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": false, "recovery_time_ms": 42111, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T12:44:15.2899058+05:30"}, "fault_start": "2026-04-02T12:43:32.8084599+05:30", "first_impact": {"com.example.code": "2026-04-02T12:43:33.1785175+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 8, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": false, "reasons": ["app recovered but required external interaction"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 10149, "fault": "network_disable", "at_time": "2026-04-02T12:43:42.9580835+05:30"}, {"step": "inject_fault", "at_ms": 18079, "fault": "network_enable", "at_time": "2026-04-02T12:43:50.8882117+05:30"}, {"step": "inject_fault", "at_ms": 30053, "fault": "kill_app", "at_time": "2026-04-02T12:44:02.8624142+05:30"}, {"step": "inject_fault", "at_ms": 40867, "fault": "foreground_app", "at_time": "2026-04-02T12:44:13.6763676+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 42481, "at_time": "2026-04-02T12:44:15.2899058+05:30"}], "cascade_depth": 0, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T12:44:15.2899058+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 0, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 07:14:18.728338	2026-04-02 07:14:18.728338
11b6a21e-0cc9-4cb5-9851-1045be41967e	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "critical", "crash_reason": "Process became not_running during experiment", "failure_type": "killed"}, "summary": {"reason": "App recovered only after external trigger", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": false, "recovery_time_ms": 41992, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T12:56:29.3897975+05:30"}, "fault_start": "2026-04-02T12:55:47.0420809+05:30", "first_impact": {"com.example.code": "2026-04-02T12:55:47.3973052+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 8, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": false, "reasons": ["app recovered but required external interaction"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 10257, "fault": "network_disable", "at_time": "2026-04-02T12:55:57.299123+05:30"}, {"step": "inject_fault", "at_ms": 18073, "fault": "network_enable", "at_time": "2026-04-02T12:56:05.1152867+05:30"}, {"step": "inject_fault", "at_ms": 30062, "fault": "kill_app", "at_time": "2026-04-02T12:56:17.1047025+05:30"}, {"step": "inject_fault", "at_ms": 40901, "fault": "foreground_app", "at_time": "2026-04-02T12:56:27.9439568+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 42347, "at_time": "2026-04-02T12:56:29.3897975+05:30"}], "cascade_depth": 0, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T12:56:29.3897975+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 0, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 07:26:32.998687	2026-04-02 07:26:32.998687
aa44532c-f2fe-4a82-b979-a32d0b6c9b57	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "summary": {"reason": "App recovered only after external trigger (likely cause: kill_app)", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": false, "recovery_time_ms": 12052, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T12:58:17.3094049+05:30"}, "fault_start": "2026-04-02T12:57:34.5942805+05:30", "first_impact": {"com.example.code": "2026-04-02T12:58:05.2570998+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 76, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": false, "reasons": ["app recovered but required external interaction"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 10080, "fault": "network_disable", "at_time": "2026-04-02T12:57:44.6744484+05:30"}, {"step": "inject_fault", "at_ms": 18073, "fault": "network_enable", "at_time": "2026-04-02T12:57:52.6678054+05:30"}, {"step": "inject_fault", "at_ms": 30065, "fault": "kill_app", "at_time": "2026-04-02T12:58:04.659423+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 30662, "at_time": "2026-04-02T12:58:05.2570998+05:30"}, {"step": "inject_fault", "at_ms": 40575, "fault": "foreground_app", "at_time": "2026-04-02T12:58:15.1693568+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 42715, "at_time": "2026-04-02T12:58:17.3094049+05:30"}], "cascade_depth": 0, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T12:58:05.2570998+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T12:58:17.3094049+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 0, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 07:28:20.221735	2026-04-02 07:28:20.221735
6ee39151-d68f-4696-a44f-1c4b77ed7702	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "summary": {"reason": "App recovered only after external trigger (likely cause: kill_app)", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": false, "recovery_time_ms": 12028, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T13:03:31.2029258+05:30"}, "fault_start": "2026-04-02T13:02:48.6529005+05:30", "first_impact": {"com.example.code": "2026-04-02T13:03:19.1748455+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 76, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": false, "reasons": ["app recovered but required external interaction"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 10125, "fault": "network_disable", "at_time": "2026-04-02T13:02:58.7779195+05:30"}, {"step": "inject_fault", "at_ms": 18081, "fault": "network_enable", "at_time": "2026-04-02T13:03:06.7339097+05:30"}, {"step": "inject_fault", "at_ms": 30174, "fault": "kill_app", "at_time": "2026-04-02T13:03:18.8273339+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 30521, "at_time": "2026-04-02T13:03:19.1748455+05:30"}, {"step": "inject_fault", "at_ms": 41079, "fault": "foreground_app", "at_time": "2026-04-02T13:03:29.7328705+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 42550, "at_time": "2026-04-02T13:03:31.2029258+05:30"}], "cascade_depth": 0, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T13:03:19.1748455+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T13:03:31.2029258+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 0, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 07:33:34.747518	2026-04-02 07:33:34.747518
b0a86dd0-7712-4761-96a0-0b05b5fec1e8	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 76}, "summary": {"reason": "App recovered only after external trigger (likely cause: kill_app)", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": false, "recovery_time_ms": 12316, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T13:23:20.1169672+05:30"}, "fault_start": "2026-04-02T13:22:37.2839734+05:30", "first_impact": {"com.example.code": "2026-04-02T13:23:07.8007151+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 76, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": false, "reasons": ["app recovered but required external interaction"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 10130, "fault": "network_disable", "at_time": "2026-04-02T13:22:47.4148767+05:30"}, {"step": "inject_fault", "at_ms": 18074, "fault": "network_enable", "at_time": "2026-04-02T13:22:55.3586559+05:30"}, {"step": "inject_fault", "at_ms": 30296, "fault": "kill_app", "at_time": "2026-04-02T13:23:07.5804604+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 30516, "at_time": "2026-04-02T13:23:07.8007151+05:30"}, {"step": "inject_fault", "at_ms": 41197, "fault": "foreground_app", "at_time": "2026-04-02T13:23:18.481258+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 42832, "at_time": "2026-04-02T13:23:20.1169672+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T13:23:07.8007151+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T13:23:20.1169672+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 07:53:23.531529	2026-04-02 07:53:23.531529
1d04ef77-8623-49d0-a808-957f1b55d29b	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 76}, "summary": {"reason": "App recovered only after external trigger (likely cause: kill_app)", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": false, "recovery_time_ms": 12166, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T13:35:59.696494+05:30"}, "fault_start": "2026-04-02T13:35:17.1180606+05:30", "first_impact": {"com.example.code": "2026-04-02T13:35:47.5303181+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 76, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": false, "reasons": ["app recovered but required external interaction"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 10163, "fault": "network_disable", "at_time": "2026-04-02T13:35:27.2818497+05:30"}, {"step": "inject_fault", "at_ms": 18088, "fault": "network_enable", "at_time": "2026-04-02T13:35:35.2068631+05:30"}, {"step": "inject_fault", "at_ms": 30069, "fault": "kill_app", "at_time": "2026-04-02T13:35:47.1875105+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 30412, "at_time": "2026-04-02T13:35:47.5303181+05:30"}, {"step": "inject_fault", "at_ms": 41002, "fault": "foreground_app", "at_time": "2026-04-02T13:35:58.1205811+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 42578, "at_time": "2026-04-02T13:35:59.696494+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T13:35:47.5303181+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T13:35:59.696494+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 08:06:03.133263	2026-04-02 08:06:03.133263
83c88b42-1da4-4377-860c-b19318fadfbb	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 76.92307692307693}, "summary": {"reason": "App recovered only after external trigger (likely cause: kill_app)", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": false, "recovery_time_ms": 6195, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T13:43:24.8649026+05:30"}, "fault_start": "2026-04-02T13:43:06.021186+05:30", "first_impact": {"com.example.code": "2026-04-02T13:43:18.6697118+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 76.92307692307693, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": false, "reasons": ["app recovered but required external interaction"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 4083, "fault": "network_disable", "at_time": "2026-04-02T13:43:10.1049795+05:30"}, {"step": "inject_fault", "at_ms": 8078, "fault": "network_enable", "at_time": "2026-04-02T13:43:14.0993997+05:30"}, {"step": "inject_fault", "at_ms": 12076, "fault": "kill_app", "at_time": "2026-04-02T13:43:18.0974438+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 12648, "at_time": "2026-04-02T13:43:18.6697118+05:30"}, {"step": "inject_fault", "at_ms": 17011, "fault": "foreground_app", "at_time": "2026-04-02T13:43:23.0330122+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 18843, "at_time": "2026-04-02T13:43:24.8649026+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T13:43:18.6697118+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T13:43:24.8649026+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 08:13:28.0407	2026-04-02 08:13:28.0407
9939ad8f-d9d3-4919-8551-6d740f32b3b0	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: network_disable", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 93.75}, "summary": {"reason": "App recovered only after external trigger (likely cause: network_disable)", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": false, "recovery_time_ms": 2012, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T13:53:23.6611764+05:30"}, "fault_start": "2026-04-02T13:53:01.314426+05:30", "first_impact": {"com.example.code": "2026-04-02T13:53:11.4350717+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 93.75, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": false, "reasons": ["app recovered but required external interaction"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8095, "fault": "network_enable", "at_time": "2026-04-02T13:53:09.4103267+05:30"}, {"step": "inject_fault", "at_ms": 10120, "fault": "network_disable", "at_time": "2026-04-02T13:53:11.4350717+05:30"}, {"step": "inject_fault", "at_ms": 20065, "fault": "kill_app", "at_time": "2026-04-02T13:53:21.3796352+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 20334, "at_time": "2026-04-02T13:53:21.6488039+05:30"}, {"step": "inject_fault", "at_ms": 21524, "fault": "foreground_app", "at_time": "2026-04-02T13:53:22.8390313+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 22346, "at_time": "2026-04-02T13:53:23.6611764+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T13:53:21.6488039+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T13:53:23.6611764+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 08:23:27.853351	2026-04-02 08:23:27.853351
59c69cb1-734e-4fdd-8423-d4ead134e60d	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: network_disable", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 93.75}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 2137, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T14:00:18.8287782+05:30"}, "fault_start": "2026-04-02T13:59:56.2868955+05:30", "first_impact": {"com.example.code": "2026-04-02T14:00:06.3684965+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 93.75, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8077, "fault": "network_enable", "at_time": "2026-04-02T14:00:04.3647955+05:30"}, {"step": "inject_fault", "at_ms": 10081, "fault": "network_disable", "at_time": "2026-04-02T14:00:06.3684965+05:30"}, {"step": "inject_fault", "at_ms": 20053, "fault": "kill_app", "at_time": "2026-04-02T14:00:16.3407575+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 20404, "at_time": "2026-04-02T14:00:16.6910808+05:30"}, {"step": "inject_fault", "at_ms": 22389, "fault": "foreground_app", "at_time": "2026-04-02T14:00:18.6761581+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 22541, "at_time": "2026-04-02T14:00:18.8287782+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T14:00:16.6910808+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T14:00:18.8287782+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 08:30:23.691653	2026-04-02 08:30:23.691653
41431500-90b1-4726-9dd2-204adba26e21	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: network_disable", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 87.5}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 4140, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T14:02:22.0861776+05:30"}, "fault_start": "2026-04-02T14:01:57.5303593+05:30", "first_impact": {"com.example.code": "2026-04-02T14:02:07.6199151+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 87.5, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8072, "fault": "network_enable", "at_time": "2026-04-02T14:02:05.6025341+05:30"}, {"step": "inject_fault", "at_ms": 10089, "fault": "network_disable", "at_time": "2026-04-02T14:02:07.6199151+05:30"}, {"step": "inject_fault", "at_ms": 20065, "fault": "kill_app", "at_time": "2026-04-02T14:02:17.596272+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 20415, "at_time": "2026-04-02T14:02:17.9455704+05:30"}, {"step": "inject_fault", "at_ms": 22457, "fault": "foreground_app", "at_time": "2026-04-02T14:02:19.987703+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 24555, "at_time": "2026-04-02T14:02:22.0861776+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T14:02:17.9455704+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T14:02:22.0861776+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 08:32:25.006311	2026-04-02 08:32:25.006311
a92c1648-d98d-49ef-adb1-0a1d14940945	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 87.5}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 4045, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T14:03:29.5847835+05:30"}, "fault_start": "2026-04-02T14:03:05.1013107+05:30", "first_impact": {"com.example.code": "2026-04-02T14:03:25.5392091+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 87.5, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8079, "fault": "network_enable", "at_time": "2026-04-02T14:03:13.1805962+05:30"}, {"step": "inject_fault", "at_ms": 10072, "fault": "network_disable", "at_time": "2026-04-02T14:03:15.1741847+05:30"}, {"step": "inject_fault", "at_ms": 20058, "fault": "kill_app", "at_time": "2026-04-02T14:03:25.1598918+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 20437, "at_time": "2026-04-02T14:03:25.5392091+05:30"}, {"step": "inject_fault", "at_ms": 22354, "fault": "foreground_app", "at_time": "2026-04-02T14:03:27.4561554+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 24483, "at_time": "2026-04-02T14:03:29.5847835+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T14:03:25.5392091+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T14:03:29.5847835+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 08:33:32.469178	2026-04-02 08:33:32.469178
76db46e4-fcc7-4673-9478-1b1fe6ef564e	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: network_disable", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 87.5}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 4152, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T14:04:14.0251274+05:30"}, "fault_start": "2026-04-02T14:03:49.4546296+05:30", "first_impact": {"com.example.code": "2026-04-02T14:03:59.5326473+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 87.5, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8078, "fault": "network_enable", "at_time": "2026-04-02T14:03:57.5327996+05:30"}, {"step": "inject_fault", "at_ms": 10078, "fault": "network_disable", "at_time": "2026-04-02T14:03:59.5326473+05:30"}, {"step": "inject_fault", "at_ms": 20064, "fault": "kill_app", "at_time": "2026-04-02T14:04:09.5186861+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 20417, "at_time": "2026-04-02T14:04:09.8724869+05:30"}, {"step": "inject_fault", "at_ms": 22382, "fault": "foreground_app", "at_time": "2026-04-02T14:04:11.8374975+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 24570, "at_time": "2026-04-02T14:04:14.0251274+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T14:04:09.8724869+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T14:04:14.0251274+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 08:34:16.852414	2026-04-02 08:34:16.852414
01bcff04-4d56-4a10-af21-a73da9ba3c05	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: network_disable", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 93.75}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 1994, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T14:06:05.2870017+05:30"}, "fault_start": "2026-04-02T14:05:42.8043348+05:30", "first_impact": {"com.example.code": "2026-04-02T14:05:52.8797934+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 93.75, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8076, "fault": "network_enable", "at_time": "2026-04-02T14:05:50.8804842+05:30"}, {"step": "inject_fault", "at_ms": 10075, "fault": "network_disable", "at_time": "2026-04-02T14:05:52.8797934+05:30"}, {"step": "inject_fault", "at_ms": 20069, "fault": "kill_app", "at_time": "2026-04-02T14:06:02.8738123+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 20488, "at_time": "2026-04-02T14:06:03.2924395+05:30"}, {"step": "inject_fault", "at_ms": 22318, "fault": "foreground_app", "at_time": "2026-04-02T14:06:05.1231398+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 22482, "at_time": "2026-04-02T14:06:05.2870017+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T14:06:03.2924395+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T14:06:05.2870017+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 08:36:10.140192	2026-04-02 08:36:10.140192
187f0f05-ede8-4ee7-bad2-2c74f000454d	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: network_disable", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 87.5}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 4118, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T14:05:00.1919096+05:30"}, "fault_start": "2026-04-02T14:04:35.6489229+05:30", "first_impact": {"com.example.code": "2026-04-02T14:04:45.7209133+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 87.5, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8076, "fault": "network_enable", "at_time": "2026-04-02T14:04:43.7257196+05:30"}, {"step": "inject_fault", "at_ms": 10071, "fault": "network_disable", "at_time": "2026-04-02T14:04:45.7209133+05:30"}, {"step": "inject_fault", "at_ms": 20049, "fault": "kill_app", "at_time": "2026-04-02T14:04:55.6981715+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 20424, "at_time": "2026-04-02T14:04:56.0731883+05:30"}, {"step": "inject_fault", "at_ms": 22390, "fault": "foreground_app", "at_time": "2026-04-02T14:04:58.0394445+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 24542, "at_time": "2026-04-02T14:05:00.1919096+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T14:04:56.0731883+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T14:05:00.1919096+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 08:35:03.050977	2026-04-02 08:35:03.050977
ca6f73c0-961e-4d80-aa17-6dff1d0917aa	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: network_disable", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 93.33333333333333}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 1974, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-02T14:07:20.0287355+05:30"}, "fault_start": "2026-04-02T14:06:57.5120226+05:30", "first_impact": {"com.example.code": "2026-04-02T14:07:07.5802947+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 93.33333333333333, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8078, "fault": "network_enable", "at_time": "2026-04-02T14:07:05.5903303+05:30"}, {"step": "inject_fault", "at_ms": 10068, "fault": "network_disable", "at_time": "2026-04-02T14:07:07.5802947+05:30"}, {"step": "inject_fault", "at_ms": 20064, "fault": "kill_app", "at_time": "2026-04-02T14:07:17.5763883+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 20542, "at_time": "2026-04-02T14:07:18.0544406+05:30"}, {"step": "inject_fault", "at_ms": 20677, "fault": "foreground_app", "at_time": "2026-04-02T14:07:18.1892689+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 22516, "at_time": "2026-04-02T14:07:20.0287355+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-02T14:07:18.0544406+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-02T14:07:20.0287355+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-02 08:37:23.20125	2026-04-02 08:37:23.20125
503df375-a008-4806-ad52-52fb392d0f01	android	single_fault	{"health": {"status": "down", "thread": "", "severity": "critical", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "impact": {"cascade_depth": 2, "disruption_events": 1, "blast_radius_percent": 60, "app_availability_percent": 40}, "summary": {"reason": "App did not recover after process kill (likely cause: kill_app)", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"running": false, "recovered": false, "auto_recovered": false, "recovery_time_ms": -1, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "single_fault", "timeline": {"recovery": {}, "fault_start": "2026-04-05T00:15:14.1791816+05:30", "first_impact": {"com.example.code": "2026-04-05T00:15:14.8025087+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 40, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 0}, "validation": {"passed": false, "reasons": ["running state does not match expectation", "expected recovery but app did not recover", "process kill detected and app did not recover"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 217, "fault": "kill_app", "at_time": "2026-04-05T00:15:14.3970693+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 623, "at_time": "2026-04-05T00:15:14.8025087+05:30"}], "cascade_depth": 2, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-05T00:15:14.8025087+05:30", "to": "not_running", "from": "running"}], "blast_radius_percent": 60, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-04 18:45:19.419729	2026-04-04 18:45:19.419729
1f1a4471-c672-4982-ba8d-e8a8ed79817e	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 93.33333333333333}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 1974, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-05T01:18:35.4891949+05:30"}, "fault_start": "2026-04-05T01:18:13.0967965+05:30", "first_impact": {"com.example.code": "2026-04-05T01:18:33.5145866+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 93.33333333333333, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8128, "fault": "network_enable", "at_time": "2026-04-05T01:18:21.225405+05:30"}, {"step": "inject_fault", "at_ms": 10106, "fault": "network_disable", "at_time": "2026-04-05T01:18:23.2029186+05:30"}, {"step": "inject_fault", "at_ms": 20132, "fault": "kill_app", "at_time": "2026-04-05T01:18:33.2290103+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 20417, "at_time": "2026-04-05T01:18:33.5145866+05:30"}, {"step": "inject_fault", "at_ms": 21340, "fault": "foreground_app", "at_time": "2026-04-05T01:18:34.4375367+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 22392, "at_time": "2026-04-05T01:18:35.4891949+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-05T01:18:33.5145866+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-05T01:18:35.4891949+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-04 19:48:39.446542	2026-04-04 19:48:39.446542
f1a53060-f7f1-40f1-8078-c540eae49879	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 93.75}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 1982, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-06T14:48:14.3456616+05:30"}, "fault_start": "2026-04-06T14:47:51.9498689+05:30", "first_impact": {"com.example.code": "2026-04-06T14:48:12.3636134+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 93.75, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8111, "fault": "network_enable", "at_time": "2026-04-06T14:48:00.0616339+05:30"}, {"step": "inject_fault", "at_ms": 10112, "fault": "network_disable", "at_time": "2026-04-06T14:48:02.0627455+05:30"}, {"step": "inject_fault", "at_ms": 20136, "fault": "kill_app", "at_time": "2026-04-06T14:48:12.0861366+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 20413, "at_time": "2026-04-06T14:48:12.3636134+05:30"}, {"step": "inject_fault", "at_ms": 21933, "fault": "foreground_app", "at_time": "2026-04-06T14:48:13.8832371+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 22395, "at_time": "2026-04-06T14:48:14.3456616+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-06T14:48:12.3636134+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-06T14:48:14.3456616+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-06 09:18:18.898106	2026-04-06 09:18:18.898106
82236e9d-a2e1-4f14-96b2-299903b79d97	android	network_interruption_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process became not_running during experiment", "failure_type": "killed"}, "impact": {"cascade_depth": 2, "disruption_events": 1, "blast_radius_percent": 92.85714285714286, "app_availability_percent": 7.142857142857142}, "summary": {"reason": "App process was killed and later recovered", "result": "FAIL", "suggestion": "Improve warm-start rehydration to reduce restart impact"}, "frontend": null, "recovery": {"running": false, "recovered": true, "auto_recovered": true, "recovery_time_ms": 18068, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "network_interruption_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-14T10:14:52.2940272+05:30"}, "fault_start": "2026-04-14T10:14:33.7912818+05:30", "first_impact": {"com.example.code": "2026-04-14T10:14:34.2254745+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 7.142857142857142, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 0}, "validation": {"passed": false, "reasons": ["running state does not match expectation"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 434, "at_time": "2026-04-14T10:14:34.2254745+05:30"}, {"step": "inject_fault", "at_ms": 8465, "fault": "network_disable", "at_time": "2026-04-14T10:14:42.256397+05:30"}, {"step": "inject_fault", "at_ms": 18502, "fault": "network_enable", "at_time": "2026-04-14T10:14:52.2940272+05:30"}, {"step": "inject_fault", "at_ms": 40241, "fault": "network_flaky", "at_time": "2026-04-14T10:15:14.0328906+05:30"}, {"step": "inject_fault", "at_ms": 47106, "fault": "network_latency", "at_time": "2026-04-14T10:15:20.897411+05:30"}], "cascade_depth": 2, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-14T10:14:34.2254745+05:30", "to": "not_running", "from": "running"}], "blast_radius_percent": 92.85714285714286, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-14 04:45:25.918656	2026-04-14 04:45:25.918656
2a78671b-30e9-4353-916c-546f92a2236f	android	network_interruption_recovery	{"health": {"status": "healthy", "thread": "", "severity": "low", "crash_reason": "", "failure_type": "healthy"}, "impact": {"cascade_depth": 0, "disruption_events": 0, "blast_radius_percent": 0, "app_availability_percent": 100}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 9960, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "network_interruption_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-14T10:43:09.0167962+05:30"}, "fault_start": "2026-04-14T10:42:50.9344597+05:30", "first_impact": {"com.example.code": "2026-04-14T10:42:59.0558305+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 100, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 0}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8121, "fault": "network_disable", "at_time": "2026-04-14T10:42:59.0558305+05:30"}, {"step": "inject_fault", "at_ms": 18082, "fault": "network_enable", "at_time": "2026-04-14T10:43:09.0167962+05:30"}, {"step": "inject_fault", "at_ms": 40153, "fault": "network_flaky", "at_time": "2026-04-14T10:43:31.0876965+05:30"}, {"step": "inject_fault", "at_ms": 47074, "fault": "network_latency", "at_time": "2026-04-14T10:43:38.0088335+05:30"}], "cascade_depth": 0, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [], "blast_radius_percent": 0, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-14 05:13:43.017641	2026-04-14 05:13:43.017641
638f7e61-9cb6-4756-8bb4-57812cb1dfd7	android	process_kill_recovery	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 76.92307692307693}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 11657, "stable_recovered": true, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-14T12:13:28.3176038+05:30"}, "fault_start": "2026-04-14T12:12:55.5027119+05:30", "first_impact": {"com.example.code": "2026-04-14T12:13:16.6596432+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 76.92307692307693, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 20323, "fault": "kill_app", "at_time": "2026-04-14T12:13:15.8258833+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 21156, "at_time": "2026-04-14T12:13:16.6596432+05:30"}, {"step": "inject_fault", "at_ms": 31644, "fault": "foreground_app", "at_time": "2026-04-14T12:13:27.1467824+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 32814, "at_time": "2026-04-14T12:13:28.3176038+05:30"}, {"step": "inject_fault", "at_ms": 43252, "fault": "network_latency", "at_time": "2026-04-14T12:13:38.7551862+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-14T12:13:16.6596432+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-14T12:13:28.3176038+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-14 06:43:43.774049	2026-04-14 06:43:43.774049
\.


--
-- Data for Name: android_experiment_summary; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.android_experiment_summary (experiment_id, target_package, scenario, failure_type, health_status, severity, crash_reason, recovered, auto_recovered, stable_recovered, manual_intervention_required, running, recovery_time_ms, first_impact_at, recovered_at, crash_rate_percent, uptime_percent, anr_detected, warning_signals, unexpected_restarts, validation_configured, validation_passed, validation_reasons, summary_result, summary_reason, summary_suggestion, created_at, updated_at) FROM stdin;
6d2a49a5-05b8-43a1-a911-7e2f43595285	android	process_kill_recovery	killed	degraded	high	Process not running after fault: kill_app	t	f	f	t	t	12111	\N	\N	0	76	f	0	1	t	f	["app recovered but required external interaction"]	FAIL	App recovered only after external trigger (likely cause: kill_app)	Handle process death and restore app state on launch	2026-04-02 06:16:03.330871	2026-04-02 06:16:03.330871
8588d07f-20b7-41a0-a665-7e23280a3b70	android	process_kill_recovery	killed	degraded	high	Process not running after fault: network_enable	t	f	f	t	t	12031	\N	\N	0	76	f	0	1	t	f	["app recovered but required external interaction"]	FAIL	App recovered only after external trigger (likely cause: network_enable)	Handle process death and restore app state on launch	2026-04-02 06:16:04.670799	2026-04-02 06:16:04.670799
d3ea29aa-9624-48a1-a23a-56ef1bdece10	android	process_kill_recovery	killed	degraded	critical	Process became not_running during experiment	t	f	f	t	t	44166	\N	\N	0	12	f	0	1	t	f	["app recovered but required external interaction"]	FAIL	App recovered only after external trigger	Handle process death and restore app state on launch	2026-04-02 06:28:17.507168	2026-04-02 06:28:17.507168
5ff7f176-044e-4c56-9b5e-1167c29960b7	android	process_kill_recovery	killed	degraded	critical	Process became not_running during experiment	t	f	f	t	t	42111	\N	\N	0	8	f	0	1	t	f	["app recovered but required external interaction"]	FAIL	App recovered only after external trigger	Handle process death and restore app state on launch	2026-04-02 07:14:18.733502	2026-04-02 07:14:18.733502
11b6a21e-0cc9-4cb5-9851-1045be41967e	android	process_kill_recovery	killed	degraded	critical	Process became not_running during experiment	t	f	f	t	t	41992	\N	\N	0	8	f	0	1	t	f	["app recovered but required external interaction"]	FAIL	App recovered only after external trigger	Handle process death and restore app state on launch	2026-04-02 07:26:33.002289	2026-04-02 07:26:33.002289
aa44532c-f2fe-4a82-b979-a32d0b6c9b57	android	process_kill_recovery	killed	degraded	high	Process not running after fault: kill_app	t	f	f	t	t	12052	\N	\N	0	76	f	0	1	t	f	["app recovered but required external interaction"]	FAIL	App recovered only after external trigger (likely cause: kill_app)	Handle process death and restore app state on launch	2026-04-02 07:28:20.225541	2026-04-02 07:28:20.225541
6ee39151-d68f-4696-a44f-1c4b77ed7702	android	process_kill_recovery	killed	degraded	high	Process not running after fault: kill_app	t	f	f	t	t	12028	\N	\N	0	76	f	0	1	t	f	["app recovered but required external interaction"]	FAIL	App recovered only after external trigger (likely cause: kill_app)	Handle process death and restore app state on launch	2026-04-02 07:33:34.752289	2026-04-02 07:33:34.752289
b0a86dd0-7712-4761-96a0-0b05b5fec1e8	android	process_kill_recovery	killed	degraded	high	Process not running after fault: kill_app	t	f	f	t	t	12316	\N	\N	0	76	f	0	1	t	f	["app recovered but required external interaction"]	FAIL	App recovered only after external trigger (likely cause: kill_app)	Handle process death and restore app state on launch	2026-04-02 07:53:23.535768	2026-04-02 07:53:23.535768
1d04ef77-8623-49d0-a808-957f1b55d29b	android	process_kill_recovery	killed	degraded	high	Process not running after fault: kill_app	t	f	f	t	t	12166	\N	\N	0	76	f	0	1	t	f	["app recovered but required external interaction"]	FAIL	App recovered only after external trigger (likely cause: kill_app)	Handle process death and restore app state on launch	2026-04-02 08:06:03.136941	2026-04-02 08:06:03.136941
83c88b42-1da4-4377-860c-b19318fadfbb	android	process_kill_recovery	killed	degraded	high	Process not running after fault: kill_app	t	f	f	t	t	6195	\N	\N	0	76.92307692307693	f	0	1	t	f	["app recovered but required external interaction"]	FAIL	App recovered only after external trigger (likely cause: kill_app)	Handle process death and restore app state on launch	2026-04-02 08:13:28.043498	2026-04-02 08:13:28.043498
9939ad8f-d9d3-4919-8551-6d740f32b3b0	android	process_kill_recovery	killed	degraded	high	Process not running after fault: network_disable	t	f	f	t	t	2012	\N	\N	0	93.75	f	0	1	t	f	["app recovered but required external interaction"]	FAIL	App recovered only after external trigger (likely cause: network_disable)	Handle process death and restore app state on launch	2026-04-02 08:23:27.855712	2026-04-02 08:23:27.855712
59c69cb1-734e-4fdd-8423-d4ead134e60d	android	process_kill_recovery	killed	degraded	high	Process not running after fault: network_disable	t	t	f	f	t	2137	\N	\N	0	93.75	f	0	1	t	t	[]	PASS	Observed behavior matched configured expectations	Increase stress with network_flaky + kill_repeated to probe deeper resilience	2026-04-02 08:30:23.69738	2026-04-02 08:30:23.69738
41431500-90b1-4726-9dd2-204adba26e21	android	process_kill_recovery	killed	degraded	high	Process not running after fault: network_disable	t	t	f	f	t	4140	\N	\N	0	87.5	f	0	1	t	t	[]	PASS	Observed behavior matched configured expectations	Increase stress with network_flaky + kill_repeated to probe deeper resilience	2026-04-02 08:32:25.009045	2026-04-02 08:32:25.009045
a92c1648-d98d-49ef-adb1-0a1d14940945	android	process_kill_recovery	killed	degraded	high	Process not running after fault: kill_app	t	t	f	f	t	4045	\N	\N	0	87.5	f	0	1	t	t	[]	PASS	Observed behavior matched configured expectations	Increase stress with network_flaky + kill_repeated to probe deeper resilience	2026-04-02 08:33:32.471234	2026-04-02 08:33:32.471234
76db46e4-fcc7-4673-9478-1b1fe6ef564e	android	process_kill_recovery	killed	degraded	high	Process not running after fault: network_disable	t	t	f	f	t	4152	\N	\N	0	87.5	f	0	1	t	t	[]	PASS	Observed behavior matched configured expectations	Increase stress with network_flaky + kill_repeated to probe deeper resilience	2026-04-02 08:34:16.854323	2026-04-02 08:34:16.854323
187f0f05-ede8-4ee7-bad2-2c74f000454d	android	process_kill_recovery	killed	degraded	high	Process not running after fault: network_disable	t	t	f	f	t	4118	\N	\N	0	87.5	f	0	1	t	t	[]	PASS	Observed behavior matched configured expectations	Increase stress with network_flaky + kill_repeated to probe deeper resilience	2026-04-02 08:35:03.052981	2026-04-02 08:35:03.052981
01bcff04-4d56-4a10-af21-a73da9ba3c05	android	process_kill_recovery	killed	degraded	high	Process not running after fault: network_disable	t	t	f	f	t	1994	\N	\N	0	93.75	f	0	1	t	t	[]	PASS	Observed behavior matched configured expectations	Increase stress with network_flaky + kill_repeated to probe deeper resilience	2026-04-02 08:36:10.142747	2026-04-02 08:36:10.142747
ca6f73c0-961e-4d80-aa17-6dff1d0917aa	android	process_kill_recovery	killed	degraded	high	Process not running after fault: network_disable	t	t	f	f	t	1974	\N	\N	0	93.33333333333333	f	0	1	t	t	[]	PASS	Observed behavior matched configured expectations	Increase stress with network_flaky + kill_repeated to probe deeper resilience	2026-04-02 08:37:23.203661	2026-04-02 08:37:23.203661
503df375-a008-4806-ad52-52fb392d0f01	android	single_fault	killed	down	critical	Process not running after fault: kill_app	f	f	f	t	f	-1	\N	\N	0	40	f	0	0	t	f	["running state does not match expectation", "expected recovery but app did not recover", "process kill detected and app did not recover"]	FAIL	App did not recover after process kill (likely cause: kill_app)	Handle process death and restore app state on launch	2026-04-04 18:45:19.42433	2026-04-04 18:45:19.42433
1f1a4471-c672-4982-ba8d-e8a8ed79817e	android	process_kill_recovery	killed	degraded	high	Process not running after fault: kill_app	t	t	f	f	t	1974	\N	\N	0	93.33333333333333	f	0	1	t	t	[]	PASS	Observed behavior matched configured expectations	Increase stress with network_flaky + kill_repeated to probe deeper resilience	2026-04-04 19:48:39.449223	2026-04-04 19:48:39.449223
f1a53060-f7f1-40f1-8078-c540eae49879	android	process_kill_recovery	killed	degraded	high	Process not running after fault: kill_app	t	t	f	f	t	1982	\N	\N	0	93.75	f	0	1	t	t	[]	PASS	Observed behavior matched configured expectations	Increase stress with network_flaky + kill_repeated to probe deeper resilience	2026-04-06 09:18:18.90294	2026-04-06 09:18:18.90294
82236e9d-a2e1-4f14-96b2-299903b79d97	android	network_interruption_recovery	killed	degraded	high	Process became not_running during experiment	t	t	f	f	f	18068	\N	\N	0	7.142857142857142	f	0	0	t	f	["running state does not match expectation"]	FAIL	App process was killed and later recovered	Improve warm-start rehydration to reduce restart impact	2026-04-14 04:45:25.934053	2026-04-14 04:45:25.934053
2a78671b-30e9-4353-916c-546f92a2236f	android	network_interruption_recovery	healthy	healthy	low		t	t	f	f	t	9960	\N	\N	0	100	f	0	0	t	t	[]	PASS	Observed behavior matched configured expectations	Increase stress with network_flaky + kill_repeated to probe deeper resilience	2026-04-14 05:13:43.021149	2026-04-14 05:13:43.021149
638f7e61-9cb6-4756-8bb4-57812cb1dfd7	android	process_kill_recovery	killed	degraded	high	Process not running after fault: kill_app	t	t	t	f	t	11657	\N	\N	0	76.92307692307693	f	0	1	t	t	[]	PASS	Observed behavior matched configured expectations	Increase stress with network_flaky + kill_repeated to probe deeper resilience	2026-04-14 06:43:43.781921	2026-04-14 06:43:43.781921
\.


--
-- Data for Name: android_experiments; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.android_experiments (experiment_id, fault_type, state, phase, package_name, activity, apk_path, targets, created_at, updated_at) FROM stdin;
503df375-a008-4806-ad52-52fb392d0f01	kill_app	failed	completed	com.example.code	com.example.code.MainActivity	D:\\FailSafe\\uploads\\apks\\29f3070c-9fe7-48f0-8aeb-da11f313bec4.apk	["com.example.code"]	2026-04-05 00:15:08.151312	2026-04-05 00:18:23.059384
1f1a4471-c672-4982-ba8d-e8a8ed79817e	kill_app	running	baseline	com.example.code	com.example.code.MainActivity	D:\\FailSafe\\uploads\\apks\\3ff05e8e-9516-4a60-b931-72948985b510.apk	["com.example.code"]	2026-04-05 01:18:07.078143	2026-04-05 01:18:07.078143
f1a53060-f7f1-40f1-8078-c540eae49879	kill_app	running	baseline	com.example.code	com.example.code.MainActivity	D:\\FailSafe\\uploads\\apks\\91226541-d2f6-491d-b16c-ea92ba70176f.apk	["com.example.code"]	2026-04-06 14:47:45.918917	2026-04-06 14:47:45.918917
2a78671b-30e9-4353-916c-546f92a2236f	network_disable	running	baseline	com.example.code	com.example.code.MainActivity	D:\\FailSafe\\uploads\\apks\\ba221153-005e-457f-b528-d42f8e50b1ac.apk	["com.example.code"]	2026-04-14 10:42:44.921327	2026-04-14 10:42:44.921327
638f7e61-9cb6-4756-8bb4-57812cb1dfd7	latency	failed	completed	com.example.code	com.example.code.MainActivity	D:\\FailSafe\\uploads\\apks\\2c4aa219-1f9c-4325-ae15-6dbf71369ed2.apk	["com.example.code"]	2026-04-14 12:12:49.465345	2026-04-14 21:18:59.849467
82236e9d-a2e1-4f14-96b2-299903b79d97	network_disable	failed	completed	com.example.code	com.example.code.MainActivity	D:\\FailSafe\\uploads\\apks\\ba221153-005e-457f-b528-d42f8e50b1ac.apk	["com.example.code"]	2026-04-14 10:14:27.73328	2026-04-14 21:29:48.501769
\.


--
-- Data for Name: android_metrics_raw; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.android_metrics_raw (id, experiment_id, endpoint, "timestamp", app_state, crash, anr, crash_reason, memory_mb, frame_drops, latency_ms, status, intensity) FROM stdin;
1	503df375-a008-4806-ad52-52fb392d0f01	com.example.code	2026-04-05 00:15:11.242234	running	f	f		0	0	0	0	0
2	503df375-a008-4806-ad52-52fb392d0f01	com.example.code	2026-04-05 00:15:13.028714	running	f	f		0	0	0	0	0
3	503df375-a008-4806-ad52-52fb392d0f01	com.example.code	2026-04-05 00:15:14.802508	not_running	f	f		0	0	0	0	0
4	503df375-a008-4806-ad52-52fb392d0f01	com.example.code	2026-04-05 00:15:16.760427	not_running	f	f		0	0	0	0	0
5	503df375-a008-4806-ad52-52fb392d0f01	com.example.code	2026-04-05 00:15:18.728497	not_running	f	f		0	0	0	0	0
6	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:09.681379	running	f	f		0	0	0	0	0
7	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:11.463657	running	f	f		0	0	0	0	0
8	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:13.462692	running	f	f		0	0	0	0	0
9	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:15.455011	running	f	f		0	0	0	0	0
10	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:17.452437	running	f	f		0	0	0	0	0
11	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:19.452602	running	f	f		0	0	0	0	0
12	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:21.545326	running	f	f		0	0	0	0	0
13	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:23.548738	running	f	f		0	0	0	0	0
14	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:25.463267	running	f	f		0	0	0	0	0
15	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:27.462368	running	f	f		0	0	0	0	0
16	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:29.45528	running	f	f		0	0	0	0	0
17	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:31.459002	running	f	f		0	0	0	0	0
18	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:33.514586	not_running	f	f		0	0	0	0	0
19	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:35.489194	running	f	f		0	0	0	0	0
20	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:37.513995	running	f	f		0	0	0	0	0
21	1f1a4471-c672-4982-ba8d-e8a8ed79817e	com.example.code	2026-04-05 01:18:39.459418	running	f	f		0	0	0	0	0
22	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:47:48.425517	running	f	f		0	0	0	0	0
23	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:47:50.396686	running	f	f		0	0	0	0	0
24	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:47:52.337743	running	f	f		0	0	0	0	0
25	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:47:54.33865	running	f	f		0	0	0	0	0
26	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:47:56.348938	running	f	f		0	0	0	0	0
27	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:47:58.37363	running	f	f		0	0	0	0	0
28	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:48:00.404191	running	f	f		0	0	0	0	0
29	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:48:02.4613	running	f	f		0	0	0	0	0
30	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:48:04.340823	running	f	f		0	0	0	0	0
31	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:48:06.314392	running	f	f		0	0	0	0	0
32	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:48:08.312218	running	f	f		0	0	0	0	0
33	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:48:10.367342	running	f	f		0	0	0	0	0
34	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:48:12.363613	not_running	f	f		0	0	0	0	0
35	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:48:14.345661	running	f	f		0	0	0	0	0
36	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:48:16.374456	running	f	f		0	0	0	0	0
37	f1a53060-f7f1-40f1-8078-c540eae49879	com.example.code	2026-04-06 14:48:18.356479	running	f	f		0	0	0	0	0
38	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:30.442687	running	f	f		0	0	0	0	0
39	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:32.490896	running	f	f		0	0	0	0	0
40	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:34.225474	not_running	f	f		0	0	0	0	0
41	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:36.165425	not_running	f	f		0	0	0	0	0
42	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:38.198729	not_running	f	f		0	0	0	0	0
43	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:40.156392	not_running	f	f		0	0	0	0	0
44	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:42.12339	not_running	f	f		0	0	0	0	0
45	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:44.124541	not_running	f	f		0	0	0	0	0
46	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:46.197374	not_running	f	f		0	0	0	0	0
47	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:48.303511	not_running	f	f		0	0	0	0	0
48	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:50.134178	not_running	f	f		0	0	0	0	0
49	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:52.209884	not_running	f	f		0	0	0	0	0
50	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:54.12838	not_running	f	f		0	0	0	0	0
51	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:56.120514	not_running	f	f		0	0	0	0	0
52	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:14:58.251439	not_running	f	f		0	0	0	0	0
53	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:00.299994	not_running	f	f		0	0	0	0	0
54	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:02.135344	not_running	f	f		0	0	0	0	0
55	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:04.154126	not_running	f	f		0	0	0	0	0
56	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:06.158481	not_running	f	f		0	0	0	0	0
57	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:08.113186	not_running	f	f		0	0	0	0	0
58	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:10.124726	not_running	f	f		0	0	0	0	0
59	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:12.110404	not_running	f	f		0	0	0	0	0
60	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:14.105091	not_running	f	f		0	0	0	0	0
61	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:16.129847	not_running	f	f		0	0	0	0	0
62	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:18.085929	not_running	f	f		0	0	0	0	0
63	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:20.097658	not_running	f	f		0	0	0	0	0
64	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:22.124152	not_running	f	f		0	0	0	0	0
65	82236e9d-a2e1-4f14-96b2-299903b79d97	com.example.code	2026-04-14 10:15:24.110288	not_running	f	f		0	0	0	0	0
66	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:42:47.861185	running	f	f		0	0	0	0	0
67	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:42:49.503921	running	f	f		0	0	0	0	0
68	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:42:51.508353	running	f	f		0	0	0	0	0
69	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:42:53.550402	running	f	f		0	0	0	0	0
70	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:42:55.678659	running	f	f		0	0	0	0	0
71	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:42:57.550683	running	f	f		0	0	0	0	0
72	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:42:59.521348	running	f	f		0	0	0	0	0
73	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:01.441417	running	f	f		0	0	0	0	0
74	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:03.496808	running	f	f		0	0	0	0	0
75	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:05.437603	running	f	f		0	0	0	0	0
76	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:07.474791	running	f	f		0	0	0	0	0
77	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:09.486458	running	f	f		0	0	0	0	0
78	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:11.545856	running	f	f		0	0	0	0	0
79	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:13.500082	running	f	f		0	0	0	0	0
80	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:15.479914	running	f	f		0	0	0	0	0
81	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:17.43837	running	f	f		0	0	0	0	0
82	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:19.437493	running	f	f		0	0	0	0	0
83	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:21.43717	running	f	f		0	0	0	0	0
84	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:23.447269	running	f	f		0	0	0	0	0
85	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:25.457378	running	f	f		0	0	0	0	0
86	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:27.438209	running	f	f		0	0	0	0	0
87	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:29.450249	running	f	f		0	0	0	0	0
88	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:31.452684	running	f	f		0	0	0	0	0
89	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:33.439736	running	f	f		0	0	0	0	0
90	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:35.590735	running	f	f		0	0	0	0	0
91	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:37.48244	running	f	f		0	0	0	0	0
92	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:39.487747	running	f	f		0	0	0	0	0
93	2a78671b-30e9-4353-916c-546f92a2236f	com.example.code	2026-04-14 10:43:41.475347	running	f	f		0	0	0	0	0
94	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:12:52.380809	running	f	f		0	0	0	0	0
95	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:12:54.569272	running	f	f		0	0	0	0	0
96	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:12:56.351402	running	f	f		0	0	0	0	0
97	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:12:58.318742	running	f	f		0	0	0	0	0
98	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:00.24594	running	f	f		0	0	0	0	0
99	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:02.28106	running	f	f		0	0	0	0	0
100	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:04.233048	running	f	f		0	0	0	0	0
101	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:06.322279	running	f	f		0	0	0	0	0
102	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:08.34027	running	f	f		0	0	0	0	0
103	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:10.267422	running	f	f		0	0	0	0	0
104	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:12.278205	running	f	f		0	0	0	0	0
105	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:14.318754	running	f	f		0	0	0	0	0
106	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:16.659643	not_running	f	f		0	0	0	0	0
107	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:18.154399	not_running	f	f		0	0	0	0	0
108	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:20.10706	not_running	f	f		0	0	0	0	0
109	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:22.092634	not_running	f	f		0	0	0	0	0
110	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:24.116931	not_running	f	f		0	0	0	0	0
111	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:26.124035	not_running	f	f		0	0	0	0	0
112	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:28.317603	running	f	f		0	0	0	0	0
113	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:30.259154	running	f	f		0	0	0	0	0
114	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:32.644928	running	f	f		0	0	0	0	0
115	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:34.084248	running	f	f		0	0	0	0	0
116	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:36.553787	running	f	f		0	0	0	0	0
117	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:38.373489	running	f	f		0	0	0	0	0
118	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:40.245342	running	f	f		0	0	0	0	0
119	638f7e61-9cb6-4756-8bb4-57812cb1dfd7	com.example.code	2026-04-14 12:13:42.258995	running	f	f		0	0	0	0	0
\.


--
-- Data for Name: android_status_metrics; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.android_status_metrics (experiment_id, state, phase, health_status, severity, recovered, recovery_time_ms, validation_passed, summary_result, failsafe_score, status_payload, updated_at) FROM stdin;
503df375-a008-4806-ad52-52fb392d0f01	failed	completed	down	critical	f	-1	f	FAIL	100	{"phase": "completed", "state": "failed", "health": {"status": "down", "thread": "", "severity": "critical", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "impact": {"cascade_depth": 2, "disruption_events": 1, "blast_radius_percent": 60, "app_availability_percent": 40}, "summary": {"reason": "App did not recover after process kill (likely cause: kill_app)", "result": "FAIL", "suggestion": "Handle process death and restore app state on launch"}, "frontend": null, "recovery": {"running": false, "recovered": false, "auto_recovered": false, "recovery_time_ms": -1, "stable_recovered": false, "manual_intervention_required": true}, "scenario": "single_fault", "timeline": {"recovery": {}, "fault_start": "2026-04-05T00:15:14.1791816+05:30", "first_impact": {"com.example.code": "2026-04-05T00:15:14.8025087+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 40, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 0}, "validation": {"passed": false, "reasons": ["running state does not match expectation", "expected recovery but app did not recover", "process kill detected and app did not recover"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 217, "fault": "kill_app", "at_time": "2026-04-05T00:15:14.3970693+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 623, "at_time": "2026-04-05T00:15:14.8025087+05:30"}], "cascade_depth": 2, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-05T00:15:14.8025087+05:30", "to": "not_running", "from": "running"}], "blast_radius_percent": 60, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-04 18:48:23.070913
1f1a4471-c672-4982-ba8d-e8a8ed79817e	completed	completed	degraded	high	t	1974	t	PASS	100	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 93.75}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 1974, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-05T01:18:35.4891949+05:30"}, "fault_start": "2026-04-05T01:18:13.0967965+05:30", "first_impact": {"com.example.code": "2026-04-05T01:18:33.5145866+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 93.75, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8128, "fault": "network_enable", "at_time": "2026-04-05T01:18:21.225405+05:30"}, {"step": "inject_fault", "at_ms": 10106, "fault": "network_disable", "at_time": "2026-04-05T01:18:23.2029186+05:30"}, {"step": "inject_fault", "at_ms": 20132, "fault": "kill_app", "at_time": "2026-04-05T01:18:33.2290103+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 20417, "at_time": "2026-04-05T01:18:33.5145866+05:30"}, {"step": "inject_fault", "at_ms": 21340, "fault": "foreground_app", "at_time": "2026-04-05T01:18:34.4375367+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 22392, "at_time": "2026-04-05T01:18:35.4891949+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-05T01:18:33.5145866+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-05T01:18:35.4891949+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-04 19:48:41.099103
f1a53060-f7f1-40f1-8078-c540eae49879	completed	completed	degraded	high	t	1982	t	PASS	100	{"health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 93.75}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 1982, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-06T14:48:14.3456616+05:30"}, "fault_start": "2026-04-06T14:47:51.9498689+05:30", "first_impact": {"com.example.code": "2026-04-06T14:48:12.3636134+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 93.75, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8111, "fault": "network_enable", "at_time": "2026-04-06T14:48:00.0616339+05:30"}, {"step": "inject_fault", "at_ms": 10112, "fault": "network_disable", "at_time": "2026-04-06T14:48:02.0627455+05:30"}, {"step": "inject_fault", "at_ms": 20136, "fault": "kill_app", "at_time": "2026-04-06T14:48:12.0861366+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 20413, "at_time": "2026-04-06T14:48:12.3636134+05:30"}, {"step": "inject_fault", "at_ms": 21933, "fault": "foreground_app", "at_time": "2026-04-06T14:48:13.8832371+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 22395, "at_time": "2026-04-06T14:48:14.3456616+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-06T14:48:12.3636134+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-06T14:48:14.3456616+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-06 09:18:18.895648
82236e9d-a2e1-4f14-96b2-299903b79d97	failed	completed	degraded	high	t	18068	f	FAIL	100	{"phase": "completed", "state": "failed", "health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process became not_running during experiment", "failure_type": "killed"}, "impact": {"cascade_depth": 2, "disruption_events": 1, "blast_radius_percent": 92.85714285714286, "app_availability_percent": 7.142857142857142}, "summary": {"reason": "App process was killed and later recovered", "result": "FAIL", "suggestion": "Improve warm-start rehydration to reduce restart impact"}, "frontend": null, "recovery": {"running": false, "recovered": true, "auto_recovered": true, "recovery_time_ms": 18068, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "network_interruption_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-14T10:14:52.2940272+05:30"}, "fault_start": "2026-04-14T10:14:33.7912818+05:30", "first_impact": {"com.example.code": "2026-04-14T10:14:34.2254745+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 7.142857142857142, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 0}, "validation": {"passed": false, "reasons": ["running state does not match expectation"], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 434, "at_time": "2026-04-14T10:14:34.2254745+05:30"}, {"step": "inject_fault", "at_ms": 8465, "fault": "network_disable", "at_time": "2026-04-14T10:14:42.256397+05:30"}, {"step": "inject_fault", "at_ms": 18502, "fault": "network_enable", "at_time": "2026-04-14T10:14:52.2940272+05:30"}, {"step": "inject_fault", "at_ms": 40241, "fault": "network_flaky", "at_time": "2026-04-14T10:15:14.0328906+05:30"}, {"step": "inject_fault", "at_ms": 47106, "fault": "network_latency", "at_time": "2026-04-14T10:15:20.897411+05:30"}], "cascade_depth": 2, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-14T10:14:34.2254745+05:30", "to": "not_running", "from": "running"}], "blast_radius_percent": 92.85714285714286, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 1}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-14 15:59:48.510131
2a78671b-30e9-4353-916c-546f92a2236f	completed	completed	healthy	low	t	9960	t	PASS	100	{"health": {"status": "healthy", "thread": "", "severity": "low", "crash_reason": "", "failure_type": "healthy"}, "impact": {"cascade_depth": 0, "disruption_events": 0, "blast_radius_percent": 0, "app_availability_percent": 100}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 9960, "stable_recovered": false, "manual_intervention_required": false}, "scenario": "network_interruption_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-14T10:43:09.0167962+05:30"}, "fault_start": "2026-04-14T10:42:50.9344597+05:30", "first_impact": {"com.example.code": "2026-04-14T10:42:59.0558305+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 100, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 0}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 8121, "fault": "network_disable", "at_time": "2026-04-14T10:42:59.0558305+05:30"}, {"step": "inject_fault", "at_ms": 18082, "fault": "network_enable", "at_time": "2026-04-14T10:43:09.0167962+05:30"}, {"step": "inject_fault", "at_ms": 40153, "fault": "network_flaky", "at_time": "2026-04-14T10:43:31.0876965+05:30"}, {"step": "inject_fault", "at_ms": 47074, "fault": "network_latency", "at_time": "2026-04-14T10:43:38.0088335+05:30"}], "cascade_depth": 0, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [], "blast_radius_percent": 0, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-14 05:13:43.013372
638f7e61-9cb6-4756-8bb4-57812cb1dfd7	failed	completed	degraded	high	t	11657	t	PASS	100	{"phase": "completed", "state": "failed", "health": {"status": "degraded", "thread": "", "severity": "high", "crash_reason": "Process not running after fault: kill_app", "failure_type": "killed"}, "impact": {"cascade_depth": 3, "disruption_events": 2, "blast_radius_percent": 35, "app_availability_percent": 76.92307692307693}, "summary": {"reason": "Observed behavior matched configured expectations", "result": "PASS", "suggestion": "Increase stress with network_flaky + kill_repeated to probe deeper resilience"}, "frontend": null, "recovery": {"running": true, "recovered": true, "auto_recovered": true, "recovery_time_ms": 11657, "stable_recovered": true, "manual_intervention_required": false}, "scenario": "process_kill_recovery", "timeline": {"recovery": {"com.example.code": "2026-04-14T12:13:28.3176038+05:30"}, "fault_start": "2026-04-14T12:12:55.5027119+05:30", "first_impact": {"com.example.code": "2026-04-14T12:13:16.6596432+05:30"}}, "stability": {"anr_detected": false, "uptime_percent": 76.92307692307693, "warning_signals": 0, "background_samples": 0, "crash_rate_percent": 0, "unexpected_restarts": 1}, "validation": {"passed": true, "reasons": [], "expected": {"not_anr": true, "running": true, "app_state": "", "not_crash": true, "should_recover": true}, "configured": true}, "target_type": "android", "replay_hints": [{"step": "inject_fault", "at_ms": 20323, "fault": "kill_app", "at_time": "2026-04-14T12:13:15.8258833+05:30"}, {"to": "not_running", "from": "running", "step": "state_transition", "at_ms": 21156, "at_time": "2026-04-14T12:13:16.6596432+05:30"}, {"step": "inject_fault", "at_ms": 31644, "fault": "foreground_app", "at_time": "2026-04-14T12:13:27.1467824+05:30"}, {"to": "running", "from": "not_running", "step": "state_transition", "at_ms": 32814, "at_time": "2026-04-14T12:13:28.3176038+05:30"}, {"step": "inject_fault", "at_ms": 43252, "fault": "network_latency", "at_time": "2026-04-14T12:13:38.7551862+05:30"}], "cascade_depth": 3, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "state_transitions": [{"at": "2026-04-14T12:13:16.6596432+05:30", "to": "not_running", "from": "running"}, {"at": "2026-04-14T12:13:28.3176038+05:30", "to": "running", "from": "not_running"}], "blast_radius_percent": 35, "crash_classification": {"ui_bug": 0, "unknown": 0, "network_bug": 0, "induced_kill": 1, "lifecycle_bug": 0}, "resilience_threshold": {"intensity_steps": [], "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-14 15:48:59.860421
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.api_keys (id, key_hash, environment, role, created_at, owner_id) FROM stdin;
497eaad7-67ab-4fdb-8ebb-6a9dbfe56910	fbc90fe757be04729911b5f42bf9e9057e5c02cf5e119f9f64e4d82286d4da07	dev	admin	2026-04-04 17:46:55.196234	\N
668557b2-65b0-44b5-88e5-77302a3ee848	142d0089dfe967c10a48e3f546c0501b68bf015fff0768670872fe51fc5ab853	dev	engineer	2026-04-04 18:17:36.592188	\N
7a003ffb-c03c-437e-a508-1322259e828e	c58b2ca9b076ae01eb53dc2ea68717c693d9e83f45a371dc9259abaad43e234e	dev	admin	2026-04-04 18:28:06.509414	\N
553cc189-f5b1-49b3-ac8f-c492c1e2bb5d	323cb33d925af43c8db5d5f1f20228c19a936e8c6e329a1efbd0b50354d91db1	dev	engineer	2026-04-04 18:34:25.03235	\N
59c88b30-0b2d-4fff-b173-40a30bcd9c3f	16b6cdf6af58b9493dc1455b05f35ebc5ba45833eac9d56f3d460d83c868bcee	dev	admin	2026-04-04 19:42:12.505232	\N
8834a23a-c785-4b6e-92a5-67bf33677d8b	d38429c7471427625c0072b691e7e8e21d5d6d97944292f596ee79762c6fd6c4	dev	admin	2026-04-04 19:42:20.183564	\N
19d0c37e-a6e3-4bd7-9311-6aa6477a26d8	132918ecb5aca36b835b782ae10275dc5a2c86b384dec6a123736066e8f7602e	dev	admin	2026-04-06 09:15:53.243986	\N
9af3cc62-b541-4bad-9e49-1a65a427e39d	ddaa18421d874b63310f631256bfb9a90c554b73d8e8dfefe35ce35fa9694866	dev	engineer	2026-04-06 15:58:42.76857	\N
e2e3c6c2-0a0a-4095-8644-ec94412731d7	f4388615cf9ab274260b4f109617c9c44e97f8a1be7723d5e39ceb14b232062b	dev	admin	2026-04-06 16:09:31.15015	\N
4cb3d8ee-86ef-4687-aa8b-5fe43b5e1347	ae5f52a546a6e0cb55bd3849bea41cbd202bb5c4a21c31d80d1efcd7a4ea0f0c	dev	viewer	2026-04-06 16:10:10.377377	\N
b059fbe6-e785-4aea-adc2-b01a1ecc8f82	991da048cbaee9e2d82b5bca4ad61a11e1d021f2ecf627094e6cbb806dea5f8a	dev	engineer	2026-04-06 16:10:28.297228	\N
1ce997fe-6112-46ef-8ece-b667e23cc97a	d63cee791918e0264fa6416698895389d535545bf9afdfa515573aaecadb630c	dev	admin	2026-04-07 01:58:46.349959	\N
592fe716-0223-4f13-90f3-904ffb989cc2	6ae3a96e9c39cc6dbba59f391197454d2a0a1024039217924d895c91e667f8bc	dev	admin	2026-04-07 01:58:50.772315	\N
85f235ca-3d73-481e-861b-1ecae1612d35	01903dfa433ac265b299e58aed4dc17af06f388a13c2664563b931c98ba48d36	dev	admin	2026-04-13 16:49:41.852165	\N
453e0b48-12f4-47eb-9848-3fbabc828838	8ab8d98e1467fcd40d69a28f1e67477b66bbe0ce57c07cad55d99c97ebe8a9e3	dev	admin	2026-04-13 16:52:27.977492	\N
29568107-1e9b-48ef-8aa6-67a4967cd7b1	2c49a9e6aa147d48a59cede7b9edabc84bb01c21e5f68f6db85576897ac3c941	dev	admin	2026-04-13 16:53:25.303198	\N
107c7711-8404-4be1-a6a5-0710e11f5b00	3deb1b60dde695ce752ffa9cc43f707c9b87c849944dcd664d59278effe55fbc	dev	admin	2026-04-13 16:54:24.523487	\N
66a4c29f-0007-4911-8275-a17be2ad76ef	6d3b777dfc84134f098b0861d6b58338ecbe562c44024265434f09ec60644ce9	dev	admin	2026-04-14 03:45:09.937543	\N
5e557c81-5969-41ce-ad3a-bcaef736b999	bb74c33d2c0743c866e0d332f827d543bea7ef3b7d0cb8c3981309261ded9ca0	dev	admin	2026-04-14 04:08:54.818459	\N
568289db-1aa5-4617-bc5b-dc4cfe7e90e1	1bc3cb557e629414a96051df733cdff7361fb3867bab758ecf8ca31ca6a728c7	dev	engineer	2026-04-14 08:07:06.061679	\N
c7d42845-a103-4d67-9584-6ec6f2bf1f49	7de0b31ff539d0b93f8c5fb3606dde8c4ebc44cbce867705979b56859d860bd3	dev	viewer	2026-04-14 13:59:15.816681	4a22ba21-25e8-418e-9e97-88e0a251647f
3a68e3f5-a4cc-4c35-a98f-73e36da0f31a	4dac494d63790e414f5fef9bf4c9d4f8ccc9e661b084ece7a4239bae328c9191	dev	engineer	2026-04-14 13:59:34.294148	4a22ba21-25e8-418e-9e97-88e0a251647f
14c91443-123e-42e7-9fb4-475feda5cd7e	d0662ea6c2848d4228a1e896c3cb62a1d31ce5da84e6b331b813adfb10aff7ac	dev	viewer	2026-04-14 15:03:25.521711	\N
17fb6acf-276a-4da7-9fd7-a38639469f34	367ede6304b14c7672b2c6b2ec0f4cd7a1a3b58c28fe8c0aa7c72081030d59b7	dev	admin	2026-04-14 15:03:49.816918	\N
\.


--
-- Data for Name: backend_experiments; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.backend_experiments (experiment_id, fault_type, state, phase, targets, observed_endpoints, created_at, updated_at) FROM stdin;
1fe154e4-a5ef-4cb1-8b63-73fb815bd835	network_delay	failed	completed	["order-service"]	["http://api-gateway:8080/api/users/1", "http://api-gateway:8080/api/orders/10", "http://user-service:8081/users/1", "http://order-service:8082/orders/10"]	2026-04-05 00:04:25.246615	2026-04-05 00:11:23.268916
89bbde53-24f1-4d15-854a-7d3031a45875	network_delay	running	baseline	["order-service"]	["http://api-gateway:8080/health"]	2026-04-06 14:58:14.515761	2026-04-06 14:58:14.515761
aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	network_delay	running	baseline	["order-service"]	["http://api-gateway:8080/api/users/1", "http://api-gateway:8080/api/orders/10", "http://order-service:8082/orders/10", "http://user-service:8081/users/1", "http://payment-service:8083/payments/10", "http://inventory-service:8084/inventory/A1", "http://shipping-service:8085/shipping/10", "http://notification-service:8086/notifications/10", "http://recommendation-service:8087/recommendations/1"]	2026-04-06 16:03:13.872283	2026-04-06 16:03:13.872283
a98a50a9-f656-4e82-970c-0b0b2165b36e	network_delay	running	baseline	["order-service"]	["http://api-gateway:8080/api/users/1", "http://api-gateway:8080/api/orders/10", "http://order-service:8082/orders/10", "http://user-service:8081/users/1", "http://payment-service:8083/payments/10", "http://inventory-service:8084/inventory/A1", "http://shipping-service:8085/shipping/10", "http://notification-service:8086/notifications/10", "http://recommendation-service:8087/recommendations/1"]	2026-04-06 16:15:04.826951	2026-04-06 16:15:04.826951
6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	network_delay	running	baseline	["order-service"]	["http://api-gateway:8080/api/users/1", "http://api-gateway:8080/api/orders/10", "http://order-service:8082/orders/10", "http://user-service:8081/users/1", "http://payment-service:8083/payments/10", "http://inventory-service:8084/inventory/A1", "http://shipping-service:8085/shipping/10", "http://notification-service:8086/notifications/10", "http://recommendation-service:8087/recommendations/1"]	2026-04-06 19:44:16.616065	2026-04-06 19:44:16.616065
50be69bb-0d99-4875-b756-eb541d3156cd	network_delay	running	baseline	["api-gateway", "notification-service", "order-service", "user-service", "payment-service", "shipping-service", "inventory-service", "recommendation-service"]	["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\""]	2026-04-08 20:50:31.483313	2026-04-08 20:50:31.483313
fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	kill	running	baseline	["api-gateway", "inventory-service", "notification-service", "order-service", "payment-service", "recommendation-service", "shipping-service", "user-service"]	["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\""]	2026-04-08 22:42:12.764035	2026-04-08 22:42:12.764035
8ccb8c63-1dfb-4513-857a-62886761cec2	kill	running	baseline	["api-gateway", "inventory-service", "notification-service", "order-service", "payment-service", "recommendation-service", "shipping-service", "user-service"]	["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\""]	2026-04-08 22:50:13.657915	2026-04-08 22:50:13.657915
d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	kill	running	baseline	["api-gateway", "inventory-service", "notification-service", "order-service", "payment-service", "recommendation-service", "shipping-service", "user-service"]	["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\""]	2026-04-08 23:05:42.78195	2026-04-08 23:05:42.78195
f3f5f610-171b-4c65-84e1-2d66e7226aed	network_delay	running	baseline	["api-gateway", "inventory-service", "notification-service", "order-service", "payment-service", "recommendation-service", "shipping-service", "user-service"]	["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\""]	2026-04-13 21:52:28.927318	2026-04-13 21:52:28.927318
3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	network_delay	running	baseline	["api-gateway", "inventory-service", "notification-service", "order-service", "payment-service", "recommendation-service", "shipping-service", "user-service"]	["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\""]	2026-04-13 22:02:58.414986	2026-04-13 22:02:58.414986
ce28f73b-57fc-45cf-9f60-36bfed57da8c	kill	running	baseline	["order-service"]	["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\""]	2026-04-13 22:08:19.303385	2026-04-13 22:08:19.303385
4ea99c95-1ae4-47db-90dd-715a5f8221c4	cpu_stress	running	baseline	["api-gateway", "inventory-service", "notification-service", "order-service", "payment-service", "recommendation-service", "shipping-service", "user-service"]	["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\""]	2026-04-13 22:14:57.313009	2026-04-13 22:14:57.313009
14a3dd03-24ad-42f0-8af9-2c94a52063aa	network_delay	running	baseline	["api-gateway"]	null	2026-04-13 22:22:28.225743	2026-04-13 22:22:28.225743
0c9159af-dbe7-4559-8610-0984750f18b8	network_delay	running	baseline	["api-gateway"]	null	2026-04-13 22:23:25.529495	2026-04-13 22:23:25.529495
7a2483a8-2988-4a21-b0f8-73c9e8533825	network_delay	running	baseline	["api-gateway"]	null	2026-04-13 22:24:24.817372	2026-04-13 22:24:24.817372
ec680a5c-b06d-417e-b725-0a9545bc9e8a	kill	running	baseline	["api-gateway", "inventory-service", "notification-service", "order-service", "payment-service", "recommendation-service", "shipping-service", "user-service"]	["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\""]	2026-04-14 16:31:46.585939	2026-04-14 16:31:46.585939
deccd3c1-17c5-4380-a1cb-961e2aef6502	network_delay	running	baseline	["api-gateway", "inventory-service", "notification-service", "order-service", "payment-service", "recommendation-service", "shipping-service", "user-service"]	["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\""]	2026-04-14 20:18:41.267578	2026-04-14 20:18:41.267578
\.


--
-- Data for Name: backend_metrics_raw; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.backend_metrics_raw (id, experiment_id, endpoint, "timestamp", latency_ms, status, intensity, container_cpu, container_memory) FROM stdin;
1	e6118e4c-ed74-436e-b79a-47fcef930087	/	2026-04-04 23:47:36.661926	88	200	0	0	0
2	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/users/1	2026-04-05 00:04:27.310008	500	0	0	0.02	24.4
3	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/users/1	2026-04-05 00:04:27.310008	500	0	0	0.02	24.4
4	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/orders/10	2026-04-05 00:04:27.810386	500	0	0	0.02	24.4
5	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/orders/10	2026-04-05 00:04:27.810386	500	0	0	0.02	24.4
6	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://user-service:8081/users/1	2026-04-05 00:04:28.310819	500	0	0	0.02	24.4
7	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://user-service:8081/users/1	2026-04-05 00:04:28.310819	500	0	0	0.02	24.4
8	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://order-service:8082/orders/10	2026-04-05 00:04:28.810983	500	0	0	0.02	24.4
9	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://order-service:8082/orders/10	2026-04-05 00:04:28.810983	500	0	0	0.02	24.4
10	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/users/1	2026-04-05 00:04:31.337654	500	0	0	0.01	24.4
11	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/users/1	2026-04-05 00:04:31.337654	500	0	0	0.01	24.4
12	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/orders/10	2026-04-05 00:04:31.838604	500	0	0	0.01	24.4
13	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/orders/10	2026-04-05 00:04:31.838604	500	0	0	0.01	24.4
14	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://user-service:8081/users/1	2026-04-05 00:04:32.339163	500	0	0	0.01	24.4
15	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://user-service:8081/users/1	2026-04-05 00:04:32.339163	500	0	0	0.01	24.4
16	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://order-service:8082/orders/10	2026-04-05 00:04:32.839822	500	0	0	0.01	24.4
17	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://order-service:8082/orders/10	2026-04-05 00:04:32.839822	500	0	0	0.01	24.4
18	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/users/1	2026-04-05 00:04:34.39004	500	0	0	0.02	24.4
19	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/users/1	2026-04-05 00:04:34.39004	500	0	0	0.02	24.4
20	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/users/1	2026-04-05 00:04:34.39004	500	0	0	0.02	24.4
21	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/orders/10	2026-04-05 00:04:34.89071	500	0	0	0.02	24.4
22	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/orders/10	2026-04-05 00:04:34.89071	500	0	0	0.02	24.4
23	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/orders/10	2026-04-05 00:04:34.89071	500	0	0	0.02	24.4
24	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://user-service:8081/users/1	2026-04-05 00:04:35.391136	500	0	0	0.02	24.4
25	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://user-service:8081/users/1	2026-04-05 00:04:35.391136	500	0	0	0.02	24.4
26	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://user-service:8081/users/1	2026-04-05 00:04:35.391136	500	0	0	0.02	24.4
27	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://order-service:8082/orders/10	2026-04-05 00:04:35.891373	500	0	0	0.02	24.4
28	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://order-service:8082/orders/10	2026-04-05 00:04:35.891373	500	0	0	0.02	24.4
29	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://order-service:8082/orders/10	2026-04-05 00:04:35.891373	500	0	0	0.02	24.4
30	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/users/1	2026-04-05 00:04:37.44688	500	0	0	2.64	25.51
31	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/users/1	2026-04-05 00:04:37.44688	500	0	0	2.64	25.51
32	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/orders/10	2026-04-05 00:04:37.947125	500	0	0	2.64	25.51
33	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/orders/10	2026-04-05 00:04:37.947125	500	0	0	2.64	25.51
34	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://user-service:8081/users/1	2026-04-05 00:04:38.447656	500	0	0	2.64	25.51
35	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://user-service:8081/users/1	2026-04-05 00:04:38.447656	500	0	0	2.64	25.51
36	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://order-service:8082/orders/10	2026-04-05 00:04:38.948297	500	0	0	2.64	25.51
37	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://order-service:8082/orders/10	2026-04-05 00:04:38.948297	500	0	0	2.64	25.51
38	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/users/1	2026-04-05 00:04:40.503448	500	0	0	0.02	26.52
39	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/users/1	2026-04-05 00:04:40.503448	500	0	0	0.02	26.52
40	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/orders/10	2026-04-05 00:04:41.004264	500	0	0	0.02	26.52
41	1fe154e4-a5ef-4cb1-8b63-73fb815bd835	http://api-gateway:8080/api/orders/10	2026-04-05 00:04:41.004264	500	0	0	0.02	26.52
42	1db2288b-9922-4f25-9efa-f8558df70288	frontend:ingest	2026-04-05 01:21:07.926958	0	408	0	0	0
43	89bbde53-24f1-4d15-854a-7d3031a45875	http://api-gateway:8080/health	2026-04-06 14:58:16.568756	500	0	0	0.01	24.28
44	89bbde53-24f1-4d15-854a-7d3031a45875	http://api-gateway:8080/health	2026-04-06 14:58:16.568756	500	0	0	0.01	24.28
45	89bbde53-24f1-4d15-854a-7d3031a45875	http://api-gateway:8080/health	2026-04-06 14:58:18.572853	500	0	0	0.01	24.28
46	89bbde53-24f1-4d15-854a-7d3031a45875	http://api-gateway:8080/health	2026-04-06 14:58:18.572853	500	0	0	0.01	24.28
47	89bbde53-24f1-4d15-854a-7d3031a45875	http://api-gateway:8080/health	2026-04-06 14:58:20.57725	500	0	0	0.02	24.28
48	89bbde53-24f1-4d15-854a-7d3031a45875	http://api-gateway:8080/health	2026-04-06 14:58:20.57725	500	0	0	0.02	24.28
49	89bbde53-24f1-4d15-854a-7d3031a45875	http://api-gateway:8080/health	2026-04-06 14:58:20.57725	500	0	0	0.02	24.28
50	89bbde53-24f1-4d15-854a-7d3031a45875	http://api-gateway:8080/health	2026-04-06 14:58:22.584895	500	0	0	0.02	25.54
51	89bbde53-24f1-4d15-854a-7d3031a45875	http://api-gateway:8080/health	2026-04-06 14:58:22.584895	500	0	0	0.02	25.54
52	89bbde53-24f1-4d15-854a-7d3031a45875	http://api-gateway:8080/health	2026-04-06 14:58:24.605563	500	0	0	0.02	26.43
53	89bbde53-24f1-4d15-854a-7d3031a45875	http://api-gateway:8080/health	2026-04-06 14:58:24.605563	500	0	0	0.02	26.43
76	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:15.937404	500	0	0	0.01	24.33
77	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:15.937404	500	0	0	0.01	24.33
78	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:16.43836	500	0	0	0.01	24.33
79	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:16.43836	500	0	0	0.01	24.33
80	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:16.939117	500	0	0	0.01	24.33
81	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:16.939117	500	0	0	0.01	24.33
82	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:17.439583	500	0	0	0.01	24.33
83	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:17.439583	500	0	0	0.01	24.33
84	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:17.939902	500	0	0	0.01	24.33
85	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:17.939902	500	0	0	0.01	24.33
86	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:18.440576	500	0	0	0.01	24.33
87	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:18.440576	500	0	0	0.01	24.33
88	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:18.942014	501	0	0	0.01	24.33
89	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:18.942014	501	0	0	0.01	24.33
90	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:19.442778	500	0	0	0.01	24.33
91	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:19.442778	500	0	0	0.01	24.33
92	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:19.94292	500	0	0	0.01	24.33
93	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:19.94292	500	0	0	0.01	24.33
94	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:22.266448	500	0	0	0.01	24.33
95	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:22.266448	500	0	0	0.01	24.33
96	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:22.767005	500	0	0	0.01	24.33
97	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:22.767005	500	0	0	0.01	24.33
98	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:23.267661	500	0	0	0.01	24.33
99	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:23.267661	500	0	0	0.01	24.33
100	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:23.76823	500	0	0	0.01	24.33
101	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:23.76823	500	0	0	0.01	24.33
102	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:24.268749	500	0	0	0.01	24.33
103	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:24.268749	500	0	0	0.01	24.33
104	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:24.769528	500	0	0	0.01	24.33
105	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:24.769528	500	0	0	0.01	24.33
106	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:25.27002	500	0	50	0.01	24.33
107	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:25.27002	500	0	50	0.01	24.33
108	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:25.777876	507	0	50	0.01	24.33
109	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:25.777876	507	0	50	0.01	24.33
110	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:26.278232	500	0	50	0.01	24.33
111	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:26.278232	500	0	50	0.01	24.33
112	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:27.827666	500	0	50	3.14	25.92
113	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:27.827666	500	0	50	3.14	25.92
114	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:27.827666	500	0	50	3.14	25.92
115	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:28.328612	500	0	50	3.14	25.92
116	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:28.328612	500	0	50	3.14	25.92
117	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:28.328612	500	0	50	3.14	25.92
118	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:28.828996	500	0	50	3.14	25.92
119	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:28.828996	500	0	50	3.14	25.92
120	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:28.828996	500	0	50	3.14	25.92
121	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:29.329599	500	0	50	3.14	25.92
122	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:29.329599	500	0	50	3.14	25.92
123	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:29.329599	500	0	50	3.14	25.92
124	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:29.830182	500	0	50	3.14	25.92
125	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:29.830182	500	0	50	3.14	25.92
126	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:29.830182	500	0	50	3.14	25.92
127	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:30.331611	501	0	50	3.14	25.92
128	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:30.331611	501	0	50	3.14	25.92
129	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:30.331611	501	0	50	3.14	25.92
130	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:30.832098	500	0	50	3.14	25.92
131	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:30.832098	500	0	50	3.14	25.92
132	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:30.832098	500	0	50	3.14	25.92
133	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:31.332927	500	0	50	3.14	25.92
134	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:31.332927	500	0	50	3.14	25.92
135	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:31.332927	500	0	50	3.14	25.92
136	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:31.833	500	0	50	3.14	25.92
137	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:31.833	500	0	50	3.14	25.92
138	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:31.833	500	0	50	3.14	25.92
139	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:34.322296	500	0	50	0.02	25.18
140	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:34.322296	500	0	50	0.02	25.18
141	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:34.822731	500	0	50	0.02	25.18
142	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:34.822731	500	0	50	0.02	25.18
143	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:35.324031	501	0	50	0.02	25.18
144	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:35.324031	501	0	50	0.02	25.18
145	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:35.824976	500	0	50	0.02	25.18
146	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:35.824976	500	0	50	0.02	25.18
147	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:36.325711	500	0	50	0.02	25.18
148	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:36.325711	500	0	50	0.02	25.18
149	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:36.82612	500	0	50	0.02	25.18
150	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:36.82612	500	0	50	0.02	25.18
151	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:37.326836	500	0	50	0.02	25.18
152	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:37.326836	500	0	50	0.02	25.18
153	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:37.82766	500	0	50	0.02	25.18
154	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:37.82766	500	0	50	0.02	25.18
155	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:38.328257	500	0	50	0.02	25.18
156	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:38.328257	500	0	50	0.02	25.18
157	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:39.878876	501	0	50	0.03	25.18
158	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:39.878876	501	0	50	0.03	25.18
159	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:40.379316	500	0	50	0.03	25.18
160	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:40.379316	500	0	50	0.03	25.18
161	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:40.880018	500	0	50	0.03	25.18
162	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:40.880018	500	0	50	0.03	25.18
163	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:41.381374	501	0	50	0.03	25.18
164	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:41.381374	501	0	50	0.03	25.18
165	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:41.88182	500	0	50	0.03	25.18
166	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:41.88182	500	0	50	0.03	25.18
167	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:42.38231	500	0	50	0.03	25.18
168	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:42.38231	500	0	50	0.03	25.18
169	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:42.883166	500	0	50	0.03	25.18
170	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:42.883166	500	0	50	0.03	25.18
171	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:43.383854	500	0	50	0.03	25.18
172	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:43.383854	500	0	50	0.03	25.18
173	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:43.884118	500	0	50	0.03	25.18
174	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:43.884118	500	0	50	0.03	25.18
175	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:45.43534	500	0	50	0.01	25.18
176	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:45.43534	500	0	50	0.01	25.18
177	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:45.935575	500	0	50	0.01	25.18
178	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:45.935575	500	0	50	0.01	25.18
179	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:46.436278	500	0	50	0.01	25.18
180	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:46.436278	500	0	50	0.01	25.18
181	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:46.937745	501	0	50	0.01	25.18
182	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:46.937745	501	0	50	0.01	25.18
183	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:47.438423	500	0	50	0.01	25.18
184	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:47.438423	500	0	50	0.01	25.18
185	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:47.938694	500	0	50	0.01	25.18
186	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:47.938694	500	0	50	0.01	25.18
187	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:48.438998	500	0	50	0.01	25.18
188	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:48.438998	500	0	50	0.01	25.18
189	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:48.939533	500	0	50	0.01	25.18
190	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:48.939533	500	0	50	0.01	25.18
191	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:49.440185	500	0	50	0.01	25.18
192	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:49.440185	500	0	50	0.01	25.18
193	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:51.000658	500	0	30	4.9	25.61
194	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/users/1	2026-04-06 16:03:51.000658	500	0	30	4.9	25.61
195	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:51.501319	500	0	30	4.9	25.61
196	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://api-gateway:8080/api/orders/10	2026-04-06 16:03:51.501319	500	0	30	4.9	25.61
197	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:52.00186	500	0	30	4.9	25.61
198	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://order-service:8082/orders/10	2026-04-06 16:03:52.00186	500	0	30	4.9	25.61
199	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:52.502778	500	0	30	4.9	25.61
200	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://user-service:8081/users/1	2026-04-06 16:03:52.502778	500	0	30	4.9	25.61
201	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:53.003347	500	0	30	4.9	25.61
202	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://payment-service:8083/payments/10	2026-04-06 16:03:53.003347	500	0	30	4.9	25.61
203	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:53.50441	501	0	30	4.9	25.61
204	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://inventory-service:8084/inventory/A1	2026-04-06 16:03:53.50441	501	0	30	4.9	25.61
205	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:54.005426	501	0	30	4.9	25.61
206	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://shipping-service:8085/shipping/10	2026-04-06 16:03:54.005426	501	0	30	4.9	25.61
207	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:54.506193	500	0	30	4.9	25.61
208	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://notification-service:8086/notifications/10	2026-04-06 16:03:54.506193	500	0	30	4.9	25.61
209	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:55.006693	500	0	30	4.9	25.61
210	aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	http://recommendation-service:8087/recommendations/1	2026-04-06 16:03:55.006693	500	0	30	4.9	25.61
211	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:06.88957	500	0	0	0.02	24.32
212	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:06.88957	500	0	0	0.02	24.32
213	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:07.390106	500	0	0	0.02	24.32
214	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:07.390106	500	0	0	0.02	24.32
215	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:07.890697	500	0	0	0.02	24.32
216	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:07.890697	500	0	0	0.02	24.32
217	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:08.39114	500	0	0	0.02	24.32
218	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:08.39114	500	0	0	0.02	24.32
219	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:08.891869	500	0	0	0.02	24.32
220	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:08.891869	500	0	0	0.02	24.32
221	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:09.392102	500	0	0	0.02	24.32
222	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:09.392102	500	0	0	0.02	24.32
223	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:09.893017	500	0	0	0.02	24.32
224	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:09.893017	500	0	0	0.02	24.32
225	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:10.393229	500	0	0	0.02	24.32
226	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:10.393229	500	0	0	0.02	24.32
227	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:10.893906	500	0	0	0.02	24.32
228	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:10.893906	500	0	0	0.02	24.32
229	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:12.880435	500	0	0	0.01	24.32
230	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:12.880435	500	0	0	0.01	24.32
231	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:13.381294	500	0	0	0.01	24.32
232	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:13.381294	500	0	0	0.01	24.32
233	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:13.882221	500	0	0	0.01	24.32
234	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:13.882221	500	0	0	0.01	24.32
235	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:14.38256	500	0	0	0.01	24.32
236	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:14.38256	500	0	0	0.01	24.32
237	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:14.882756	500	0	0	0.01	24.32
238	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:14.882756	500	0	0	0.01	24.32
239	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:15.383405	500	0	0	0.01	24.32
240	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:15.383405	500	0	0	0.01	24.32
241	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:15.884078	500	0	50	0.01	24.32
242	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:15.884078	500	0	50	0.01	24.32
243	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:16.384463	500	0	50	0.01	24.32
244	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:16.384463	500	0	50	0.01	24.32
245	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:16.885263	500	0	50	0.01	24.32
246	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:16.885263	500	0	50	0.01	24.32
247	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:18.447059	500	0	50	0.02	24.58
248	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:18.447059	500	0	50	0.02	24.58
249	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:18.447059	500	0	50	0.02	24.58
250	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:18.949295	502	0	50	0.02	24.58
251	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:18.949295	502	0	50	0.02	24.58
252	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:18.949295	502	0	50	0.02	24.58
253	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:19.45035	501	0	50	0.02	24.58
254	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:19.45035	501	0	50	0.02	24.58
255	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:19.45035	501	0	50	0.02	24.58
256	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:19.951302	500	0	50	0.02	24.58
257	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:19.951302	500	0	50	0.02	24.58
258	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:19.951302	500	0	50	0.02	24.58
259	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:20.451447	500	0	50	0.02	24.58
260	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:20.451447	500	0	50	0.02	24.58
261	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:20.451447	500	0	50	0.02	24.58
262	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:20.951479	500	0	50	0.02	24.58
263	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:20.951479	500	0	50	0.02	24.58
264	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:20.951479	500	0	50	0.02	24.58
265	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:21.452065	500	0	50	0.02	24.58
266	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:21.452065	500	0	50	0.02	24.58
267	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:21.452065	500	0	50	0.02	24.58
268	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:21.952732	500	0	50	0.02	24.58
269	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:21.952732	500	0	50	0.02	24.58
270	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:21.952732	500	0	50	0.02	24.58
271	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:22.453223	500	0	50	0.02	24.58
272	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:22.453223	500	0	50	0.02	24.58
273	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:22.453223	500	0	50	0.02	24.58
274	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:24.841632	500	0	50	0.02	25.08
275	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:24.841632	500	0	50	0.02	25.08
276	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:25.342489	500	0	50	0.02	25.08
277	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:25.342489	500	0	50	0.02	25.08
278	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:25.843481	500	0	50	0.02	25.08
279	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:25.843481	500	0	50	0.02	25.08
280	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:26.344666	501	0	50	0.02	25.08
281	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:26.344666	501	0	50	0.02	25.08
282	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:26.845541	500	0	50	0.02	25.08
283	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:26.845541	500	0	50	0.02	25.08
284	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:27.346507	500	0	50	0.02	25.08
285	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:27.346507	500	0	50	0.02	25.08
286	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:27.84801	501	0	50	0.02	25.08
287	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:27.84801	501	0	50	0.02	25.08
288	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:28.348588	500	0	50	0.02	25.08
289	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:28.348588	500	0	50	0.02	25.08
290	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:28.849658	501	0	50	0.02	25.08
291	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:28.849658	501	0	50	0.02	25.08
292	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:30.40398	500	0	50	0.02	25.08
293	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:30.40398	500	0	50	0.02	25.08
294	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:30.904533	500	0	50	0.02	25.08
295	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:30.904533	500	0	50	0.02	25.08
296	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:31.404793	500	0	50	0.02	25.08
297	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:31.404793	500	0	50	0.02	25.08
298	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:31.905229	500	0	50	0.02	25.08
299	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:31.905229	500	0	50	0.02	25.08
300	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:32.405876	500	0	50	0.02	25.08
301	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:32.405876	500	0	50	0.02	25.08
302	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:32.906025	500	0	50	0.02	25.08
303	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:32.906025	500	0	50	0.02	25.08
304	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:33.406679	500	0	50	0.02	25.08
305	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:33.406679	500	0	50	0.02	25.08
306	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:33.907686	501	0	50	0.02	25.08
307	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:33.907686	501	0	50	0.02	25.08
308	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:34.408129	500	0	50	0.02	25.08
309	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:34.408129	500	0	50	0.02	25.08
310	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:35.973421	500	0	50	0.02	25.08
311	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:35.973421	500	0	50	0.02	25.08
312	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:36.474014	500	0	50	0.02	25.08
313	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:36.474014	500	0	50	0.02	25.08
314	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:36.974841	500	0	50	0.02	25.08
315	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:36.974841	500	0	50	0.02	25.08
316	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:37.475521	500	0	50	0.02	25.08
317	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:37.475521	500	0	50	0.02	25.08
318	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:37.976299	500	0	50	0.02	25.08
319	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:37.976299	500	0	50	0.02	25.08
320	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:38.477411	501	0	50	0.02	25.08
321	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:38.477411	501	0	50	0.02	25.08
322	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:38.978385	500	0	50	0.02	25.08
323	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:38.978385	500	0	50	0.02	25.08
324	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:39.478986	500	0	50	0.02	25.08
325	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:39.478986	500	0	50	0.02	25.08
326	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:39.979403	500	0	50	0.02	25.08
327	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:39.979403	500	0	50	0.02	25.08
328	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:41.540587	500	0	30	1.41	25.56
329	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/users/1	2026-04-06 16:15:41.540587	500	0	30	1.41	25.56
330	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:42.04138	500	0	30	1.41	25.56
331	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://api-gateway:8080/api/orders/10	2026-04-06 16:15:42.04138	500	0	30	1.41	25.56
332	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:42.541676	500	0	30	1.41	25.56
333	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://order-service:8082/orders/10	2026-04-06 16:15:42.541676	500	0	30	1.41	25.56
334	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:43.0418	500	0	30	1.41	25.56
335	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://user-service:8081/users/1	2026-04-06 16:15:43.0418	500	0	30	1.41	25.56
336	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:43.542385	500	0	30	1.41	25.56
337	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://payment-service:8083/payments/10	2026-04-06 16:15:43.542385	500	0	30	1.41	25.56
338	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:44.042869	500	0	30	1.41	25.56
339	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://inventory-service:8084/inventory/A1	2026-04-06 16:15:44.042869	500	0	30	1.41	25.56
340	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:44.543382	500	0	30	1.41	25.56
341	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://shipping-service:8085/shipping/10	2026-04-06 16:15:44.543382	500	0	30	1.41	25.56
342	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:45.043596	500	0	30	1.41	25.56
343	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://notification-service:8086/notifications/10	2026-04-06 16:15:45.043596	500	0	30	1.41	25.56
344	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:45.544442	500	0	30	1.41	25.56
345	a98a50a9-f656-4e82-970c-0b0b2165b36e	http://recommendation-service:8087/recommendations/1	2026-04-06 16:15:45.544442	500	0	30	1.41	25.56
346	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:18.769319	500	0	0	0.01	25.26
347	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:18.769319	500	0	0	0.01	25.26
348	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:19.269996	500	0	0	0.01	25.26
349	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:19.269996	500	0	0	0.01	25.26
350	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:19.770413	500	0	0	0.01	25.26
351	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:19.770413	500	0	0	0.01	25.26
352	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:20.27088	500	0	0	0.01	25.26
353	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:20.27088	500	0	0	0.01	25.26
354	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:20.771542	500	0	0	0.01	25.26
355	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:20.771542	500	0	0	0.01	25.26
356	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:21.272502	500	0	0	0.01	25.26
357	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:21.272502	500	0	0	0.01	25.26
358	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:21.773787	501	0	0	0.01	25.26
359	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:21.773787	501	0	0	0.01	25.26
360	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:22.274464	500	0	0	0.01	25.26
361	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:22.274464	500	0	0	0.01	25.26
362	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:22.774621	500	0	0	0.01	25.26
363	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:22.774621	500	0	0	0.01	25.26
364	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:24.334065	501	0	0	0.02	25.26
365	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:24.334065	501	0	0	0.02	25.26
366	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:24.834208	500	0	0	0.02	25.26
367	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:24.834208	500	0	0	0.02	25.26
368	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:25.335094	500	0	0	0.02	25.26
369	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:25.335094	500	0	0	0.02	25.26
370	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:25.8358	500	0	0	0.02	25.26
371	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:25.8358	500	0	0	0.02	25.26
372	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:26.336297	500	0	0	0.02	25.26
373	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:26.336297	500	0	0	0.02	25.26
374	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:26.836746	500	0	0	0.02	25.26
375	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:26.836746	500	0	0	0.02	25.26
376	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:27.33723	500	0	0	0.02	25.26
377	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:27.33723	500	0	0	0.02	25.26
378	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:27.837691	500	0	50	0.02	25.26
379	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:27.837691	500	0	50	0.02	25.26
380	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:28.338539	500	0	50	0.02	25.26
381	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:28.338539	500	0	50	0.02	25.26
382	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:29.933464	500	0	50	0.02	25.72
383	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:29.933464	500	0	50	0.02	25.72
384	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:29.933464	500	0	50	0.02	25.72
385	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:30.433914	500	0	50	0.02	25.72
386	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:30.433914	500	0	50	0.02	25.72
387	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:30.433914	500	0	50	0.02	25.72
388	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:30.934087	500	0	50	0.02	25.72
389	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:30.934087	500	0	50	0.02	25.72
390	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:30.934087	500	0	50	0.02	25.72
391	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:31.43494	500	0	50	0.02	25.72
392	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:31.43494	500	0	50	0.02	25.72
393	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:31.43494	500	0	50	0.02	25.72
394	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:31.936133	501	0	50	0.02	25.72
395	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:31.936133	501	0	50	0.02	25.72
396	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:31.936133	501	0	50	0.02	25.72
397	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:32.43755	501	0	50	0.02	25.72
398	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:32.43755	501	0	50	0.02	25.72
399	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:32.43755	501	0	50	0.02	25.72
400	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:32.938316	500	0	50	0.02	25.72
401	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:32.938316	500	0	50	0.02	25.72
402	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:32.938316	500	0	50	0.02	25.72
403	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:33.439045	500	0	50	0.02	25.72
404	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:33.439045	500	0	50	0.02	25.72
405	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:33.439045	500	0	50	0.02	25.72
406	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:33.939897	500	0	50	0.02	25.72
407	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:33.939897	500	0	50	0.02	25.72
408	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:33.939897	500	0	50	0.02	25.72
409	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:35.558273	500	0	50	0.02	25.26
410	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:35.558273	500	0	50	0.02	25.26
411	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:36.058919	500	0	50	0.02	25.26
412	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:36.058919	500	0	50	0.02	25.26
413	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:36.559952	501	0	50	0.02	25.26
414	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:36.559952	501	0	50	0.02	25.26
415	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:37.060444	500	0	50	0.02	25.26
416	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:37.060444	500	0	50	0.02	25.26
417	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:37.560947	500	0	50	0.02	25.26
418	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:37.560947	500	0	50	0.02	25.26
419	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:38.061906	500	0	50	0.02	25.26
420	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:38.061906	500	0	50	0.02	25.26
421	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:38.562547	500	0	50	0.02	25.26
422	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:38.562547	500	0	50	0.02	25.26
423	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:39.062625	500	0	50	0.02	25.26
424	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:39.062625	500	0	50	0.02	25.26
425	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:39.563465	500	0	50	0.02	25.26
426	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:39.563465	500	0	50	0.02	25.26
427	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:41.12276	500	0	50	0.03	25.26
428	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:41.12276	500	0	50	0.03	25.26
429	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:41.623334	500	0	50	0.03	25.26
430	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:41.623334	500	0	50	0.03	25.26
431	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:42.124052	500	0	50	0.03	25.26
432	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:42.124052	500	0	50	0.03	25.26
433	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:42.624345	500	0	50	0.03	25.26
434	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:42.624345	500	0	50	0.03	25.26
435	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:43.124829	500	0	50	0.03	25.26
436	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:43.124829	500	0	50	0.03	25.26
437	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:43.62575	500	0	50	0.03	25.26
438	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:43.62575	500	0	50	0.03	25.26
439	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:44.126458	500	0	50	0.03	25.26
440	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:44.126458	500	0	50	0.03	25.26
441	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:44.627248	500	0	50	0.03	25.26
442	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:44.627248	500	0	50	0.03	25.26
443	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:45.1278	500	0	50	0.03	25.26
444	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:45.1278	500	0	50	0.03	25.26
445	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:46.692966	501	0	50	0.02	25.26
446	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:46.692966	501	0	50	0.02	25.26
447	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:47.193932	500	0	50	0.02	25.26
448	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:47.193932	500	0	50	0.02	25.26
449	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:47.694899	500	0	50	0.02	25.26
450	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:47.694899	500	0	50	0.02	25.26
451	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:48.195925	501	0	50	0.02	25.26
452	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:48.195925	501	0	50	0.02	25.26
453	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:48.696416	500	0	50	0.02	25.26
454	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:48.696416	500	0	50	0.02	25.26
455	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:49.197626	501	0	50	0.02	25.26
456	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:49.197626	501	0	50	0.02	25.26
457	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:49.69798	500	0	50	0.02	25.26
458	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:49.69798	500	0	50	0.02	25.26
459	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:50.198584	500	0	50	0.02	25.26
460	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:50.198584	500	0	50	0.02	25.26
461	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:50.69952	500	0	50	0.02	25.26
462	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:50.69952	500	0	50	0.02	25.26
463	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:52.251523	500	0	50	0.02	25.77
464	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:52.251523	500	0	50	0.02	25.77
465	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:52.752363	500	0	30	0.02	25.77
466	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:52.752363	500	0	30	0.02	25.77
467	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:53.252951	500	0	30	0.02	25.77
468	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://order-service:8082/orders/10	2026-04-06 19:44:53.252951	500	0	30	0.02	25.77
469	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:53.753471	500	0	30	0.02	25.77
470	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://user-service:8081/users/1	2026-04-06 19:44:53.753471	500	0	30	0.02	25.77
471	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:54.253988	500	0	30	0.02	25.77
472	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://payment-service:8083/payments/10	2026-04-06 19:44:54.253988	500	0	30	0.02	25.77
473	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:54.754623	500	0	30	0.02	25.77
474	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://inventory-service:8084/inventory/A1	2026-04-06 19:44:54.754623	500	0	30	0.02	25.77
475	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:55.255423	500	0	30	0.02	25.77
476	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://shipping-service:8085/shipping/10	2026-04-06 19:44:55.255423	500	0	30	0.02	25.77
477	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:55.755853	500	0	30	0.02	25.77
478	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://notification-service:8086/notifications/10	2026-04-06 19:44:55.755853	500	0	30	0.02	25.77
479	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:56.256369	500	0	30	0.02	25.77
480	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://recommendation-service:8087/recommendations/1	2026-04-06 19:44:56.256369	500	0	30	0.02	25.77
481	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:57.854925	500	0	30	0.02	25.61
482	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/users/1	2026-04-06 19:44:57.854925	500	0	30	0.02	25.61
483	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:58.355642	500	0	30	0.02	25.61
484	6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	http://api-gateway:8080/api/orders/10	2026-04-06 19:44:58.355642	500	0	30	0.02	25.61
485	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/users/1"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
486	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/users/1"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
487	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/orders/10"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
488	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/orders/10"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
489	50be69bb-0d99-4875-b756-eb541d3156cd	"http://order-service:8082/orders/10"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
490	50be69bb-0d99-4875-b756-eb541d3156cd	"http://order-service:8082/orders/10"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
491	50be69bb-0d99-4875-b756-eb541d3156cd	"http://user-service:8081/users/1"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
492	50be69bb-0d99-4875-b756-eb541d3156cd	"http://user-service:8081/users/1"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
493	50be69bb-0d99-4875-b756-eb541d3156cd	"http://payment-service:8083/payments/10"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
494	50be69bb-0d99-4875-b756-eb541d3156cd	"http://payment-service:8083/payments/10"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
495	50be69bb-0d99-4875-b756-eb541d3156cd	"http://inventory-service:8084/inventory/A1"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
496	50be69bb-0d99-4875-b756-eb541d3156cd	"http://inventory-service:8084/inventory/A1"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
497	50be69bb-0d99-4875-b756-eb541d3156cd	"http://shipping-service:8085/shipping/10"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
498	50be69bb-0d99-4875-b756-eb541d3156cd	"http://shipping-service:8085/shipping/10"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
499	50be69bb-0d99-4875-b756-eb541d3156cd	"http://notification-service:8086/notifications/10"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
500	50be69bb-0d99-4875-b756-eb541d3156cd	"http://notification-service:8086/notifications/10"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
501	50be69bb-0d99-4875-b756-eb541d3156cd	"http://recommendation-service:8087/recommendations/1"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
502	50be69bb-0d99-4875-b756-eb541d3156cd	"http://recommendation-service:8087/recommendations/1"	2026-04-08 20:50:47.13995	0	0	35	0.0125	23.32875
503	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/users/1"	2026-04-08 20:51:03.190883	0	0	62	0.8799999999999999	23.71125
504	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/orders/10"	2026-04-08 20:51:03.190883	0	0	62	0.8799999999999999	23.71125
505	50be69bb-0d99-4875-b756-eb541d3156cd	"http://order-service:8082/orders/10"	2026-04-08 20:51:03.190883	0	0	62	0.8799999999999999	23.71125
506	50be69bb-0d99-4875-b756-eb541d3156cd	"http://user-service:8081/users/1"	2026-04-08 20:51:03.190883	0	0	62	0.8799999999999999	23.71125
507	50be69bb-0d99-4875-b756-eb541d3156cd	"http://payment-service:8083/payments/10"	2026-04-08 20:51:03.190883	0	0	62	0.8799999999999999	23.71125
508	50be69bb-0d99-4875-b756-eb541d3156cd	"http://inventory-service:8084/inventory/A1"	2026-04-08 20:51:03.190883	0	0	62	0.8799999999999999	23.71125
509	50be69bb-0d99-4875-b756-eb541d3156cd	"http://shipping-service:8085/shipping/10"	2026-04-08 20:51:03.190883	0	0	62	0.8799999999999999	23.71125
510	50be69bb-0d99-4875-b756-eb541d3156cd	"http://notification-service:8086/notifications/10"	2026-04-08 20:51:03.190883	0	0	62	0.8799999999999999	23.71125
511	50be69bb-0d99-4875-b756-eb541d3156cd	"http://recommendation-service:8087/recommendations/1"	2026-04-08 20:51:03.190883	0	0	62	0.8799999999999999	23.71125
512	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/users/1"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
513	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/users/1"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
514	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/orders/10"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
515	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/orders/10"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
516	50be69bb-0d99-4875-b756-eb541d3156cd	"http://order-service:8082/orders/10"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
517	50be69bb-0d99-4875-b756-eb541d3156cd	"http://order-service:8082/orders/10"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
518	50be69bb-0d99-4875-b756-eb541d3156cd	"http://user-service:8081/users/1"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
519	50be69bb-0d99-4875-b756-eb541d3156cd	"http://user-service:8081/users/1"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
520	50be69bb-0d99-4875-b756-eb541d3156cd	"http://payment-service:8083/payments/10"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
521	50be69bb-0d99-4875-b756-eb541d3156cd	"http://payment-service:8083/payments/10"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
522	50be69bb-0d99-4875-b756-eb541d3156cd	"http://inventory-service:8084/inventory/A1"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
523	50be69bb-0d99-4875-b756-eb541d3156cd	"http://inventory-service:8084/inventory/A1"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
524	50be69bb-0d99-4875-b756-eb541d3156cd	"http://shipping-service:8085/shipping/10"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
525	50be69bb-0d99-4875-b756-eb541d3156cd	"http://shipping-service:8085/shipping/10"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
526	50be69bb-0d99-4875-b756-eb541d3156cd	"http://notification-service:8086/notifications/10"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
527	50be69bb-0d99-4875-b756-eb541d3156cd	"http://notification-service:8086/notifications/10"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
528	50be69bb-0d99-4875-b756-eb541d3156cd	"http://recommendation-service:8087/recommendations/1"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
529	50be69bb-0d99-4875-b756-eb541d3156cd	"http://recommendation-service:8087/recommendations/1"	2026-04-08 20:51:19.273125	0	0	68	0.4025	23.6925
530	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/users/1"	2026-04-08 20:51:35.274001	0	0	69	0.3899999999999999	23.62875
531	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/orders/10"	2026-04-08 20:51:35.274001	0	0	69	0.3899999999999999	23.62875
532	50be69bb-0d99-4875-b756-eb541d3156cd	"http://order-service:8082/orders/10"	2026-04-08 20:51:35.274001	0	0	69	0.3899999999999999	23.62875
533	50be69bb-0d99-4875-b756-eb541d3156cd	"http://user-service:8081/users/1"	2026-04-08 20:51:35.274001	0	0	69	0.3899999999999999	23.62875
534	50be69bb-0d99-4875-b756-eb541d3156cd	"http://payment-service:8083/payments/10"	2026-04-08 20:51:35.274001	0	0	69	0.3899999999999999	23.62875
535	50be69bb-0d99-4875-b756-eb541d3156cd	"http://inventory-service:8084/inventory/A1"	2026-04-08 20:51:35.274001	0	0	69	0.3899999999999999	23.62875
536	50be69bb-0d99-4875-b756-eb541d3156cd	"http://shipping-service:8085/shipping/10"	2026-04-08 20:51:35.274001	0	0	69	0.3899999999999999	23.62875
537	50be69bb-0d99-4875-b756-eb541d3156cd	"http://notification-service:8086/notifications/10"	2026-04-08 20:51:35.274001	0	0	69	0.3899999999999999	23.62875
538	50be69bb-0d99-4875-b756-eb541d3156cd	"http://recommendation-service:8087/recommendations/1"	2026-04-08 20:51:35.274001	0	0	69	0.3899999999999999	23.62875
539	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/users/1"	2026-04-08 20:51:51.316829	0	0	70	0.45249999999999996	23.757499999999997
540	50be69bb-0d99-4875-b756-eb541d3156cd	"http://api-gateway:8080/api/orders/10"	2026-04-08 20:51:51.316829	0	0	70	0.45249999999999996	23.757499999999997
541	50be69bb-0d99-4875-b756-eb541d3156cd	"http://order-service:8082/orders/10"	2026-04-08 20:51:51.316829	0	0	70	0.45249999999999996	23.757499999999997
542	50be69bb-0d99-4875-b756-eb541d3156cd	"http://user-service:8081/users/1"	2026-04-08 20:51:51.316829	0	0	70	0.45249999999999996	23.757499999999997
543	50be69bb-0d99-4875-b756-eb541d3156cd	"http://payment-service:8083/payments/10"	2026-04-08 20:51:51.316829	0	0	70	0.45249999999999996	23.757499999999997
544	50be69bb-0d99-4875-b756-eb541d3156cd	"http://inventory-service:8084/inventory/A1"	2026-04-08 20:51:51.316829	0	0	70	0.45249999999999996	23.757499999999997
545	50be69bb-0d99-4875-b756-eb541d3156cd	"http://shipping-service:8085/shipping/10"	2026-04-08 20:51:51.316829	0	0	70	0.45249999999999996	23.757499999999997
546	50be69bb-0d99-4875-b756-eb541d3156cd	"http://notification-service:8086/notifications/10"	2026-04-08 20:51:51.316829	0	0	70	0.45249999999999996	23.757499999999997
547	50be69bb-0d99-4875-b756-eb541d3156cd	"http://recommendation-service:8087/recommendations/1"	2026-04-08 20:51:51.316829	0	0	70	0.45249999999999996	23.757499999999997
548	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
549	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
550	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
551	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
552	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
553	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
554	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
555	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
556	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
557	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
558	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
559	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
560	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
561	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
562	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
563	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
564	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
565	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:42:28.36929	0	0	40	0.014999999999999998	23.38625
566	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:42:34.384292	0	0	60	0.00625	9.6225
567	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:42:34.384292	0	0	60	0.00625	9.6225
568	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:42:34.384292	0	0	60	0.00625	9.6225
569	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:42:34.384292	0	0	60	0.00625	9.6225
570	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:42:34.384292	0	0	60	0.00625	9.6225
571	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:42:34.384292	0	0	60	0.00625	9.6225
572	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:42:34.384292	0	0	60	0.00625	9.6225
573	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:42:34.384292	0	0	60	0.00625	9.6225
574	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:42:34.384292	0	0	60	0.00625	9.6225
575	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
576	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
577	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
578	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
579	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
580	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
581	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
582	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
583	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
584	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
585	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
586	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
587	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
588	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
589	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
590	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
591	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
592	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:42:36.390775	0	0	60	0.0025	3.6125
593	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:42:38.401243	0	0	60	0	0
594	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:42:38.401243	0	0	60	0	0
595	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:42:38.401243	0	0	60	0	0
596	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:42:38.401243	0	0	60	0	0
597	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:42:38.401243	0	0	60	0	0
598	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:42:38.401243	0	0	60	0	0
599	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:42:38.401243	0	0	60	0	0
600	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:42:38.401243	0	0	60	0	0
601	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:42:38.401243	0	0	60	0	0
602	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:42:38.738625	0	0	60	0	0
603	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:42:38.738625	0	0	60	0	0
604	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:42:38.738625	0	0	60	0	0
605	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:42:38.738625	0	0	60	0	0
606	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:42:38.738625	0	0	60	0	0
607	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:42:38.738625	0	0	60	0	0
608	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:42:38.738625	0	0	60	0	0
609	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:42:38.738625	0	0	60	0	0
610	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:42:38.738625	0	0	60	0	0
611	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:42:39.111218	0	0	70	0	0
612	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:42:39.111218	0	0	70	0	0
613	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:42:39.111218	0	0	70	0	0
614	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:42:39.111218	0	0	70	0	0
615	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:42:39.111218	0	0	70	0	0
616	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:42:39.111218	0	0	70	0	0
617	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:42:39.111218	0	0	70	0	0
618	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:42:39.111218	0	0	70	0	0
619	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:42:39.111218	0	0	70	0	0
620	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:42:39.634197	0	0	70	0	0
621	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:42:39.634197	0	0	70	0	0
622	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:42:39.634197	0	0	70	0	0
623	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:42:39.634197	0	0	70	0	0
624	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:42:39.634197	0	0	70	0	0
625	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:42:39.634197	0	0	70	0	0
626	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:42:39.634197	0	0	70	0	0
627	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:42:39.634197	0	0	70	0	0
628	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:42:39.634197	0	0	70	0	0
629	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:42:40.082741	0	0	70	0	0
630	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:42:40.082741	0	0	70	0	0
631	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:42:40.082741	0	0	70	0	0
632	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:42:40.082741	0	0	70	0	0
633	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:42:40.082741	0	0	70	0	0
634	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:42:40.082741	0	0	70	0	0
635	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:42:40.082741	0	0	70	0	0
636	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:42:40.082741	0	0	70	0	0
637	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:42:40.082741	0	0	70	0	0
638	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:42:40.59644	0	0	70	0	0
639	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:42:40.59644	0	0	70	0	0
640	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:42:40.59644	0	0	70	0	0
641	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:42:40.59644	0	0	70	0	0
642	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:42:40.59644	0	0	70	0	0
643	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:42:40.59644	0	0	70	0	0
644	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:42:40.59644	0	0	70	0	0
645	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:42:40.59644	0	0	70	0	0
646	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:42:40.59644	0	0	70	0	0
647	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:42:55.860871	0	0	75	1.9499999999999997	22.736250000000002
648	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:42:55.860871	0	0	75	1.9499999999999997	22.736250000000002
649	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:42:55.860871	0	0	75	1.9499999999999997	22.736250000000002
650	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:42:55.860871	0	0	75	1.9499999999999997	22.736250000000002
651	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:42:55.860871	0	0	75	1.9499999999999997	22.736250000000002
652	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:42:55.860871	0	0	75	1.9499999999999997	22.736250000000002
653	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:42:55.860871	0	0	75	1.9499999999999997	22.736250000000002
654	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:42:55.860871	0	0	75	1.9499999999999997	22.736250000000002
655	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:42:55.860871	0	0	75	1.9499999999999997	22.736250000000002
656	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:43:03.883824	0	0	78	0.00875	11.405000000000001
657	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:43:03.883824	0	0	78	0.00875	11.405000000000001
658	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:43:03.883824	0	0	78	0.00875	11.405000000000001
659	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:43:03.883824	0	0	78	0.00875	11.405000000000001
660	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:43:03.883824	0	0	78	0.00875	11.405000000000001
661	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:43:03.883824	0	0	78	0.00875	11.405000000000001
662	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:43:03.883824	0	0	78	0.00875	11.405000000000001
663	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:43:03.883824	0	0	78	0.00875	11.405000000000001
664	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:43:03.883824	0	0	78	0.00875	11.405000000000001
665	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:43:07.899736	0	0	78	0.04125	0.1685
666	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:43:07.899736	0	0	78	0.04125	0.1685
667	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:43:07.899736	0	0	78	0.04125	0.1685
668	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:43:07.899736	0	0	78	0.04125	0.1685
669	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:43:07.899736	0	0	78	0.04125	0.1685
670	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:43:07.899736	0	0	78	0.04125	0.1685
671	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:43:07.899736	0	0	78	0.04125	0.1685
672	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:43:07.899736	0	0	78	0.04125	0.1685
673	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:43:07.899736	0	0	78	0.04125	0.1685
674	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:43:08.233764	0	0	78	0	0
675	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:43:08.233764	0	0	78	0	0
676	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:43:08.233764	0	0	78	0	0
677	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:43:08.233764	0	0	78	0	0
678	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:43:08.233764	0	0	78	0	0
679	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:43:08.233764	0	0	78	0	0
680	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:43:08.233764	0	0	78	0	0
681	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:43:08.233764	0	0	78	0	0
682	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:43:08.233764	0	0	78	0	0
683	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:43:08.595301	0	0	78	0	0
684	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:43:08.595301	0	0	78	0	0
685	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:43:08.595301	0	0	78	0	0
686	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:43:08.595301	0	0	78	0	0
687	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:43:08.595301	0	0	78	0	0
688	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:43:08.595301	0	0	78	0	0
689	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:43:08.595301	0	0	78	0	0
690	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:43:08.595301	0	0	78	0	0
691	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:43:08.595301	0	0	78	0	0
692	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:43:09.09489	0	0	79	0	0
693	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:43:09.09489	0	0	79	0	0
694	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:43:09.09489	0	0	79	0	0
695	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:43:09.09489	0	0	79	0	0
696	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:43:09.09489	0	0	79	0	0
697	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:43:09.09489	0	0	79	0	0
698	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:43:09.09489	0	0	79	0	0
699	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:43:09.09489	0	0	79	0	0
700	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:43:09.09489	0	0	79	0	0
701	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:43:09.601731	0	0	79	0	0
702	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:43:09.601731	0	0	79	0	0
703	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:43:09.601731	0	0	79	0	0
704	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:43:09.601731	0	0	79	0	0
705	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:43:09.601731	0	0	79	0	0
706	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:43:09.601731	0	0	79	0	0
707	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:43:09.601731	0	0	79	0	0
708	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:43:09.601731	0	0	79	0	0
709	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:43:09.601731	0	0	79	0	0
710	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:43:10.111847	0	0	79	0	0
711	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:43:10.112394	0	0	79	0	0
712	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:43:10.112394	0	0	79	0	0
713	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:43:10.112394	0	0	79	0	0
714	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:43:10.112394	0	0	79	0	0
715	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:43:10.112394	0	0	79	0	0
716	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:43:10.112394	0	0	79	0	0
717	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:43:10.112394	0	0	79	0	0
718	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:43:10.112394	0	0	79	0	0
719	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:43:10.585119	0	0	79	0	0
720	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:43:10.585119	0	0	79	0	0
721	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:43:10.585119	0	0	79	0	0
722	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:43:10.585119	0	0	79	0	0
723	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:43:10.585119	0	0	79	0	0
724	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:43:10.585119	0	0	79	0	0
725	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:43:10.585119	0	0	79	0	0
726	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:43:10.585119	0	0	79	0	0
727	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:43:10.585119	0	0	79	0	0
728	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:43:25.8722	0	0	80	0.01875	22.1075
729	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:43:25.8722	0	0	80	0.01875	22.1075
730	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:43:25.8722	0	0	80	0.01875	22.1075
731	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:43:25.8722	0	0	80	0.01875	22.1075
732	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:43:25.8722	0	0	80	0.01875	22.1075
733	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:43:25.8722	0	0	80	0.01875	22.1075
734	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:43:25.8722	0	0	80	0.01875	22.1075
735	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:43:25.8722	0	0	80	0.01875	22.1075
736	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:43:25.8722	0	0	80	0.01875	22.1075
737	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/users/1"	2026-04-08 22:43:33.902558	0	0	80	0.01625	11.37125
738	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:43:33.902558	0	0	80	0.01625	11.37125
739	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://order-service:8082/orders/10"	2026-04-08 22:43:33.902558	0	0	80	0.01625	11.37125
740	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://user-service:8081/users/1"	2026-04-08 22:43:33.902558	0	0	80	0.01625	11.37125
741	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://payment-service:8083/payments/10"	2026-04-08 22:43:33.902558	0	0	80	0.01625	11.37125
742	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:43:33.902558	0	0	80	0.01625	11.37125
743	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://shipping-service:8085/shipping/10"	2026-04-08 22:43:33.903093	0	0	80	0.01625	11.37125
744	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://notification-service:8086/notifications/10"	2026-04-08 22:43:33.903093	0	0	80	0.01625	11.37125
745	fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:43:33.903093	0	0	80	0.01625	11.37125
746	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
747	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
748	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
749	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
750	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
751	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
752	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
753	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
754	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
755	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
756	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
757	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
758	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
759	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
760	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
761	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
762	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
763	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:50:29.253631	0	0	50	0.01875	22.86125
764	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:50:35.265657	0	0	75	0.00375	9.035
765	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:50:35.265657	0	0	75	0.00375	9.035
766	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:50:35.265657	0	0	75	0.00375	9.035
767	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:50:35.265657	0	0	75	0.00375	9.035
768	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:50:35.265657	0	0	75	0.00375	9.035
769	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:50:35.265657	0	0	75	0.00375	9.035
770	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:50:35.265657	0	0	75	0.00375	9.035
771	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:50:35.265657	0	0	75	0.00375	9.035
772	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:50:35.265657	0	0	75	0.00375	9.035
773	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
774	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
775	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
776	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
777	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
778	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
779	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
780	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
781	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
782	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
783	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
784	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
785	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
786	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
787	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
788	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
789	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
790	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:50:37.280681	0	0	75	0.0025	3.01375
791	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:50:39.273496	0	0	75	0	0
792	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:50:39.273496	0	0	75	0	0
793	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:50:39.273496	0	0	75	0	0
794	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:50:39.273496	0	0	75	0	0
795	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:50:39.273496	0	0	75	0	0
796	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:50:39.273496	0	0	75	0	0
797	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:50:39.273496	0	0	75	0	0
798	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:50:39.273496	0	0	75	0	0
799	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:50:39.273496	0	0	75	0	0
800	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:50:39.615806	0	0	75	0	0
801	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:50:39.615806	0	0	75	0	0
802	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:50:39.615806	0	0	75	0	0
803	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:50:39.615806	0	0	75	0	0
804	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:50:39.615806	0	0	75	0	0
805	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:50:39.615806	0	0	75	0	0
806	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:50:39.615806	0	0	75	0	0
807	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:50:39.615806	0	0	75	0	0
808	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:50:39.615806	0	0	75	0	0
809	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:50:40.01671	0	0	88	0	0
810	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:50:40.01671	0	0	88	0	0
811	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:50:40.01671	0	0	88	0	0
812	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:50:40.01671	0	0	88	0	0
813	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:50:40.01671	0	0	88	0	0
814	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:50:40.01671	0	0	88	0	0
815	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:50:40.01671	0	0	88	0	0
816	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:50:40.01671	0	0	88	0	0
817	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:50:40.01671	0	0	88	0	0
818	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:50:40.520848	0	0	88	0	0
819	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:50:40.520848	0	0	88	0	0
820	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:50:40.520848	0	0	88	0	0
821	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:50:40.520848	0	0	88	0	0
822	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:50:40.520848	0	0	88	0	0
823	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:50:40.520848	0	0	88	0	0
824	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:50:40.520848	0	0	88	0	0
825	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:50:40.520848	0	0	88	0	0
826	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:50:40.520848	0	0	88	0	0
827	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:50:41.007584	0	0	88	0	0
828	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:50:41.007584	0	0	88	0	0
829	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:50:41.007584	0	0	88	0	0
830	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:50:41.007584	0	0	88	0	0
831	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:50:41.007584	0	0	88	0	0
832	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:50:41.007584	0	0	88	0	0
833	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:50:41.007584	0	0	88	0	0
834	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:50:41.007584	0	0	88	0	0
835	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:50:41.007584	0	0	88	0	0
836	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:50:41.514613	0	0	88	0	0
837	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:50:41.514613	0	0	88	0	0
838	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:50:41.514613	0	0	88	0	0
839	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:50:41.514613	0	0	88	0	0
840	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:50:41.514613	0	0	88	0	0
841	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:50:41.514613	0	0	88	0	0
842	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:50:41.514613	0	0	88	0	0
843	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:50:41.514613	0	0	88	0	0
844	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:50:41.514613	0	0	88	0	0
845	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:50:56.767622	0	0	94	0.01625	22.1125
846	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:50:56.767622	0	0	94	0.01625	22.1125
847	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:50:56.767622	0	0	94	0.01625	22.1125
848	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:50:56.767622	0	0	94	0.01625	22.1125
849	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:50:56.767622	0	0	94	0.01625	22.1125
850	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:50:56.767622	0	0	94	0.01625	22.1125
851	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:50:56.767622	0	0	94	0.01625	22.1125
852	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:50:56.767622	0	0	94	0.01625	22.1125
853	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:50:56.767622	0	0	94	0.01625	22.1125
854	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:51:04.797739	0	0	97	0.01	11.37875
855	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:51:04.797739	0	0	97	0.01	11.37875
856	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:51:04.797739	0	0	97	0.01	11.37875
857	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:51:04.797739	0	0	97	0.01	11.37875
858	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:51:04.797739	0	0	97	0.01	11.37875
859	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:51:04.797739	0	0	97	0.01	11.37875
860	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:51:04.797739	0	0	97	0.01	11.37875
861	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:51:04.797739	0	0	97	0.01	11.37875
862	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:51:04.797739	0	0	97	0.01	11.37875
863	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:51:09.03446	0	0	97	0	0
864	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:51:09.03446	0	0	97	0	0
865	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:51:09.03446	0	0	97	0	0
866	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:51:09.03446	0	0	97	0	0
867	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:51:09.03446	0	0	97	0	0
868	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:51:09.03446	0	0	97	0	0
869	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:51:09.03446	0	0	97	0	0
870	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:51:09.03446	0	0	97	0	0
871	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:51:09.03446	0	0	97	0	0
872	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:51:09.378524	0	0	97	0	0
873	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:51:09.378524	0	0	97	0	0
874	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:51:09.378524	0	0	97	0	0
875	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:51:09.378524	0	0	97	0	0
876	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:51:09.378524	0	0	97	0	0
877	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:51:09.378524	0	0	97	0	0
878	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:51:09.378524	0	0	97	0	0
879	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:51:09.378524	0	0	97	0	0
880	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:51:09.378524	0	0	97	0	0
881	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:51:09.714909	0	0	99	0	0
882	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:51:09.714909	0	0	99	0	0
883	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:51:09.714909	0	0	99	0	0
884	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:51:09.714909	0	0	99	0	0
885	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:51:09.714909	0	0	99	0	0
886	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:51:09.714909	0	0	99	0	0
887	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:51:09.714909	0	0	99	0	0
888	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:51:09.714909	0	0	99	0	0
889	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:51:09.714909	0	0	99	0	0
890	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:51:10.052605	0	0	99	0	0
891	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:51:10.052605	0	0	99	0	0
892	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:51:10.052605	0	0	99	0	0
893	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:51:10.052605	0	0	99	0	0
894	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:51:10.052605	0	0	99	0	0
895	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:51:10.052605	0	0	99	0	0
896	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:51:10.052605	0	0	99	0	0
897	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:51:10.052605	0	0	99	0	0
898	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:51:10.052605	0	0	99	0	0
899	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:51:10.519304	0	0	99	0	0
900	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:51:10.519304	0	0	99	0	0
901	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:51:10.519304	0	0	99	0	0
902	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:51:10.519304	0	0	99	0	0
903	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:51:10.519304	0	0	99	0	0
904	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:51:10.519304	0	0	99	0	0
905	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:51:10.519304	0	0	99	0	0
906	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:51:10.519304	0	0	99	0	0
907	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:51:10.519304	0	0	99	0	0
908	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:51:10.997009	0	0	99	0	0
909	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:51:10.997009	0	0	99	0	0
910	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:51:10.997009	0	0	99	0	0
911	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:51:10.997009	0	0	99	0	0
912	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:51:10.997009	0	0	99	0	0
913	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:51:10.997009	0	0	99	0	0
914	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:51:10.997009	0	0	99	0	0
915	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:51:10.997009	0	0	99	0	0
916	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:51:10.997009	0	0	99	0	0
917	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/users/1"	2026-04-08 22:51:26.349081	0	0	100	1.6949999999999998	22.10875
918	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://api-gateway:8080/api/orders/10"	2026-04-08 22:51:26.349081	0	0	100	1.6949999999999998	22.10875
919	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://order-service:8082/orders/10"	2026-04-08 22:51:26.349081	0	0	100	1.6949999999999998	22.10875
920	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://user-service:8081/users/1"	2026-04-08 22:51:26.349081	0	0	100	1.6949999999999998	22.10875
921	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://payment-service:8083/payments/10"	2026-04-08 22:51:26.349081	0	0	100	1.6949999999999998	22.10875
922	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://inventory-service:8084/inventory/A1"	2026-04-08 22:51:26.349081	0	0	100	1.6949999999999998	22.10875
923	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://shipping-service:8085/shipping/10"	2026-04-08 22:51:26.349081	0	0	100	1.6949999999999998	22.10875
924	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://notification-service:8086/notifications/10"	2026-04-08 22:51:26.349081	0	0	100	1.6949999999999998	22.10875
925	8ccb8c63-1dfb-4513-857a-62886761cec2	"http://recommendation-service:8087/recommendations/1"	2026-04-08 22:51:26.349081	0	0	100	1.6949999999999998	22.10875
926	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
927	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
928	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
929	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
930	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
931	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
932	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
933	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
934	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
935	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
936	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
937	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
938	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
939	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
940	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
941	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
942	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
943	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:05:58.389295	0	0	50	0.019999999999999997	22.10125
944	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:04.417313	0	0	75	0.00625	9.01125
945	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:04.417313	0	0	75	0.00625	9.01125
946	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:04.417313	0	0	75	0.00625	9.01125
947	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:04.417313	0	0	75	0.00625	9.01125
948	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:04.417313	0	0	75	0.00625	9.01125
949	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:04.417313	0	0	75	0.00625	9.01125
950	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:04.417313	0	0	75	0.00625	9.01125
951	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:04.417313	0	0	75	0.00625	9.01125
952	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:04.417313	0	0	75	0.00625	9.01125
953	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
954	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
955	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
956	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
957	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
958	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
959	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
960	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
961	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
962	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
963	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
964	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
965	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
966	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
967	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
968	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
969	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
970	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:06.422376	0	0	75	0.00375	3.00625
971	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:08.42787	0	0	75	0	0
972	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:08.42787	0	0	75	0	0
973	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:08.42787	0	0	75	0	0
974	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:08.42787	0	0	75	0	0
975	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:08.42787	0	0	75	0	0
976	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:08.42787	0	0	75	0	0
977	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:08.42787	0	0	75	0	0
978	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:08.42787	0	0	75	0	0
979	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:08.42787	0	0	75	0	0
980	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:08.735679	0	0	75	0	0
981	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:08.735679	0	0	75	0	0
982	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:08.735679	0	0	75	0	0
983	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:08.735679	0	0	75	0	0
984	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:08.735679	0	0	75	0	0
985	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:08.735679	0	0	75	0	0
986	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:08.735679	0	0	75	0	0
987	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:08.735679	0	0	75	0	0
988	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:08.735679	0	0	75	0	0
989	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:09.105252	0	0	88	0	0
990	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:09.105252	0	0	88	0	0
991	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:09.105252	0	0	88	0	0
992	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:09.105252	0	0	88	0	0
993	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:09.105252	0	0	88	0	0
994	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:09.105252	0	0	88	0	0
995	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:09.105252	0	0	88	0	0
996	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:09.105252	0	0	88	0	0
997	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:09.105252	0	0	88	0	0
998	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:09.602385	0	0	88	0	0
999	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:09.602385	0	0	88	0	0
1000	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:09.602385	0	0	88	0	0
1001	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:09.602385	0	0	88	0	0
1002	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:09.602385	0	0	88	0	0
1003	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:09.602385	0	0	88	0	0
1004	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:09.602385	0	0	88	0	0
1005	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:09.602385	0	0	88	0	0
1006	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:09.602385	0	0	88	0	0
1007	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:10.107156	0	0	88	0	0
1008	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:10.107156	0	0	88	0	0
1009	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:10.107156	0	0	88	0	0
1010	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:10.107156	0	0	88	0	0
1011	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:10.107156	0	0	88	0	0
1012	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:10.107156	0	0	88	0	0
1013	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:10.107156	0	0	88	0	0
1014	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:10.107156	0	0	88	0	0
1015	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:10.107156	0	0	88	0	0
1016	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:25.453283	0	0	94	2.0775000000000006	22.7575
1017	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:25.453283	0	0	94	2.0775000000000006	22.7575
1018	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:25.453283	0	0	94	2.0775000000000006	22.7575
1019	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:25.453283	0	0	94	2.0775000000000006	22.7575
1020	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:25.453283	0	0	94	2.0775000000000006	22.7575
1021	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:25.453283	0	0	94	2.0775000000000006	22.7575
1022	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:25.453283	0	0	94	2.0775000000000006	22.7575
1023	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:25.453283	0	0	94	2.0775000000000006	22.7575
1024	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:25.453283	0	0	94	2.0775000000000006	22.7575
1025	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:35.665543	0	0	97	0.005	6.0287500000000005
1026	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:35.665543	0	0	97	0.005	6.0287500000000005
1027	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:35.665543	0	0	97	0.005	6.0287500000000005
1028	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:35.665543	0	0	97	0.005	6.0287500000000005
1029	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:35.665543	0	0	97	0.005	6.0287500000000005
1030	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:35.665543	0	0	97	0.005	6.0287500000000005
1031	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:35.665543	0	0	97	0.005	6.0287500000000005
1032	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:35.665543	0	0	97	0.005	6.0287500000000005
1033	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:35.665543	0	0	97	0.005	6.0287500000000005
1034	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:37.669934	0	0	97	0.00125	3.015
1035	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:37.669934	0	0	97	0.00125	3.015
1036	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:37.669934	0	0	97	0.00125	3.015
1037	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:37.669934	0	0	97	0.00125	3.015
1038	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:37.669934	0	0	97	0.00125	3.015
1039	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:37.669934	0	0	97	0.00125	3.015
1040	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:37.669934	0	0	97	0.00125	3.015
1041	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:37.669934	0	0	97	0.00125	3.015
1042	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:37.669934	0	0	97	0.00125	3.015
1043	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:38.168588	0	0	97	0	0
1044	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:38.168588	0	0	97	0	0
1045	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:38.168588	0	0	97	0	0
1046	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:38.168588	0	0	97	0	0
1047	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:38.168588	0	0	97	0	0
1048	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:38.168588	0	0	97	0	0
1049	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:38.168588	0	0	97	0	0
1050	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:38.168588	0	0	97	0	0
1051	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:38.168588	0	0	97	0	0
1052	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:38.478343	0	0	97	0	0
1053	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:38.478343	0	0	97	0	0
1054	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:38.478343	0	0	97	0	0
1055	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:38.478343	0	0	97	0	0
1056	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:38.478343	0	0	97	0	0
1057	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:38.478343	0	0	97	0	0
1058	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:38.478343	0	0	97	0	0
1059	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:38.478343	0	0	97	0	0
1060	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:38.478343	0	0	97	0	0
1061	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:38.781345	0	0	97	0	0
1062	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:38.781345	0	0	97	0	0
1063	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:38.781345	0	0	97	0	0
1064	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:38.781345	0	0	97	0	0
1065	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:38.781345	0	0	97	0	0
1066	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:38.781345	0	0	97	0	0
1067	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:38.781345	0	0	97	0	0
1068	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:38.781345	0	0	97	0	0
1069	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:38.781345	0	0	97	0	0
1070	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:39.109268	0	0	99	0	0
1071	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:39.109268	0	0	99	0	0
1072	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:39.109268	0	0	99	0	0
1073	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:39.109268	0	0	99	0	0
1074	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:39.109268	0	0	99	0	0
1075	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:39.109268	0	0	99	0	0
1076	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:39.109268	0	0	99	0	0
1077	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:39.109268	0	0	99	0	0
1078	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:39.109268	0	0	99	0	0
1079	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:39.615747	0	0	99	0	0
1080	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:39.615747	0	0	99	0	0
1081	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:39.615747	0	0	99	0	0
1082	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:39.615747	0	0	99	0	0
1083	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:39.615747	0	0	99	0	0
1084	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:39.615747	0	0	99	0	0
1085	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:39.615747	0	0	99	0	0
1086	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:39.615747	0	0	99	0	0
1087	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:39.615747	0	0	99	0	0
1088	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:40.11587	0	0	99	0	0
1089	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:40.11587	0	0	99	0	0
1090	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:40.11587	0	0	99	0	0
1091	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:40.11587	0	0	99	0	0
1092	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:40.11587	0	0	99	0	0
1093	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:40.11587	0	0	99	0	0
1094	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:40.11587	0	0	99	0	0
1095	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:40.11587	0	0	99	0	0
1096	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:40.11587	0	0	99	0	0
1097	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/users/1"	2026-04-08 23:06:55.512159	0	0	100	1.5849999999999995	22.10875
1098	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://api-gateway:8080/api/orders/10"	2026-04-08 23:06:55.512159	0	0	100	1.5849999999999995	22.10875
1099	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://order-service:8082/orders/10"	2026-04-08 23:06:55.512159	0	0	100	1.5849999999999995	22.10875
1100	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://user-service:8081/users/1"	2026-04-08 23:06:55.512159	0	0	100	1.5849999999999995	22.10875
1101	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://payment-service:8083/payments/10"	2026-04-08 23:06:55.512159	0	0	100	1.5849999999999995	22.10875
1102	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://inventory-service:8084/inventory/A1"	2026-04-08 23:06:55.512159	0	0	100	1.5849999999999995	22.10875
1103	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://shipping-service:8085/shipping/10"	2026-04-08 23:06:55.512159	0	0	100	1.5849999999999995	22.10875
1104	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://notification-service:8086/notifications/10"	2026-04-08 23:06:55.512159	0	0	100	1.5849999999999995	22.10875
1105	d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	"http://recommendation-service:8087/recommendations/1"	2026-04-08 23:06:55.512159	0	0	100	1.5849999999999995	22.10875
1106	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/users/1"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1107	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/users/1"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1108	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/orders/10"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1109	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/orders/10"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1110	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://order-service:8082/orders/10"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1111	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://order-service:8082/orders/10"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1112	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://user-service:8081/users/1"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1113	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://user-service:8081/users/1"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1114	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://payment-service:8083/payments/10"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1115	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://payment-service:8083/payments/10"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1116	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://inventory-service:8084/inventory/A1"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1117	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://inventory-service:8084/inventory/A1"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1118	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://shipping-service:8085/shipping/10"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1119	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://shipping-service:8085/shipping/10"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1120	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://notification-service:8086/notifications/10"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1121	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://notification-service:8086/notifications/10"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1122	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://recommendation-service:8087/recommendations/1"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1123	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://recommendation-service:8087/recommendations/1"	2026-04-13 21:52:44.545715	0	0	50	0.0175	22.133749999999996
1124	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/users/1"	2026-04-13 21:53:00.584176	0	0	88	0.44375	22.43625
1125	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/orders/10"	2026-04-13 21:53:00.584176	0	0	88	0.44375	22.43625
1126	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://order-service:8082/orders/10"	2026-04-13 21:53:00.584176	0	0	88	0.44375	22.43625
1127	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://user-service:8081/users/1"	2026-04-13 21:53:00.584176	0	0	88	0.44375	22.43625
1128	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://payment-service:8083/payments/10"	2026-04-13 21:53:00.584176	0	0	88	0.44375	22.43625
1129	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://inventory-service:8084/inventory/A1"	2026-04-13 21:53:00.584176	0	0	88	0.44375	22.43625
1130	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://shipping-service:8085/shipping/10"	2026-04-13 21:53:00.584176	0	0	88	0.44375	22.43625
1131	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://notification-service:8086/notifications/10"	2026-04-13 21:53:00.584176	0	0	88	0.44375	22.43625
1132	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://recommendation-service:8087/recommendations/1"	2026-04-13 21:53:00.584176	0	0	88	0.44375	22.43625
1133	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/users/1"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1134	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/users/1"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1135	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/orders/10"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1136	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/orders/10"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1137	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://order-service:8082/orders/10"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1138	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://order-service:8082/orders/10"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1139	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://user-service:8081/users/1"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1140	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://user-service:8081/users/1"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1141	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://payment-service:8083/payments/10"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1142	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://payment-service:8083/payments/10"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1143	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://inventory-service:8084/inventory/A1"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1144	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://inventory-service:8084/inventory/A1"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1145	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://shipping-service:8085/shipping/10"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1146	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://shipping-service:8085/shipping/10"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1147	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://notification-service:8086/notifications/10"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1148	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://notification-service:8086/notifications/10"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1149	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://recommendation-service:8087/recommendations/1"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1150	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://recommendation-service:8087/recommendations/1"	2026-04-13 21:53:16.62961	0	0	97	0.5525	22.556250000000002
1151	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/users/1"	2026-04-13 21:53:32.670688	0	0	99	0.45249999999999985	22.447499999999998
1152	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/orders/10"	2026-04-13 21:53:32.670688	0	0	99	0.45249999999999985	22.447499999999998
1153	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://order-service:8082/orders/10"	2026-04-13 21:53:32.670688	0	0	99	0.45249999999999985	22.447499999999998
1154	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://user-service:8081/users/1"	2026-04-13 21:53:32.670688	0	0	99	0.45249999999999985	22.447499999999998
1155	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://payment-service:8083/payments/10"	2026-04-13 21:53:32.670688	0	0	99	0.45249999999999985	22.447499999999998
1156	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://inventory-service:8084/inventory/A1"	2026-04-13 21:53:32.670688	0	0	99	0.45249999999999985	22.447499999999998
1157	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://shipping-service:8085/shipping/10"	2026-04-13 21:53:32.670688	0	0	99	0.45249999999999985	22.447499999999998
1158	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://notification-service:8086/notifications/10"	2026-04-13 21:53:32.670688	0	0	99	0.45249999999999985	22.447499999999998
1159	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://recommendation-service:8087/recommendations/1"	2026-04-13 21:53:32.670688	0	0	99	0.45249999999999985	22.447499999999998
1160	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/users/1"	2026-04-13 21:53:48.714983	0	0	100	0.5962499999999998	22.4975
1161	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://api-gateway:8080/api/orders/10"	2026-04-13 21:53:48.714983	0	0	100	0.5962499999999998	22.4975
1162	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://order-service:8082/orders/10"	2026-04-13 21:53:48.714983	0	0	100	0.5962499999999998	22.4975
1163	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://user-service:8081/users/1"	2026-04-13 21:53:48.714983	0	0	100	0.5962499999999998	22.4975
1164	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://payment-service:8083/payments/10"	2026-04-13 21:53:48.714983	0	0	100	0.5962499999999998	22.4975
1165	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://inventory-service:8084/inventory/A1"	2026-04-13 21:53:48.714983	0	0	100	0.5962499999999998	22.4975
1166	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://shipping-service:8085/shipping/10"	2026-04-13 21:53:48.714983	0	0	100	0.5962499999999998	22.4975
1167	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://notification-service:8086/notifications/10"	2026-04-13 21:53:48.714983	0	0	100	0.5962499999999998	22.4975
1168	f3f5f610-171b-4c65-84e1-2d66e7226aed	"http://recommendation-service:8087/recommendations/1"	2026-04-13 21:53:48.714983	0	0	100	0.5962499999999998	22.4975
1169	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/users/1"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1170	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/users/1"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1171	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1172	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1173	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://order-service:8082/orders/10"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1174	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://order-service:8082/orders/10"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1175	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://user-service:8081/users/1"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1176	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://user-service:8081/users/1"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1177	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://payment-service:8083/payments/10"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1178	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://payment-service:8083/payments/10"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1179	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1180	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1181	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://shipping-service:8085/shipping/10"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1182	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://shipping-service:8085/shipping/10"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1183	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://notification-service:8086/notifications/10"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1184	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://notification-service:8086/notifications/10"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1185	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1186	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:03:14.00112	0	0	50	0.015	22.211249999999996
1187	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/users/1"	2026-04-13 22:03:30.039716	0	0	88	0.5749999999999998	22.306250000000002
1188	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:03:30.039716	0	0	88	0.5749999999999998	22.306250000000002
1189	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://order-service:8082/orders/10"	2026-04-13 22:03:30.039716	0	0	88	0.5749999999999998	22.306250000000002
1190	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://user-service:8081/users/1"	2026-04-13 22:03:30.039716	0	0	88	0.5749999999999998	22.306250000000002
1191	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://payment-service:8083/payments/10"	2026-04-13 22:03:30.039716	0	0	88	0.5749999999999998	22.306250000000002
1192	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:03:30.039716	0	0	88	0.5749999999999998	22.306250000000002
1193	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://shipping-service:8085/shipping/10"	2026-04-13 22:03:30.039716	0	0	88	0.5749999999999998	22.306250000000002
1194	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://notification-service:8086/notifications/10"	2026-04-13 22:03:30.039716	0	0	88	0.5749999999999998	22.306250000000002
1195	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:03:30.039716	0	0	88	0.5749999999999998	22.306250000000002
1196	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/users/1"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1197	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/users/1"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1198	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1199	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1200	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://order-service:8082/orders/10"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1201	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://order-service:8082/orders/10"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1202	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://user-service:8081/users/1"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1203	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://user-service:8081/users/1"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1204	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://payment-service:8083/payments/10"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1205	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://payment-service:8083/payments/10"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1206	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1207	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1208	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://shipping-service:8085/shipping/10"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1209	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://shipping-service:8085/shipping/10"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1210	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://notification-service:8086/notifications/10"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1211	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://notification-service:8086/notifications/10"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1212	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1213	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:03:46.076624	0	0	97	0.57	22.34125
1214	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/users/1"	2026-04-13 22:04:02.115869	0	0	99	0.38999999999999985	22.26625
1215	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:04:02.115869	0	0	99	0.38999999999999985	22.26625
1216	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://order-service:8082/orders/10"	2026-04-13 22:04:02.115869	0	0	99	0.38999999999999985	22.26625
1217	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://user-service:8081/users/1"	2026-04-13 22:04:02.115869	0	0	99	0.38999999999999985	22.26625
1218	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://payment-service:8083/payments/10"	2026-04-13 22:04:02.115869	0	0	99	0.38999999999999985	22.26625
1219	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:04:02.115869	0	0	99	0.38999999999999985	22.26625
1220	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://shipping-service:8085/shipping/10"	2026-04-13 22:04:02.115869	0	0	99	0.38999999999999985	22.26625
1221	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://notification-service:8086/notifications/10"	2026-04-13 22:04:02.115869	0	0	99	0.38999999999999985	22.26625
1222	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:04:02.115869	0	0	99	0.38999999999999985	22.26625
1223	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/users/1"	2026-04-13 22:04:18.150945	0	0	100	0.39749999999999996	22.36125
1224	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:04:18.150945	0	0	100	0.39749999999999996	22.36125
1225	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://order-service:8082/orders/10"	2026-04-13 22:04:18.150945	0	0	100	0.39749999999999996	22.36125
1226	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://user-service:8081/users/1"	2026-04-13 22:04:18.150945	0	0	100	0.39749999999999996	22.36125
1227	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://payment-service:8083/payments/10"	2026-04-13 22:04:18.150945	0	0	100	0.39749999999999996	22.36125
1228	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:04:18.150945	0	0	100	0.39749999999999996	22.36125
1229	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://shipping-service:8085/shipping/10"	2026-04-13 22:04:18.150945	0	0	100	0.39749999999999996	22.36125
1230	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://notification-service:8086/notifications/10"	2026-04-13 22:04:18.150945	0	0	100	0.39749999999999996	22.36125
1231	3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:04:18.150945	0	0	100	0.39749999999999996	22.36125
1259	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1260	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1261	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1262	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1263	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1264	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1265	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1266	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1267	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1268	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1269	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1270	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1271	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1272	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1273	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1274	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1275	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1276	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:24.87196	0	0	0	0.01	24.15
1232	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1233	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1234	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1235	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1236	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1237	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1238	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1239	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1240	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1241	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1242	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1243	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1244	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1245	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1246	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1247	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1248	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1249	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:20.856255	0	0	0	0.01	24.15
1250	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:22.86572	0	0	0	0.02	24.15
1251	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:22.86572	0	0	0	0.02	24.15
1252	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:22.86572	0	0	0	0.02	24.15
1253	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:22.86572	0	0	0	0.02	24.15
1254	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:22.86572	0	0	0	0.02	24.15
1255	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:22.86572	0	0	0	0.02	24.15
1256	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:22.86572	0	0	0	0.02	24.15
1257	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:22.86572	0	0	0	0.02	24.15
1258	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:22.86572	0	0	0	0.02	24.15
1277	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:26.876079	0	0	50	0	0
1278	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:26.876079	0	0	50	0	0
1279	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:26.876079	0	0	50	0	0
1280	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:26.876079	0	0	50	0	0
1281	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:26.876079	0	0	50	0	0
1282	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:26.876079	0	0	50	0	0
1283	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:26.876079	0	0	50	0	0
1284	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:26.876079	0	0	50	0	0
1285	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:26.876079	0	0	50	0	0
1286	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:26.91886	0	0	50	0	0
1287	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:26.91886	0	0	50	0	0
1288	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:26.91886	0	0	50	0	0
1289	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:26.91886	0	0	50	0	0
1290	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:26.91886	0	0	50	0	0
1291	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:26.91886	0	0	50	0	0
1292	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:26.91886	0	0	50	0	0
1293	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:26.91886	0	0	50	0	0
1294	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:26.91886	0	0	50	0	0
1295	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:27.356222	0	0	50	0	0
1296	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:27.356222	0	0	50	0	0
1297	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:27.356222	0	0	50	0	0
1298	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:27.356222	0	0	50	0	0
1299	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:27.356222	0	0	50	0	0
1300	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:27.356222	0	0	50	0	0
1301	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:27.356222	0	0	50	0	0
1302	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:27.356222	0	0	50	0	0
1303	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:27.356222	0	0	50	0	0
1304	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:27.852955	0	0	50	0	0
1305	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:27.852955	0	0	50	0	0
1306	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:27.852955	0	0	50	0	0
1307	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:27.852955	0	0	50	0	0
1308	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:27.852955	0	0	50	0	0
1309	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:27.852955	0	0	50	0	0
1310	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:27.852955	0	0	50	0	0
1311	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:27.852955	0	0	50	0	0
1312	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:27.852955	0	0	50	0	0
1313	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:28.354263	0	0	50	0	0
1314	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:28.354263	0	0	50	0	0
1315	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:28.354263	0	0	50	0	0
1316	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:28.354263	0	0	50	0	0
1317	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:28.354263	0	0	50	0	0
1318	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:28.354263	0	0	50	0	0
1319	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:28.354263	0	0	50	0	0
1320	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:28.354263	0	0	50	0	0
1321	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:28.354263	0	0	50	0	0
1322	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:28.848631	0	0	50	0	0
1323	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:28.848631	0	0	50	0	0
1324	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:28.848631	0	0	50	0	0
1325	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:28.848631	0	0	50	0	0
1326	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:28.848631	0	0	50	0	0
1327	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:28.848631	0	0	50	0	0
1328	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:28.848631	0	0	50	0	0
1329	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:28.848631	0	0	50	0	0
1330	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:28.848631	0	0	50	0	0
1331	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:30.358566	0	0	50	2.18	25.16
1332	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:30.358566	0	0	50	2.18	25.16
1333	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:30.358566	0	0	50	2.18	25.16
1334	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:30.358566	0	0	50	2.18	25.16
1335	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:30.358566	0	0	50	2.18	25.16
1336	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:30.358566	0	0	50	2.18	25.16
1337	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:30.358566	0	0	50	2.18	25.16
1338	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:30.358566	0	0	50	2.18	25.16
1339	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:30.358566	0	0	50	2.18	25.16
1340	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:32.365276	0	0	50	0.01	25.04
1341	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:32.365276	0	0	50	0.01	25.04
1342	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:32.365276	0	0	50	0.01	25.04
1343	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:32.365276	0	0	50	0.01	25.04
1344	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:32.365276	0	0	50	0.01	25.04
1345	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:32.365276	0	0	50	0.01	25.04
1346	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:32.365276	0	0	50	0.01	25.04
1347	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:32.365276	0	0	50	0.01	25.04
1348	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:32.365276	0	0	50	0.01	25.04
1349	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:34.369022	0	0	50	0.01	24.8
1350	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:34.369022	0	0	50	0.01	24.8
1351	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:34.369022	0	0	50	0.01	24.8
1352	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:34.369022	0	0	50	0.01	24.8
1353	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:34.369022	0	0	50	0.01	24.8
1354	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:34.369022	0	0	50	0.01	24.8
1355	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:34.369022	0	0	50	0.01	24.8
1356	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:34.369022	0	0	50	0.01	24.8
1357	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:34.369022	0	0	50	0.01	24.8
1358	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:36.372669	0	0	75	0.03	24.79
1359	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:36.372669	0	0	75	0.03	24.79
1360	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:36.372669	0	0	75	0.03	24.79
1361	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:36.372669	0	0	75	0.03	24.79
1362	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:36.372669	0	0	75	0.03	24.79
1363	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:36.372669	0	0	75	0.03	24.79
1364	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:36.372669	0	0	75	0.03	24.79
1365	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:36.372669	0	0	75	0.03	24.79
1366	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:36.372669	0	0	75	0.03	24.79
1367	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:38.374708	0	0	75	0	0
1368	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:38.374708	0	0	75	0	0
1369	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:38.374708	0	0	75	0	0
1370	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:38.374708	0	0	75	0	0
1371	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:38.374708	0	0	75	0	0
1372	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:38.374708	0	0	75	0	0
1373	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:38.374708	0	0	75	0	0
1374	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:38.374708	0	0	75	0	0
1375	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:38.374708	0	0	75	0	0
1376	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:38.417931	0	0	75	0	0
1377	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:38.417931	0	0	75	0	0
1378	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:38.417931	0	0	75	0	0
1379	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:38.417931	0	0	75	0	0
1380	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:38.417931	0	0	75	0	0
1381	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:38.417931	0	0	75	0	0
1382	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:38.417931	0	0	75	0	0
1383	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:38.417931	0	0	75	0	0
1384	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:38.417931	0	0	75	0	0
1385	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:40.381162	0	0	75	0.04	24.27
1386	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:40.381162	0	0	75	0.04	24.27
1387	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:40.381162	0	0	75	0.04	24.27
1388	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:40.381162	0	0	75	0.04	24.27
1389	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:40.381162	0	0	75	0.04	24.27
1390	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:40.381162	0	0	75	0.04	24.27
1391	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:40.381162	0	0	75	0.04	24.27
1392	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:40.381162	0	0	75	0.04	24.27
1393	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:40.381162	0	0	75	0.04	24.27
1394	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:42.386788	0	0	75	0.01	24.17
1395	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:42.386788	0	0	75	0.01	24.17
1396	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:42.386788	0	0	75	0.01	24.17
1397	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:42.386788	0	0	75	0.01	24.17
1398	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:42.386788	0	0	75	0.01	24.17
1399	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:42.386788	0	0	75	0.01	24.17
1400	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:42.386788	0	0	75	0.01	24.17
1401	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:42.386788	0	0	75	0.01	24.17
1402	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:42.386788	0	0	75	0.01	24.17
1403	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:44.390953	0	0	75	0.01	24.17
1404	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:44.390953	0	0	75	0.01	24.17
1405	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:44.390953	0	0	75	0.01	24.17
1406	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:44.390953	0	0	75	0.01	24.17
1407	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:44.390953	0	0	75	0.01	24.17
1408	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:44.390953	0	0	75	0.01	24.17
1409	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:44.390953	0	0	75	0.01	24.17
1410	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:44.390953	0	0	75	0.01	24.17
1411	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:44.390953	0	0	75	0.01	24.17
1412	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:46.396217	0	0	88	0.01	24.11
1413	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:46.396217	0	0	88	0.01	24.11
1414	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:46.396217	0	0	88	0.01	24.11
1415	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:46.396217	0	0	88	0.01	24.11
1416	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:46.396217	0	0	88	0.01	24.11
1417	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:46.396217	0	0	88	0.01	24.11
1418	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:46.396217	0	0	88	0.01	24.11
1419	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:46.396217	0	0	88	0.01	24.11
1420	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:46.396217	0	0	88	0.01	24.11
1421	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:46.709807	0	0	88	0	0
1422	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:46.709807	0	0	88	0	0
1423	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:46.709807	0	0	88	0	0
1424	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:46.709807	0	0	88	0	0
1425	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:46.709807	0	0	88	0	0
1426	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:46.709807	0	0	88	0	0
1427	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:46.709807	0	0	88	0	0
1428	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:46.709807	0	0	88	0	0
1429	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:46.709807	0	0	88	0	0
1430	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:46.856921	0	0	88	0	0
1431	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:46.856921	0	0	88	0	0
1432	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:46.856921	0	0	88	0	0
1433	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:46.856921	0	0	88	0	0
1434	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:46.856921	0	0	88	0	0
1435	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:46.856921	0	0	88	0	0
1436	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:46.856921	0	0	88	0	0
1437	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:46.856921	0	0	88	0	0
1438	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:46.856921	0	0	88	0	0
1439	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:47.353791	0	0	88	0	0
1440	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:47.353791	0	0	88	0	0
1441	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:47.353791	0	0	88	0	0
1442	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:47.353791	0	0	88	0	0
1443	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:47.353791	0	0	88	0	0
1444	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:47.353791	0	0	88	0	0
1445	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:47.353791	0	0	88	0	0
1446	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:47.353791	0	0	88	0	0
1447	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:47.353791	0	0	88	0	0
1448	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:47.855898	0	0	88	0	0
1449	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:47.855898	0	0	88	0	0
1450	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:47.855898	0	0	88	0	0
1451	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:47.855898	0	0	88	0	0
1452	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:47.855898	0	0	88	0	0
1453	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:47.855898	0	0	88	0	0
1454	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:47.855898	0	0	88	0	0
1455	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:47.855898	0	0	88	0	0
1456	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:47.855898	0	0	88	0	0
1457	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:48.362141	0	0	88	0	0
1458	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:48.362141	0	0	88	0	0
1459	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:48.362141	0	0	88	0	0
1460	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:48.362141	0	0	88	0	0
1461	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:48.362141	0	0	88	0	0
1462	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:48.362141	0	0	88	0	0
1463	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:48.362141	0	0	88	0	0
1464	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:48.362141	0	0	88	0	0
1465	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:48.362141	0	0	88	0	0
1466	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:49.981829	0	0	88	12.61	24.4
1467	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:49.981829	0	0	88	12.61	24.4
1468	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:49.981829	0	0	88	12.61	24.4
1469	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:49.981829	0	0	88	12.61	24.4
1470	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:49.981829	0	0	88	12.61	24.4
1471	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:49.981829	0	0	88	12.61	24.4
1472	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:49.981829	0	0	88	12.61	24.4
1473	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:49.981829	0	0	88	12.61	24.4
1474	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:49.981829	0	0	88	12.61	24.4
1475	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:51.988965	0	0	88	0.02	24.17
1476	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:51.988965	0	0	88	0.02	24.17
1477	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:51.988965	0	0	88	0.02	24.17
1478	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:51.988965	0	0	88	0.02	24.17
1479	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:51.988965	0	0	88	0.02	24.17
1480	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:51.988965	0	0	88	0.02	24.17
1481	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:51.988965	0	0	88	0.02	24.17
1482	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:51.988965	0	0	88	0.02	24.17
1483	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:51.988965	0	0	88	0.02	24.17
1484	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:53.995186	0	0	88	0.02	24.17
1485	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:53.995186	0	0	88	0.02	24.17
1486	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:53.995186	0	0	88	0.02	24.17
1487	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:53.995186	0	0	88	0.02	24.17
1488	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:53.995186	0	0	88	0.02	24.17
1489	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:53.995186	0	0	88	0.02	24.17
1490	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:53.995186	0	0	88	0.02	24.17
1491	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:53.995186	0	0	88	0.02	24.17
1492	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:53.995186	0	0	88	0.02	24.17
1493	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:56.002586	0	0	94	0.01	24.17
1494	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:56.002586	0	0	94	0.01	24.17
1495	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:56.002586	0	0	94	0.01	24.17
1496	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:56.002586	0	0	94	0.01	24.17
1497	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:56.002586	0	0	94	0.01	24.17
1498	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:56.002586	0	0	94	0.01	24.17
1499	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:56.002586	0	0	94	0.01	24.17
1500	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:56.002586	0	0	94	0.01	24.17
1501	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:56.002586	0	0	94	0.01	24.17
1502	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:58.008242	0	0	94	0	0
1503	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:58.008242	0	0	94	0	0
1504	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:58.008242	0	0	94	0	0
1505	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:58.008242	0	0	94	0	0
1506	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:58.008242	0	0	94	0	0
1507	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:58.008242	0	0	94	0	0
1508	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:58.008242	0	0	94	0	0
1509	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:58.008242	0	0	94	0	0
1510	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:58.008242	0	0	94	0	0
1511	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:58.046472	0	0	94	0	0
1512	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:58.046472	0	0	94	0	0
1513	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:58.046472	0	0	94	0	0
1514	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:58.046472	0	0	94	0	0
1515	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:58.046472	0	0	94	0	0
1516	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:58.046472	0	0	94	0	0
1517	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:58.046472	0	0	94	0	0
1518	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:58.046472	0	0	94	0	0
1519	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:58.046472	0	0	94	0	0
1520	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:08:58.349898	0	0	94	0	0
1521	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:08:58.349898	0	0	94	0	0
1522	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:08:58.349898	0	0	94	0	0
1523	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:08:58.349898	0	0	94	0	0
1524	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:08:58.349898	0	0	94	0	0
1525	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:08:58.349898	0	0	94	0	0
1526	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:08:58.349898	0	0	94	0	0
1527	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:08:58.349898	0	0	94	0	0
1528	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:08:58.349898	0	0	94	0	0
1529	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:00.021751	0	0	94	9.93	24.43
1530	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:00.021751	0	0	94	9.93	24.43
1531	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:00.021751	0	0	94	9.93	24.43
1532	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:00.021751	0	0	94	9.93	24.43
1533	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:00.021751	0	0	94	9.93	24.43
1534	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:00.021751	0	0	94	9.93	24.43
1535	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:00.021751	0	0	94	9.93	24.43
1536	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:00.021751	0	0	94	9.93	24.43
1537	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:00.021751	0	0	94	9.93	24.43
1538	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:02.025724	0	0	94	0.02	24.33
1539	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:02.025724	0	0	94	0.02	24.33
1540	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:02.025724	0	0	94	0.02	24.33
1541	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:02.025724	0	0	94	0.02	24.33
1542	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:02.025724	0	0	94	0.02	24.33
1543	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:02.025724	0	0	94	0.02	24.33
1544	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:02.025724	0	0	94	0.02	24.33
1545	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:02.025724	0	0	94	0.02	24.33
1546	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:02.025724	0	0	94	0.02	24.33
1547	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:04.027066	0	0	94	0.02	24.33
1548	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:04.027066	0	0	94	0.02	24.33
1549	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:04.027066	0	0	94	0.02	24.33
1550	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:04.027066	0	0	94	0.02	24.33
1551	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:04.027066	0	0	94	0.02	24.33
1552	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:04.027066	0	0	94	0.02	24.33
1553	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:04.027066	0	0	94	0.02	24.33
1554	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:04.027066	0	0	94	0.02	24.33
1555	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:04.027066	0	0	94	0.02	24.33
1556	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:06.032193	0	0	97	0.02	24.11
1557	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:06.032193	0	0	97	0.02	24.11
1558	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:06.032193	0	0	97	0.02	24.11
1559	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:06.032193	0	0	97	0.02	24.11
1560	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:06.032193	0	0	97	0.02	24.11
1561	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:06.032193	0	0	97	0.02	24.11
1562	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:06.032193	0	0	97	0.02	24.11
1563	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:06.032193	0	0	97	0.02	24.11
1564	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:06.032193	0	0	97	0.02	24.11
1565	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:08.033223	0	0	97	0	0
1566	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:08.033223	0	0	97	0	0
1567	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:08.033223	0	0	97	0	0
1568	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:08.033223	0	0	97	0	0
1569	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:08.033223	0	0	97	0	0
1570	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:08.033223	0	0	97	0	0
1571	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:08.033223	0	0	97	0	0
1572	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:08.033223	0	0	97	0	0
1573	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:08.033223	0	0	97	0	0
1574	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:08.074424	0	0	97	0	0
1575	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:08.074424	0	0	97	0	0
1576	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:08.074424	0	0	97	0	0
1577	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:08.074424	0	0	97	0	0
1578	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:08.074424	0	0	97	0	0
1579	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:08.074424	0	0	97	0	0
1580	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:08.074424	0	0	97	0	0
1581	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:08.074424	0	0	97	0	0
1582	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:08.074424	0	0	97	0	0
1583	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:08.352375	0	0	97	0	0
1584	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:08.352375	0	0	97	0	0
1585	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:08.352375	0	0	97	0	0
1586	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:08.352375	0	0	97	0	0
1587	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:08.352375	0	0	97	0	0
1588	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:08.352375	0	0	97	0	0
1589	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:08.352375	0	0	97	0	0
1590	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:08.352375	0	0	97	0	0
1591	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:08.352375	0	0	97	0	0
1592	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:10.037227	0	0	97	5.47	24.49
1593	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:10.037227	0	0	97	5.47	24.49
1594	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:10.037227	0	0	97	5.47	24.49
1595	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:10.037227	0	0	97	5.47	24.49
1596	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:10.037227	0	0	97	5.47	24.49
1597	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:10.037227	0	0	97	5.47	24.49
1598	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:10.037227	0	0	97	5.47	24.49
1599	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:10.037227	0	0	97	5.47	24.49
1600	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:10.037227	0	0	97	5.47	24.49
1601	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:12.041616	0	0	97	0.01	24.39
1602	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:12.041616	0	0	97	0.01	24.39
1603	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:12.041616	0	0	97	0.01	24.39
1604	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:12.041616	0	0	97	0.01	24.39
1605	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:12.041616	0	0	97	0.01	24.39
1606	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:12.041616	0	0	97	0.01	24.39
1607	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:12.041616	0	0	97	0.01	24.39
1608	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:12.041616	0	0	97	0.01	24.39
1609	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:12.041616	0	0	97	0.01	24.39
1610	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:14.04842	0	0	97	0.01	24.14
1611	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:14.04842	0	0	97	0.01	24.14
1612	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:14.04842	0	0	97	0.01	24.14
1613	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:14.04842	0	0	97	0.01	24.14
1614	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:14.04842	0	0	97	0.01	24.14
1615	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:14.04842	0	0	97	0.01	24.14
1616	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:14.04842	0	0	97	0.01	24.14
1617	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:14.04842	0	0	97	0.01	24.14
1618	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:14.04842	0	0	97	0.01	24.14
1619	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:16.05398	0	0	99	0.02	24.12
1620	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:16.05398	0	0	99	0.02	24.12
1621	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:16.05398	0	0	99	0.02	24.12
1622	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:16.05398	0	0	99	0.02	24.12
1623	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:16.05398	0	0	99	0.02	24.12
1624	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:16.05398	0	0	99	0.02	24.12
1625	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:16.05398	0	0	99	0.02	24.12
1626	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:16.05398	0	0	99	0.02	24.12
1627	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:16.05398	0	0	99	0.02	24.12
1628	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:18.05923	0	0	99	0	0
1629	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:18.05923	0	0	99	0	0
1630	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:18.05923	0	0	99	0	0
1631	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:18.05923	0	0	99	0	0
1632	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:18.05923	0	0	99	0	0
1633	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:18.05923	0	0	99	0	0
1634	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:18.05977	0	0	99	0	0
1635	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:18.05977	0	0	99	0	0
1636	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:18.05977	0	0	99	0	0
1637	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:18.099176	0	0	99	0	0
1638	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:18.099176	0	0	99	0	0
1639	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:18.099176	0	0	99	0	0
1640	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:18.099176	0	0	99	0	0
1641	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:18.099176	0	0	99	0	0
1642	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:18.099176	0	0	99	0	0
1643	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:18.099176	0	0	99	0	0
1644	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:18.099176	0	0	99	0	0
1645	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:18.099176	0	0	99	0	0
1646	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:18.351029	0	0	99	0	0
1647	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:18.351029	0	0	99	0	0
1648	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:18.351029	0	0	99	0	0
1649	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:18.351029	0	0	99	0	0
1650	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:18.351029	0	0	99	0	0
1651	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:18.351029	0	0	99	0	0
1652	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:18.351029	0	0	99	0	0
1653	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:18.351029	0	0	99	0	0
1654	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:18.351029	0	0	99	0	0
1655	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:20.069005	0	0	99	5.05	24.41
1656	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:20.069005	0	0	99	5.05	24.41
1657	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:20.069005	0	0	99	5.05	24.41
1658	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:20.069005	0	0	99	5.05	24.41
1659	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:20.069005	0	0	99	5.05	24.41
1660	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:20.069005	0	0	99	5.05	24.41
1661	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:20.069005	0	0	99	5.05	24.41
1662	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:20.069005	0	0	99	5.05	24.41
1663	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:20.069005	0	0	99	5.05	24.41
1664	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:22.068866	0	0	99	0.01	24.36
1665	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:22.068866	0	0	99	0.01	24.36
1666	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:22.068866	0	0	99	0.01	24.36
1667	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:22.068866	0	0	99	0.01	24.36
1668	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:22.068866	0	0	99	0.01	24.36
1669	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:22.068866	0	0	99	0.01	24.36
1670	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:22.068866	0	0	99	0.01	24.36
1671	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:22.068866	0	0	99	0.01	24.36
1672	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:22.068866	0	0	99	0.01	24.36
1673	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:24.078134	0	0	99	0.02	24.36
1674	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:24.078134	0	0	99	0.02	24.36
1675	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:24.078134	0	0	99	0.02	24.36
1676	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:24.078134	0	0	99	0.02	24.36
1677	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:24.078134	0	0	99	0.02	24.36
1678	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:24.078134	0	0	99	0.02	24.36
1679	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:24.078134	0	0	99	0.02	24.36
1680	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:24.078134	0	0	99	0.02	24.36
1681	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:24.078134	0	0	99	0.02	24.36
1682	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:26.084518	0	0	100	0.02	24.11
1683	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:26.084518	0	0	100	0.02	24.11
1684	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:26.084518	0	0	100	0.02	24.11
1685	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:26.084518	0	0	100	0.02	24.11
1686	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:26.084518	0	0	100	0.02	24.11
1687	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:26.084518	0	0	100	0.02	24.11
1688	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:26.084518	0	0	100	0.02	24.11
1689	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:26.084518	0	0	100	0.02	24.11
1690	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:26.084518	0	0	100	0.02	24.11
1691	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:28.081557	0	0	100	0	0
1692	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:28.081557	0	0	100	0	0
1693	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:28.081557	0	0	100	0	0
1694	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:28.081557	0	0	100	0	0
1695	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:28.081557	0	0	100	0	0
1696	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:28.081557	0	0	100	0	0
1697	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:28.081557	0	0	100	0	0
1698	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:28.081557	0	0	100	0	0
1699	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:28.081557	0	0	100	0	0
1700	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:28.122783	0	0	100	0	0
1701	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:28.122783	0	0	100	0	0
1702	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:28.122783	0	0	100	0	0
1703	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:28.122783	0	0	100	0	0
1704	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:28.122783	0	0	100	0	0
1705	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:28.122783	0	0	100	0	0
1706	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:28.122783	0	0	100	0	0
1707	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:28.122783	0	0	100	0	0
1708	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:28.122783	0	0	100	0	0
1709	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:28.358948	0	0	100	0	0
1710	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:28.358948	0	0	100	0	0
1711	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:28.358948	0	0	100	0	0
1712	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:28.358948	0	0	100	0	0
1713	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:28.358948	0	0	100	0	0
1714	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:28.358948	0	0	100	0	0
1715	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:28.358948	0	0	100	0	0
1716	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:28.358948	0	0	100	0	0
1717	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:28.358948	0	0	100	0	0
1718	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:30.08466	0	0	100	2.54	24.16
1719	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:30.08466	0	0	100	2.54	24.16
1720	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:30.08466	0	0	100	2.54	24.16
1721	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:30.08466	0	0	100	2.54	24.16
1722	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:30.08466	0	0	100	2.54	24.16
1723	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:30.08466	0	0	100	2.54	24.16
1724	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:30.08466	0	0	100	2.54	24.16
1725	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:30.08466	0	0	100	2.54	24.16
1726	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:30.08466	0	0	100	2.54	24.16
1727	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:32.090337	0	0	100	0.02	24.12
1728	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:32.090337	0	0	100	0.02	24.12
1729	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:32.090337	0	0	100	0.02	24.12
1730	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:32.090337	0	0	100	0.02	24.12
1731	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:32.090337	0	0	100	0.02	24.12
1732	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:32.090337	0	0	100	0.02	24.12
1733	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:32.090337	0	0	100	0.02	24.12
1734	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:32.090337	0	0	100	0.02	24.12
1735	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:32.090337	0	0	100	0.02	24.12
1736	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:34.096529	0	0	100	0.01	24.12
1737	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:34.096529	0	0	100	0.01	24.12
1738	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:34.096529	0	0	100	0.01	24.12
1739	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:34.096529	0	0	100	0.01	24.12
1740	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:34.096529	0	0	100	0.01	24.12
1741	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:34.096529	0	0	100	0.01	24.12
1742	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:34.096529	0	0	100	0.01	24.12
1743	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:34.096529	0	0	100	0.01	24.12
1744	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:34.096529	0	0	100	0.01	24.12
1745	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:36.100574	0	0	100	0.03	24.12
1746	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:36.100574	0	0	100	0.03	24.12
1747	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:36.100574	0	0	100	0.03	24.12
1748	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:36.100574	0	0	100	0.03	24.12
1749	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:36.100574	0	0	100	0.03	24.12
1750	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:36.100574	0	0	100	0.03	24.12
1751	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:36.100574	0	0	100	0.03	24.12
1752	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:36.100574	0	0	100	0.03	24.12
1753	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:36.100574	0	0	100	0.03	24.12
1754	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:38.105587	0	0	100	0.01	24.12
1755	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:38.105587	0	0	100	0.01	24.12
1756	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:38.105587	0	0	100	0.01	24.12
1757	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:38.105587	0	0	100	0.01	24.12
1758	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:38.105587	0	0	100	0.01	24.12
1759	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:38.105587	0	0	100	0.01	24.12
1760	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:38.105587	0	0	100	0.01	24.12
1761	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:38.105587	0	0	100	0.01	24.12
1762	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:38.105587	0	0	100	0.01	24.12
1763	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/users/1"	2026-04-13 22:09:40.111993	0	0	100	0.02	24.1
1764	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:09:40.111993	0	0	100	0.02	24.1
1765	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://order-service:8082/orders/10"	2026-04-13 22:09:40.111993	0	0	100	0.02	24.1
1766	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://user-service:8081/users/1"	2026-04-13 22:09:40.111993	0	0	100	0.02	24.1
1767	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://payment-service:8083/payments/10"	2026-04-13 22:09:40.111993	0	0	100	0.02	24.1
1768	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:09:40.111993	0	0	100	0.02	24.1
1769	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://shipping-service:8085/shipping/10"	2026-04-13 22:09:40.111993	0	0	100	0.02	24.1
1770	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://notification-service:8086/notifications/10"	2026-04-13 22:09:40.111993	0	0	100	0.02	24.1
1771	ce28f73b-57fc-45cf-9f60-36bfed57da8c	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:09:40.111993	0	0	100	0.02	24.1
1772	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/users/1"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1773	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/users/1"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1774	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1775	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1776	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://order-service:8082/orders/10"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1777	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://order-service:8082/orders/10"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1778	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://user-service:8081/users/1"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1779	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://user-service:8081/users/1"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1780	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://payment-service:8083/payments/10"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1781	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://payment-service:8083/payments/10"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1782	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1783	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1784	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://shipping-service:8085/shipping/10"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1785	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://shipping-service:8085/shipping/10"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1786	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://notification-service:8086/notifications/10"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1787	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://notification-service:8086/notifications/10"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1788	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1789	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:15:12.911569	0	0	40	0.012499999999999997	22.13625
1790	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/users/1"	2026-04-13 22:15:28.94018	0	0	70	17.65	40.4075
1791	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:15:28.94018	0	0	70	17.65	40.4075
1792	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://order-service:8082/orders/10"	2026-04-13 22:15:28.94018	0	0	70	17.65	40.4075
1793	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://user-service:8081/users/1"	2026-04-13 22:15:28.94018	0	0	70	17.65	40.4075
1794	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://payment-service:8083/payments/10"	2026-04-13 22:15:28.94018	0	0	70	17.65	40.4075
1795	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:15:28.94018	0	0	70	17.65	40.4075
1796	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://shipping-service:8085/shipping/10"	2026-04-13 22:15:28.94018	0	0	70	17.65	40.4075
1797	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://notification-service:8086/notifications/10"	2026-04-13 22:15:28.94018	0	0	70	17.65	40.4075
1798	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:15:28.94018	0	0	70	17.65	40.4075
1799	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/users/1"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1800	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/users/1"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1801	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1802	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1803	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://order-service:8082/orders/10"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1804	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://order-service:8082/orders/10"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1805	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://user-service:8081/users/1"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1806	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://user-service:8081/users/1"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1807	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://payment-service:8083/payments/10"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1808	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://payment-service:8083/payments/10"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1809	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1810	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1811	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://shipping-service:8085/shipping/10"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1812	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://shipping-service:8085/shipping/10"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1813	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://notification-service:8086/notifications/10"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1814	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://notification-service:8086/notifications/10"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1815	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1816	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:15:44.98919	0	0	78	131.0275	47.66374999999999
1817	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/users/1"	2026-04-13 22:16:01.027684	0	0	79	132.5975	47.07375
1818	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:16:01.027684	0	0	79	132.5975	47.07375
1819	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://order-service:8082/orders/10"	2026-04-13 22:16:01.027684	0	0	79	132.5975	47.07375
1820	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://user-service:8081/users/1"	2026-04-13 22:16:01.027684	0	0	79	132.5975	47.07375
1821	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://payment-service:8083/payments/10"	2026-04-13 22:16:01.027684	0	0	79	132.5975	47.07375
1822	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:16:01.027684	0	0	79	132.5975	47.07375
1823	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://shipping-service:8085/shipping/10"	2026-04-13 22:16:01.027684	0	0	79	132.5975	47.07375
1824	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://notification-service:8086/notifications/10"	2026-04-13 22:16:01.027684	0	0	79	132.5975	47.07375
1825	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:16:01.027684	0	0	79	132.5975	47.07375
1826	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/users/1"	2026-04-13 22:16:17.066743	0	0	80	68.40874999999998	46.88250000000001
1827	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://api-gateway:8080/api/orders/10"	2026-04-13 22:16:17.066743	0	0	80	68.40874999999998	46.88250000000001
1828	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://order-service:8082/orders/10"	2026-04-13 22:16:17.066743	0	0	80	68.40874999999998	46.88250000000001
1829	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://user-service:8081/users/1"	2026-04-13 22:16:17.066743	0	0	80	68.40874999999998	46.88250000000001
1830	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://payment-service:8083/payments/10"	2026-04-13 22:16:17.066743	0	0	80	68.40874999999998	46.88250000000001
1831	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://inventory-service:8084/inventory/A1"	2026-04-13 22:16:17.066743	0	0	80	68.40874999999998	46.88250000000001
1832	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://shipping-service:8085/shipping/10"	2026-04-13 22:16:17.066743	0	0	80	68.40874999999998	46.88250000000001
1833	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://notification-service:8086/notifications/10"	2026-04-13 22:16:17.066743	0	0	80	68.40874999999998	46.88250000000001
1834	4ea99c95-1ae4-47db-90dd-715a5f8221c4	"http://recommendation-service:8087/recommendations/1"	2026-04-13 22:16:17.066743	0	0	80	68.40874999999998	46.88250000000001
1835	dacebb05-5455-4e5a-ad98-c9d9217470a2	frontend:ingest	2026-04-14 08:50:43.401481	0	408	0	0	0
1836	3f5ef8a2-b8c9-4faf-b26c-8cb498a82e4c	frontend:ingest	2026-04-14 09:07:38.725513	0	408	0	0	0
1837	9391f66d-c2cf-442b-ba64-8e043fb22fa3	frontend:ingest	2026-04-14 09:15:15.948533	0	408	0	0	0
1838	7e39ec66-a1a0-43a1-bb27-64c99d1de31d	frontend:ingest	2026-04-14 09:39:00.854218	0	408	0	0	0
1839	7e39ec66-a1a0-43a1-bb27-64c99d1de31d	/	2026-04-14 09:39:02.289647	0	200	0	0	0
1840	dac38b3c-afaf-4ac9-a68c-8f2b5e19d5cd	frontend:ingest	2026-04-14 09:41:54.476279	0	408	0	0	0
1841	dac38b3c-afaf-4ac9-a68c-8f2b5e19d5cd	/	2026-04-14 09:41:55.112173	0	200	0	0	0
1842	ecdf9170-7b71-493b-9644-39391b84cc3b	frontend:ingest	2026-04-14 09:42:54.023913	0	408	0	0	0
1843	ecdf9170-7b71-493b-9644-39391b84cc3b	/	2026-04-14 09:42:54.71056	0	200	0	0	0
1844	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1845	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1846	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1847	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1848	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1849	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1850	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1851	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1852	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1853	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1854	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1855	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1856	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1857	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1858	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1859	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1860	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1861	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:02.286195	0	0	50	0.01125	22.729999999999997
1862	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:10.305927	0	0	75	0.0025	6.14625
1863	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:10.305927	0	0	75	0.0025	6.14625
1864	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:10.305927	0	0	75	0.0025	6.14625
1865	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:10.305927	0	0	75	0.0025	6.14625
1866	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:10.305927	0	0	75	0.0025	6.14625
1867	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:10.305927	0	0	75	0.0025	6.14625
1868	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:10.305927	0	0	75	0.0025	6.14625
1869	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:10.305927	0	0	75	0.0025	6.14625
1870	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:10.305927	0	0	75	0.0025	6.14625
1871	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:12.594313	0	0	75	0	0
1872	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:12.594313	0	0	75	0	0
1873	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:12.594313	0	0	75	0	0
1874	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:12.594313	0	0	75	0	0
1875	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:12.594313	0	0	75	0	0
1876	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:12.594313	0	0	75	0	0
1877	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:12.594313	0	0	75	0	0
1878	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:12.594313	0	0	75	0	0
1879	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:12.594313	0	0	75	0	0
1880	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:12.594313	0	0	75	0	0
1881	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:12.594313	0	0	75	0	0
1882	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:12.594313	0	0	75	0	0
1883	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:12.594313	0	0	75	0	0
1884	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:12.594313	0	0	75	0	0
1885	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:12.594313	0	0	75	0	0
1886	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:12.594313	0	0	75	0	0
1887	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:12.594313	0	0	75	0	0
1888	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:12.594313	0	0	75	0	0
1889	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:12.902197	0	0	88	0	0
1890	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:12.902197	0	0	88	0	0
1891	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:12.902197	0	0	88	0	0
1892	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:12.902197	0	0	88	0	0
1893	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:12.902197	0	0	88	0	0
1894	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:12.902197	0	0	88	0	0
1895	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:12.902197	0	0	88	0	0
1896	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:12.902197	0	0	88	0	0
1897	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:12.902197	0	0	88	0	0
1898	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:13.210065	0	0	88	0	0
1899	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:13.210065	0	0	88	0	0
1900	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:13.210065	0	0	88	0	0
1901	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:13.210065	0	0	88	0	0
1902	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:13.210065	0	0	88	0	0
1903	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:13.210065	0	0	88	0	0
1904	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:13.210065	0	0	88	0	0
1905	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:13.210065	0	0	88	0	0
1906	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:13.210065	0	0	88	0	0
1907	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:13.515658	0	0	88	0	0
1908	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:13.515658	0	0	88	0	0
1909	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:13.515658	0	0	88	0	0
1910	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:13.515658	0	0	88	0	0
1911	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:13.515658	0	0	88	0	0
1912	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:13.515658	0	0	88	0	0
1913	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:13.515658	0	0	88	0	0
1914	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:13.515658	0	0	88	0	0
1915	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:13.515658	0	0	88	0	0
1916	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:13.905288	0	0	88	0	0
1917	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:13.905288	0	0	88	0	0
1918	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:13.905288	0	0	88	0	0
1919	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:13.905288	0	0	88	0	0
1920	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:13.905288	0	0	88	0	0
1921	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:13.905288	0	0	88	0	0
1922	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:13.905288	0	0	88	0	0
1923	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:13.905288	0	0	88	0	0
1924	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:13.905288	0	0	88	0	0
1925	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:14.416178	0	0	88	0	0
1926	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:14.416178	0	0	88	0	0
1927	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:14.416178	0	0	88	0	0
1928	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:14.416178	0	0	88	0	0
1929	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:14.416178	0	0	88	0	0
1930	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:14.416178	0	0	88	0	0
1931	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:14.416178	0	0	88	0	0
1932	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:14.416178	0	0	88	0	0
1933	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:14.416178	0	0	88	0	0
1934	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:14.934351	0	0	88	0	0
1935	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:14.934351	0	0	88	0	0
1936	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:14.934351	0	0	88	0	0
1937	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:14.934351	0	0	88	0	0
1938	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:14.934351	0	0	88	0	0
1939	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:14.934351	0	0	88	0	0
1940	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:14.934351	0	0	88	0	0
1941	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:14.934351	0	0	88	0	0
1942	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:14.934351	0	0	88	0	0
1943	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:30.186841	0	0	94	1.86875	22.737500000000004
1944	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:30.186841	0	0	94	1.86875	22.737500000000004
1945	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:30.186841	0	0	94	1.86875	22.737500000000004
1946	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:30.186841	0	0	94	1.86875	22.737500000000004
1947	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:30.186841	0	0	94	1.86875	22.737500000000004
1948	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:30.186841	0	0	94	1.86875	22.737500000000004
1949	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:30.186841	0	0	94	1.86875	22.737500000000004
1950	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:30.186841	0	0	94	1.86875	22.737500000000004
1951	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:30.186841	0	0	94	1.86875	22.737500000000004
1952	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:38.408549	0	0	97	0.00375	9.040000000000001
1953	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:38.408549	0	0	97	0.00375	9.040000000000001
1954	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:38.408549	0	0	97	0.00375	9.040000000000001
1955	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:38.408549	0	0	97	0.00375	9.040000000000001
1956	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:38.408549	0	0	97	0.00375	9.040000000000001
1957	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:38.408549	0	0	97	0.00375	9.040000000000001
1958	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:38.408549	0	0	97	0.00375	9.040000000000001
1959	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:38.408549	0	0	97	0.00375	9.040000000000001
1960	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:38.408549	0	0	97	0.00375	9.040000000000001
1961	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:40.414019	0	0	97	0.00125	3.015
1962	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:40.414019	0	0	97	0.00125	3.015
1963	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:40.414019	0	0	97	0.00125	3.015
1964	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:40.414019	0	0	97	0.00125	3.015
1965	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:40.414019	0	0	97	0.00125	3.015
1966	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:40.414019	0	0	97	0.00125	3.015
1967	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:40.414019	0	0	97	0.00125	3.015
1968	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:40.414019	0	0	97	0.00125	3.015
1969	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:40.414019	0	0	97	0.00125	3.015
1970	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:42.417492	0	0	97	0	0
1971	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:42.417492	0	0	97	0	0
1972	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:42.417492	0	0	97	0	0
1973	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:42.417492	0	0	97	0	0
1974	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:42.417492	0	0	97	0	0
1975	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:42.417492	0	0	97	0	0
1976	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:42.417492	0	0	97	0	0
1977	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:42.417492	0	0	97	0	0
1978	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:42.417492	0	0	97	0	0
1979	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:42.727613	0	0	99	0	0
1980	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:42.727613	0	0	99	0	0
1981	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:42.727613	0	0	99	0	0
1982	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:42.727613	0	0	99	0	0
1983	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:42.727613	0	0	99	0	0
1984	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:42.727613	0	0	99	0	0
1985	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:42.727613	0	0	99	0	0
1986	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:42.727613	0	0	99	0	0
1987	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:42.727613	0	0	99	0	0
1988	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:43.039756	0	0	99	0	0
1989	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:43.039756	0	0	99	0	0
1990	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:43.039756	0	0	99	0	0
1991	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:43.039756	0	0	99	0	0
1992	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:43.039756	0	0	99	0	0
1993	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:43.039756	0	0	99	0	0
1994	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:43.039756	0	0	99	0	0
1995	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:43.039756	0	0	99	0	0
1996	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:43.039756	0	0	99	0	0
1997	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:43.414762	0	0	99	0	0
1998	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:43.414762	0	0	99	0	0
1999	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:43.414762	0	0	99	0	0
2000	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:43.414762	0	0	99	0	0
2001	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:43.414762	0	0	99	0	0
2002	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:43.414762	0	0	99	0	0
2003	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:43.414762	0	0	99	0	0
2004	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:43.414762	0	0	99	0	0
2005	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:43.414762	0	0	99	0	0
2006	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:43.931885	0	0	99	0	0
2007	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:43.931885	0	0	99	0	0
2008	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:43.931885	0	0	99	0	0
2009	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:43.931885	0	0	99	0	0
2010	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:43.931885	0	0	99	0	0
2011	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:43.931885	0	0	99	0	0
2012	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:43.931885	0	0	99	0	0
2013	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:43.931885	0	0	99	0	0
2014	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:43.931885	0	0	99	0	0
2015	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/users/1"	2026-04-14 16:32:59.328362	0	0	100	1.8749999999999998	22.1075
2016	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://api-gateway:8080/api/orders/10"	2026-04-14 16:32:59.328362	0	0	100	1.8749999999999998	22.1075
2017	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://order-service:8082/orders/10"	2026-04-14 16:32:59.328362	0	0	100	1.8749999999999998	22.1075
2018	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://user-service:8081/users/1"	2026-04-14 16:32:59.328362	0	0	100	1.8749999999999998	22.1075
2019	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://payment-service:8083/payments/10"	2026-04-14 16:32:59.328362	0	0	100	1.8749999999999998	22.1075
2020	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://inventory-service:8084/inventory/A1"	2026-04-14 16:32:59.328362	0	0	100	1.8749999999999998	22.1075
2021	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://shipping-service:8085/shipping/10"	2026-04-14 16:32:59.328362	0	0	100	1.8749999999999998	22.1075
2022	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://notification-service:8086/notifications/10"	2026-04-14 16:32:59.328362	0	0	100	1.8749999999999998	22.1075
2023	ec680a5c-b06d-417e-b725-0a9545bc9e8a	"http://recommendation-service:8087/recommendations/1"	2026-04-14 16:32:59.328362	0	0	100	1.8749999999999998	22.1075
2024	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/users/1"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2025	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/users/1"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2026	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/orders/10"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2027	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/orders/10"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2028	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://order-service:8082/orders/10"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2029	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://order-service:8082/orders/10"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2030	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://user-service:8081/users/1"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2031	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://user-service:8081/users/1"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2032	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://payment-service:8083/payments/10"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2033	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://payment-service:8083/payments/10"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2034	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://inventory-service:8084/inventory/A1"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2035	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://inventory-service:8084/inventory/A1"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2036	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://shipping-service:8085/shipping/10"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2037	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://shipping-service:8085/shipping/10"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2038	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://notification-service:8086/notifications/10"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2039	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://notification-service:8086/notifications/10"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2040	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://recommendation-service:8087/recommendations/1"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2041	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://recommendation-service:8087/recommendations/1"	2026-04-14 20:18:56.936844	0	0	50	0.04625000000000001	22.127499999999998
2042	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/users/1"	2026-04-14 20:19:12.981417	0	0	88	0.4037499999999999	22.36375
2043	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/orders/10"	2026-04-14 20:19:12.981417	0	0	88	0.4037499999999999	22.36375
2044	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://order-service:8082/orders/10"	2026-04-14 20:19:12.981417	0	0	88	0.4037499999999999	22.36375
2045	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://user-service:8081/users/1"	2026-04-14 20:19:12.981417	0	0	88	0.4037499999999999	22.36375
2046	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://payment-service:8083/payments/10"	2026-04-14 20:19:12.981417	0	0	88	0.4037499999999999	22.36375
2047	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://inventory-service:8084/inventory/A1"	2026-04-14 20:19:12.981417	0	0	88	0.4037499999999999	22.36375
2048	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://shipping-service:8085/shipping/10"	2026-04-14 20:19:12.981417	0	0	88	0.4037499999999999	22.36375
2049	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://notification-service:8086/notifications/10"	2026-04-14 20:19:12.981417	0	0	88	0.4037499999999999	22.36375
2050	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://recommendation-service:8087/recommendations/1"	2026-04-14 20:19:12.981417	0	0	88	0.4037499999999999	22.36375
2051	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/users/1"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2052	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/users/1"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2053	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/orders/10"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2054	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/orders/10"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2055	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://order-service:8082/orders/10"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2056	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://order-service:8082/orders/10"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2057	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://user-service:8081/users/1"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2058	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://user-service:8081/users/1"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2059	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://payment-service:8083/payments/10"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2060	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://payment-service:8083/payments/10"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2061	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://inventory-service:8084/inventory/A1"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2062	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://inventory-service:8084/inventory/A1"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2063	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://shipping-service:8085/shipping/10"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2064	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://shipping-service:8085/shipping/10"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2065	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://notification-service:8086/notifications/10"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2066	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://notification-service:8086/notifications/10"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2067	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://recommendation-service:8087/recommendations/1"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2068	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://recommendation-service:8087/recommendations/1"	2026-04-14 20:19:29.018277	0	0	97	0.69	22.541249999999998
2069	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/users/1"	2026-04-14 20:19:45.061017	0	0	99	0.5874999999999998	22.3275
2070	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/orders/10"	2026-04-14 20:19:45.061017	0	0	99	0.5874999999999998	22.3275
2071	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://order-service:8082/orders/10"	2026-04-14 20:19:45.061017	0	0	99	0.5874999999999998	22.3275
2072	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://user-service:8081/users/1"	2026-04-14 20:19:45.061017	0	0	99	0.5874999999999998	22.3275
2073	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://payment-service:8083/payments/10"	2026-04-14 20:19:45.061017	0	0	99	0.5874999999999998	22.3275
2074	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://inventory-service:8084/inventory/A1"	2026-04-14 20:19:45.061017	0	0	99	0.5874999999999998	22.3275
2075	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://shipping-service:8085/shipping/10"	2026-04-14 20:19:45.061017	0	0	99	0.5874999999999998	22.3275
2076	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://notification-service:8086/notifications/10"	2026-04-14 20:19:45.061017	0	0	99	0.5874999999999998	22.3275
2077	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://recommendation-service:8087/recommendations/1"	2026-04-14 20:19:45.061017	0	0	99	0.5874999999999998	22.3275
2078	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/users/1"	2026-04-14 20:20:01.097706	0	0	100	0.5899999999999999	22.326249999999998
2079	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://api-gateway:8080/api/orders/10"	2026-04-14 20:20:01.097706	0	0	100	0.5899999999999999	22.326249999999998
2080	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://order-service:8082/orders/10"	2026-04-14 20:20:01.097706	0	0	100	0.5899999999999999	22.326249999999998
2081	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://user-service:8081/users/1"	2026-04-14 20:20:01.097706	0	0	100	0.5899999999999999	22.326249999999998
2082	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://payment-service:8083/payments/10"	2026-04-14 20:20:01.097706	0	0	100	0.5899999999999999	22.326249999999998
2083	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://inventory-service:8084/inventory/A1"	2026-04-14 20:20:01.097706	0	0	100	0.5899999999999999	22.326249999999998
2084	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://shipping-service:8085/shipping/10"	2026-04-14 20:20:01.097706	0	0	100	0.5899999999999999	22.326249999999998
2085	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://notification-service:8086/notifications/10"	2026-04-14 20:20:01.097706	0	0	100	0.5899999999999999	22.326249999999998
2086	deccd3c1-17c5-4380-a1cb-961e2aef6502	"http://recommendation-service:8087/recommendations/1"	2026-04-14 20:20:01.097706	0	0	100	0.5899999999999999	22.326249999999998
\.


--
-- Data for Name: backend_status_metrics; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.backend_status_metrics (experiment_id, state, phase, blast_radius, cascade_depth, system_severity, failsafe_score, status_payload, updated_at) FROM stdin;
1fe154e4-a5ef-4cb1-8b63-73fb815bd835	failed	completed	0	0	isolated	0	{"phase": "completed", "state": "failed", "frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-05T00:04:31.2636198+05:30", "first_impact": {"http://user-service:8081/users/1": "2026-04-05T00:04:32.339163+05:30", "http://api-gateway:8080/api/users/1": "2026-04-05T00:04:31.3376544+05:30", "http://order-service:8082/orders/10": "2026-04-05T00:04:32.8398229+05:30", "http://api-gateway:8080/api/orders/10": "2026-04-05T00:04:31.8386043+05:30"}}, "endpoints": {"http://user-service:8081/users/1": {"errors": {"total": 9, "rate_percent": 100, "max_failure_streak": 9}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 24.646666666666665, "max_memory_mb": 25.51, "avg_cpu_percent": 0.6000000000000001, "max_cpu_percent": 2.64}, "impact_order": 0, "requests_total": 9, "stability_score": 0}, "http://api-gateway:8080/api/users/1": {"errors": {"total": 11, "rate_percent": 100, "max_failure_streak": 11}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 24.987272727272728, "max_memory_mb": 26.52, "avg_cpu_percent": 0.4945454545454545, "max_cpu_percent": 2.64}, "impact_order": 0, "requests_total": 11, "stability_score": 0}, "http://order-service:8082/orders/10": {"errors": {"total": 9, "rate_percent": 100, "max_failure_streak": 9}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 24.646666666666665, "max_memory_mb": 25.51, "avg_cpu_percent": 0.6000000000000001, "max_cpu_percent": 2.64}, "impact_order": 0, "requests_total": 9, "stability_score": 0}, "http://api-gateway:8080/api/orders/10": {"errors": {"total": 11, "rate_percent": 100, "max_failure_streak": 11}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 24.987272727272728, "max_memory_mb": 26.52, "avg_cpu_percent": 0.4945454545454545, "max_cpu_percent": 2.64}, "impact_order": 0, "requests_total": 11, "stability_score": 0}}, "cascade_depth": 0, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 40, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "isolated", "total_endpoints": 4, "blast_radius_percent": 0, "resilience_threshold": {"intensity_steps": null, "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-04 18:41:23.2771
a98a50a9-f656-4e82-970c-0b0b2165b36e	completed	completed	112.5	1	partial	0	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-06T16:15:10.8468734+05:30", "first_impact": {"http://user-service:8081/users/1": "2026-04-06T16:15:14.3825609+05:30", "http://api-gateway:8080/api/users/1": "2026-04-06T16:15:12.8804353+05:30", "http://order-service:8082/orders/10": "2026-04-06T16:15:13.8822213+05:30", "http://api-gateway:8080/api/orders/10": "2026-04-06T16:15:13.3812945+05:30", "http://payment-service:8083/payments/10": "2026-04-06T16:15:14.8827569+05:30", "http://shipping-service:8085/shipping/10": "2026-04-06T16:15:15.8840783+05:30", "http://inventory-service:8084/inventory/A1": "2026-04-06T16:15:15.3834059+05:30", "http://notification-service:8086/notifications/10": "2026-04-06T16:15:16.3844635+05:30", "http://recommendation-service:8087/recommendations/1": "2026-04-06T16:15:10.8939066+05:30"}}, "endpoints": {"http://user-service:8081/users/1": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1.002}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.3651483716701107}, "degraded": true, "container": {"avg_memory_mb": 24.841333333333328, "max_memory_mb": 25.56, "avg_cpu_percent": 0.204, "max_cpu_percent": 1.41}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://api-gateway:8080/api/users/1": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 24.841333333333328, "max_memory_mb": 25.56, "avg_cpu_percent": 0.204, "max_cpu_percent": 1.41}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://order-service:8082/orders/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1.002}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.4472135954999579}, "degraded": true, "container": {"avg_memory_mb": 24.841333333333328, "max_memory_mb": 25.56, "avg_cpu_percent": 0.204, "max_cpu_percent": 1.41}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://api-gateway:8080/api/orders/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1.004}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 502, "p99_ms": 502, "jitter_ms": 0.14285714285714285, "stddev_ms": 0.8944271909999159}, "degraded": true, "container": {"avg_memory_mb": 24.841333333333328, "max_memory_mb": 25.56, "avg_cpu_percent": 0.204, "max_cpu_percent": 1.41}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://payment-service:8083/payments/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 24.841333333333328, "max_memory_mb": 25.56, "avg_cpu_percent": 0.204, "max_cpu_percent": 1.41}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://shipping-service:8085/shipping/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1.002}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.3651483716701107}, "degraded": true, "container": {"avg_memory_mb": 24.841333333333328, "max_memory_mb": 25.56, "avg_cpu_percent": 0.204, "max_cpu_percent": 1.41}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://inventory-service:8084/inventory/A1": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1.002}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.3651483716701107}, "degraded": true, "container": {"avg_memory_mb": 24.841333333333328, "max_memory_mb": 25.56, "avg_cpu_percent": 0.204, "max_cpu_percent": 1.41}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://notification-service:8086/notifications/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1.002}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.3651483716701107}, "degraded": true, "container": {"avg_memory_mb": 24.841333333333328, "max_memory_mb": 25.56, "avg_cpu_percent": 0.204, "max_cpu_percent": 1.41}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://recommendation-service:8087/recommendations/1": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1.002}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.3651483716701107}, "degraded": true, "container": {"avg_memory_mb": 24.841333333333328, "max_memory_mb": 25.56, "avg_cpu_percent": 0.204, "max_cpu_percent": 1.41}, "impact_order": 0, "requests_total": 15, "stability_score": 0}}, "cascade_depth": 1, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 135, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "partial", "total_endpoints": 9, "blast_radius_percent": 112.5, "resilience_threshold": {"intensity_steps": null, "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-06 10:45:45.891299
89bbde53-24f1-4d15-854a-7d3031a45875	completed	completed	0	0	isolated	0	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-06T14:58:20.5363836+05:30", "first_impact": {"http://api-gateway:8080/health": "2026-04-06T14:58:20.5772507+05:30"}}, "endpoints": {"http://api-gateway:8080/health": {"errors": {"total": 11, "rate_percent": 100, "max_failure_streak": 11}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 24.9, "max_memory_mb": 26.43, "avg_cpu_percent": 0.01636363636363636, "max_cpu_percent": 0.02}, "impact_order": 0, "requests_total": 11, "stability_score": 0}}, "cascade_depth": 0, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 11, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "isolated", "total_endpoints": 1, "blast_radius_percent": 0, "resilience_threshold": {"intensity_steps": null, "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-06 09:28:25.551943
8ccb8c63-1dfb-4513-857a-62886761cec2	completed	completed	0	0	isolated	0	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-08T22:51:19.672978+05:30", "first_impact": {}}, "endpoints": {"\\"http://user-service:8081/users/1\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.819249999999999, "max_memory_mb": 22.86125, "avg_cpu_percent": 0.088375, "max_cpu_percent": 1.6949999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://api-gateway:8080/api/users/1\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.819249999999999, "max_memory_mb": 22.86125, "avg_cpu_percent": 0.088375, "max_cpu_percent": 1.6949999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://order-service:8082/orders/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.819249999999999, "max_memory_mb": 22.86125, "avg_cpu_percent": 0.088375, "max_cpu_percent": 1.6949999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://api-gateway:8080/api/orders/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.819249999999999, "max_memory_mb": 22.86125, "avg_cpu_percent": 0.088375, "max_cpu_percent": 1.6949999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://payment-service:8083/payments/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.819249999999999, "max_memory_mb": 22.86125, "avg_cpu_percent": 0.088375, "max_cpu_percent": 1.6949999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://shipping-service:8085/shipping/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.819249999999999, "max_memory_mb": 22.86125, "avg_cpu_percent": 0.088375, "max_cpu_percent": 1.6949999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://inventory-service:8084/inventory/A1\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.819249999999999, "max_memory_mb": 22.86125, "avg_cpu_percent": 0.088375, "max_cpu_percent": 1.6949999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://notification-service:8086/notifications/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.819249999999999, "max_memory_mb": 22.86125, "avg_cpu_percent": 0.088375, "max_cpu_percent": 1.6949999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.819249999999999, "max_memory_mb": 22.86125, "avg_cpu_percent": 0.088375, "max_cpu_percent": 1.6949999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}}, "cascade_depth": 0, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 180, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "isolated", "total_endpoints": 9, "blast_radius_percent": 0, "resilience_threshold": {"intensity_steps": [50, 75, 88, 94, 97, 99, 100], "breaking_intensity": 0, "max_stable_intensity": 100}, "fault_injection_history": [{"intensity": 50, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-08T22:50:29.2536318+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-08T22:50:29.2536318+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-08T22:50:29.2536318+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-08T22:50:29.2536318+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-08T22:50:29.2536318+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-08T22:50:29.2536318+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-08T22:50:29.2536318+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-08T22:50:29.2536318+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-08T22:50:29.2536318+05:30"}, "fault_started_at": "2026-04-08T22:50:19.669311+05:30"}, {"intensity": 75, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-08T22:50:37.2806813+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-08T22:50:37.2806813+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-08T22:50:37.2806813+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-08T22:50:37.2806813+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-08T22:50:37.2806813+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-08T22:50:37.2806813+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-08T22:50:37.2806813+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-08T22:50:37.2806813+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-08T22:50:37.2806813+05:30"}, "fault_started_at": "2026-04-08T22:50:29.669979+05:30"}, {"intensity": 88, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T22:50:39.6707195+05:30"}, {"intensity": 94, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T22:50:49.6708845+05:30"}, {"intensity": 97, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T22:50:59.6718673+05:30"}, {"intensity": 99, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T22:51:09.6726131+05:30"}, {"intensity": 100, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T22:51:19.672978+05:30"}], "fault_injection_history_v2": [{"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:29.2536318+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:29.2536318+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:29.2536318+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:29.2536318+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:29.2536318+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:29.2536318+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:29.2536318+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:29.2536318+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:29.2536318+05:30"}}, "anomalies": null, "intensity": 50, "fault_cause": "kill", "cascade_path": ["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://user-service:8081/users/1\\""], "fault_started_at": "2026-04-08T22:50:19.669311+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:37.2806813+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:37.2806813+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:37.2806813+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:37.2806813+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:37.2806813+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:37.2806813+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:37.2806813+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:37.2806813+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:50:37.2806813+05:30"}}, "anomalies": null, "intensity": 75, "fault_cause": "kill", "cascade_path": ["\\"http://notification-service:8086/notifications/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\""], "fault_started_at": "2026-04-08T22:50:29.669979+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 88, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T22:50:39.6707195+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 94, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T22:50:49.6708845+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 97, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T22:50:59.6718673+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 99, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T22:51:09.6726131+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 100, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T22:51:19.672978+05:30"}]}	2026-04-08 17:21:34.687581
aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	completed	completed	112.5	1	partial	0.03326679973386604	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-06T16:03:19.9287621+05:30", "first_impact": {"http://user-service:8081/users/1": "2026-04-06T16:03:23.7682302+05:30", "http://api-gateway:8080/api/users/1": "2026-04-06T16:03:22.266448+05:30", "http://order-service:8082/orders/10": "2026-04-06T16:03:23.267661+05:30", "http://api-gateway:8080/api/orders/10": "2026-04-06T16:03:22.7670051+05:30", "http://payment-service:8083/payments/10": "2026-04-06T16:03:24.2687497+05:30", "http://shipping-service:8085/shipping/10": "2026-04-06T16:03:25.2700204+05:30", "http://inventory-service:8084/inventory/A1": "2026-04-06T16:03:24.7695281+05:30", "http://notification-service:8086/notifications/10": "2026-04-06T16:03:25.7778768+05:30", "http://recommendation-service:8087/recommendations/1": "2026-04-06T16:03:19.9429201+05:30"}}, "endpoints": {"http://user-service:8081/users/1": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.5163977794943223}, "degraded": true, "container": {"avg_memory_mb": 25.15866666666667, "max_memory_mb": 25.92, "avg_cpu_percent": 1.292, "max_cpu_percent": 4.9}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://api-gateway:8080/api/users/1": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.3651483716701107}, "degraded": true, "container": {"avg_memory_mb": 25.15866666666667, "max_memory_mb": 25.92, "avg_cpu_percent": 1.292, "max_cpu_percent": 4.9}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://order-service:8082/orders/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.3651483716701107}, "degraded": true, "container": {"avg_memory_mb": 25.15866666666667, "max_memory_mb": 25.92, "avg_cpu_percent": 1.292, "max_cpu_percent": 4.9}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://api-gateway:8080/api/orders/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 0.998003992015968}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 25.15866666666667, "max_memory_mb": 25.92, "avg_cpu_percent": 1.292, "max_cpu_percent": 4.9}, "impact_order": 0, "requests_total": 15, "stability_score": 0.09980039920159811}, "http://payment-service:8083/payments/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 0.998003992015968}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 25.15866666666667, "max_memory_mb": 25.92, "avg_cpu_percent": 1.292, "max_cpu_percent": 4.9}, "impact_order": 0, "requests_total": 15, "stability_score": 0.09980039920159811}, "http://shipping-service:8085/shipping/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.5163977794943223}, "degraded": true, "container": {"avg_memory_mb": 25.15866666666667, "max_memory_mb": 25.92, "avg_cpu_percent": 1.292, "max_cpu_percent": 4.9}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://inventory-service:8084/inventory/A1": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.5773502691896257}, "degraded": true, "container": {"avg_memory_mb": 25.15866666666667, "max_memory_mb": 25.92, "avg_cpu_percent": 1.292, "max_cpu_percent": 4.9}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://notification-service:8086/notifications/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1.0119760479041917}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 507, "p99_ms": 507, "jitter_ms": 0.5, "stddev_ms": 2.556038601690775}, "degraded": true, "container": {"avg_memory_mb": 25.15866666666667, "max_memory_mb": 25.92, "avg_cpu_percent": 1.292, "max_cpu_percent": 4.9}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://recommendation-service:8087/recommendations/1": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 0.998003992015968}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 25.15866666666667, "max_memory_mb": 25.92, "avg_cpu_percent": 1.292, "max_cpu_percent": 4.9}, "impact_order": 0, "requests_total": 15, "stability_score": 0.09980039920159811}}, "cascade_depth": 1, "failsafe_index": {"mode": "backend_only", "score": 0.03326679973386604, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 135, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "partial", "total_endpoints": 9, "blast_radius_percent": 112.5, "resilience_threshold": {"intensity_steps": null, "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-06 10:33:55.923336
d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	completed	completed	0	0	isolated	0	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-08T23:06:48.8064981+05:30", "first_impact": {}}, "endpoints": {"\\"http://user-service:8081/users/1\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.656812500000001, "max_memory_mb": 22.7575, "avg_cpu_percent": 0.186125, "max_cpu_percent": 2.0775000000000006}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://api-gateway:8080/api/users/1\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.656812500000001, "max_memory_mb": 22.7575, "avg_cpu_percent": 0.186125, "max_cpu_percent": 2.0775000000000006}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://order-service:8082/orders/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.656812500000001, "max_memory_mb": 22.7575, "avg_cpu_percent": 0.186125, "max_cpu_percent": 2.0775000000000006}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://api-gateway:8080/api/orders/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.656812500000001, "max_memory_mb": 22.7575, "avg_cpu_percent": 0.186125, "max_cpu_percent": 2.0775000000000006}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://payment-service:8083/payments/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.656812500000001, "max_memory_mb": 22.7575, "avg_cpu_percent": 0.186125, "max_cpu_percent": 2.0775000000000006}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://shipping-service:8085/shipping/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.656812500000001, "max_memory_mb": 22.7575, "avg_cpu_percent": 0.186125, "max_cpu_percent": 2.0775000000000006}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://inventory-service:8084/inventory/A1\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.656812500000001, "max_memory_mb": 22.7575, "avg_cpu_percent": 0.186125, "max_cpu_percent": 2.0775000000000006}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://notification-service:8086/notifications/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.656812500000001, "max_memory_mb": 22.7575, "avg_cpu_percent": 0.186125, "max_cpu_percent": 2.0775000000000006}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.656812500000001, "max_memory_mb": 22.7575, "avg_cpu_percent": 0.186125, "max_cpu_percent": 2.0775000000000006}, "impact_order": 0, "requests_total": 20, "stability_score": 0}}, "cascade_depth": 0, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 180, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "isolated", "total_endpoints": 9, "blast_radius_percent": 0, "resilience_threshold": {"intensity_steps": [50, 75, 88, 94, 97, 99, 100], "breaking_intensity": 0, "max_stable_intensity": 100}, "fault_injection_history": [{"intensity": 88, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T23:06:08.8047289+05:30"}, {"intensity": 94, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T23:06:18.8052045+05:30"}, {"intensity": 97, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T23:06:28.805829+05:30"}, {"intensity": 99, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T23:06:38.8061614+05:30"}, {"intensity": 100, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T23:06:48.8064981+05:30"}, {"intensity": 50, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-08T23:05:58.3892954+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-08T23:05:58.3892954+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-08T23:05:58.3892954+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-08T23:05:58.3892954+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-08T23:05:58.3892954+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-08T23:05:58.3892954+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-08T23:05:58.3892954+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-08T23:05:58.3892954+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-08T23:05:58.3892954+05:30"}, "fault_started_at": "2026-04-08T23:05:48.8028257+05:30"}, {"intensity": 75, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-08T23:06:06.422376+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-08T23:06:06.422376+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-08T23:06:06.422376+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-08T23:06:06.422376+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-08T23:06:06.422376+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-08T23:06:06.422376+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-08T23:06:06.422376+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-08T23:06:06.422376+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-08T23:06:06.422376+05:30"}, "fault_started_at": "2026-04-08T23:05:58.8040411+05:30"}], "fault_injection_history_v2": [{"impacts": {}, "anomalies": null, "intensity": 88, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T23:06:08.8047289+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 94, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T23:06:18.8052045+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 97, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T23:06:28.805829+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 99, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T23:06:38.8061614+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 100, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T23:06:48.8064981+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:05:58.3892954+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:05:58.3892954+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:05:58.3892954+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:05:58.3892954+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:05:58.3892954+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:05:58.3892954+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:05:58.3892954+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:05:58.3892954+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:05:58.3892954+05:30"}}, "anomalies": null, "intensity": 50, "fault_cause": "kill", "cascade_path": ["\\"http://user-service:8081/users/1\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://api-gateway:8080/api/users/1\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://notification-service:8086/notifications/10\\""], "fault_started_at": "2026-04-08T23:05:48.8028257+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:06:06.422376+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:06:06.422376+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:06:06.422376+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:06:06.422376+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:06:06.422376+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:06:06.422376+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:06:06.422376+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:06:06.422376+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T23:06:06.422376+05:30"}}, "anomalies": null, "intensity": 75, "fault_cause": "kill", "cascade_path": ["\\"http://user-service:8081/users/1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://notification-service:8086/notifications/10\\""], "fault_started_at": "2026-04-08T23:05:58.8040411+05:30"}]}	2026-04-08 17:37:03.814011
f3f5f610-171b-4c65-84e1-2d66e7226aed	completed	completed	0	0	isolated	0	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-13T21:53:34.9671529+05:30", "first_impact": {}}, "endpoints": {"\\"http://user-service:8081/users/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.394464285714285, "max_memory_mb": 22.556250000000002, "avg_cpu_percent": 0.37607142857142856, "max_cpu_percent": 0.5962499999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://api-gateway:8080/api/users/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.394464285714285, "max_memory_mb": 22.556250000000002, "avg_cpu_percent": 0.37607142857142856, "max_cpu_percent": 0.5962499999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://order-service:8082/orders/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.394464285714285, "max_memory_mb": 22.556250000000002, "avg_cpu_percent": 0.37607142857142856, "max_cpu_percent": 0.5962499999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://api-gateway:8080/api/orders/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.394464285714285, "max_memory_mb": 22.556250000000002, "avg_cpu_percent": 0.37607142857142856, "max_cpu_percent": 0.5962499999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://payment-service:8083/payments/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.394464285714285, "max_memory_mb": 22.556250000000002, "avg_cpu_percent": 0.37607142857142856, "max_cpu_percent": 0.5962499999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://shipping-service:8085/shipping/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.394464285714285, "max_memory_mb": 22.556250000000002, "avg_cpu_percent": 0.37607142857142856, "max_cpu_percent": 0.5962499999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://inventory-service:8084/inventory/A1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.394464285714285, "max_memory_mb": 22.556250000000002, "avg_cpu_percent": 0.37607142857142856, "max_cpu_percent": 0.5962499999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://notification-service:8086/notifications/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.394464285714285, "max_memory_mb": 22.556250000000002, "avg_cpu_percent": 0.37607142857142856, "max_cpu_percent": 0.5962499999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.394464285714285, "max_memory_mb": 22.556250000000002, "avg_cpu_percent": 0.37607142857142856, "max_cpu_percent": 0.5962499999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}}, "cascade_depth": 0, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 63, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "isolated", "total_endpoints": 9, "blast_radius_percent": 0, "resilience_threshold": {"intensity_steps": [50, 75, 88, 94, 97, 99, 100], "breaking_intensity": 0, "max_stable_intensity": 100}, "fault_injection_history": [{"intensity": 50, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-13T21:52:44.5457154+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-13T21:52:44.5457154+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-13T21:52:44.5457154+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-13T21:52:44.5457154+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-13T21:52:44.5457154+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-13T21:52:44.5457154+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-13T21:52:44.5457154+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-13T21:52:44.5457154+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-13T21:52:44.5457154+05:30"}, "fault_started_at": "2026-04-13T21:52:34.9639036+05:30"}, {"intensity": 75, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T21:52:44.964868+05:30"}, {"intensity": 88, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T21:52:54.9653832+05:30"}, {"intensity": 94, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T21:53:04.9658105+05:30"}, {"intensity": 97, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-13T21:53:16.6296109+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-13T21:53:16.6296109+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-13T21:53:16.6296109+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-13T21:53:16.6296109+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-13T21:53:16.6296109+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-13T21:53:16.6296109+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-13T21:53:16.6296109+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-13T21:53:16.6296109+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-13T21:53:16.6296109+05:30"}, "fault_started_at": "2026-04-13T21:53:14.9664641+05:30"}, {"intensity": 99, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T21:53:24.9669986+05:30"}, {"intensity": 100, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T21:53:34.9671529+05:30"}], "fault_injection_history_v2": [{"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:52:44.5457154+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:52:44.5457154+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:52:44.5457154+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:52:44.5457154+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:52:44.5457154+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:52:44.5457154+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:52:44.5457154+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:52:44.5457154+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:52:44.5457154+05:30"}}, "anomalies": null, "intensity": 50, "fault_cause": "network_delay", "cascade_path": ["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://payment-service:8083/payments/10\\""], "fault_started_at": "2026-04-13T21:52:34.9639036+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 75, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T21:52:44.964868+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 88, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T21:52:54.9653832+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 94, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T21:53:04.9658105+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:53:16.6296109+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:53:16.6296109+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:53:16.6296109+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:53:16.6296109+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:53:16.6296109+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:53:16.6296109+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:53:16.6296109+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:53:16.6296109+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T21:53:16.6296109+05:30"}}, "anomalies": null, "intensity": 97, "fault_cause": "network_delay", "cascade_path": ["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\""], "fault_started_at": "2026-04-13T21:53:14.9664641+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 99, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T21:53:24.9669986+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 100, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T21:53:34.9671529+05:30"}]}	2026-04-13 16:23:49.97537
6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	completed	completed	112.5	1	partial	0.03326679973386604	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-06T19:44:22.6859293+05:30", "first_impact": {"http://user-service:8081/users/1": "2026-04-06T19:44:25.8358008+05:30", "http://api-gateway:8080/api/users/1": "2026-04-06T19:44:24.3340651+05:30", "http://order-service:8082/orders/10": "2026-04-06T19:44:25.3350942+05:30", "http://api-gateway:8080/api/orders/10": "2026-04-06T19:44:24.8342089+05:30", "http://payment-service:8083/payments/10": "2026-04-06T19:44:26.3362977+05:30", "http://shipping-service:8085/shipping/10": "2026-04-06T19:44:27.3372308+05:30", "http://inventory-service:8084/inventory/A1": "2026-04-06T19:44:26.8367467+05:30", "http://notification-service:8086/notifications/10": "2026-04-06T19:44:27.8376911+05:30", "http://recommendation-service:8087/recommendations/1": "2026-04-06T19:44:22.7746212+05:30"}}, "endpoints": {"http://user-service:8081/users/1": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.3651483716701107}, "degraded": true, "container": {"avg_memory_mb": 25.419999999999998, "max_memory_mb": 25.77, "avg_cpu_percent": 0.020000000000000004, "max_cpu_percent": 0.03}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://api-gateway:8080/api/users/1": {"errors": {"total": 17, "rate_percent": 100, "max_failure_streak": 17}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.0625, "stddev_ms": 0.48507125007266594}, "degraded": true, "container": {"avg_memory_mb": 25.44235294117647, "max_memory_mb": 25.77, "avg_cpu_percent": 0.020000000000000004, "max_cpu_percent": 0.03}, "impact_order": 0, "requests_total": 17, "stability_score": 0}, "http://order-service:8082/orders/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.3651483716701107}, "degraded": true, "container": {"avg_memory_mb": 25.419999999999998, "max_memory_mb": 25.77, "avg_cpu_percent": 0.020000000000000004, "max_cpu_percent": 0.03}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://api-gateway:8080/api/orders/10": {"errors": {"total": 17, "rate_percent": 100, "max_failure_streak": 17}, "derived": {"error_delta": 0, "latency_ratio": 0.998003992015968}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 25.44235294117647, "max_memory_mb": 25.77, "avg_cpu_percent": 0.020000000000000004, "max_cpu_percent": 0.03}, "impact_order": 0, "requests_total": 17, "stability_score": 0.09980039920159811}, "http://payment-service:8083/payments/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.4472135954999579}, "degraded": true, "container": {"avg_memory_mb": 25.419999999999998, "max_memory_mb": 25.77, "avg_cpu_percent": 0.020000000000000004, "max_cpu_percent": 0.03}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://shipping-service:8085/shipping/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.3651483716701107}, "degraded": true, "container": {"avg_memory_mb": 25.419999999999998, "max_memory_mb": 25.77, "avg_cpu_percent": 0.020000000000000004, "max_cpu_percent": 0.03}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://inventory-service:8084/inventory/A1": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 501, "p99_ms": 501, "jitter_ms": 0.07142857142857142, "stddev_ms": 0.5773502691896257}, "degraded": true, "container": {"avg_memory_mb": 25.419999999999998, "max_memory_mb": 25.77, "avg_cpu_percent": 0.020000000000000004, "max_cpu_percent": 0.03}, "impact_order": 0, "requests_total": 15, "stability_score": 0}, "http://notification-service:8086/notifications/10": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 0.998003992015968}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 25.419999999999998, "max_memory_mb": 25.77, "avg_cpu_percent": 0.020000000000000004, "max_cpu_percent": 0.03}, "impact_order": 0, "requests_total": 15, "stability_score": 0.09980039920159811}, "http://recommendation-service:8087/recommendations/1": {"errors": {"total": 15, "rate_percent": 100, "max_failure_streak": 15}, "derived": {"error_delta": 0, "latency_ratio": 0.998003992015968}, "latency": {"avg_ms": 500, "p50_ms": 500, "p95_ms": 500, "p99_ms": 500, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 25.419999999999998, "max_memory_mb": 25.77, "avg_cpu_percent": 0.020000000000000004, "max_cpu_percent": 0.03}, "impact_order": 0, "requests_total": 15, "stability_score": 0.09980039920159811}}, "cascade_depth": 1, "failsafe_index": {"mode": "backend_only", "score": 0.03326679973386604, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 139, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "partial", "total_endpoints": 9, "blast_radius_percent": 112.5, "resilience_threshold": {"intensity_steps": null, "breaking_intensity": 0, "max_stable_intensity": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-06 14:14:58.681587
50be69bb-0d99-4875-b756-eb541d3156cd	completed	completed	0	0	isolated	0	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-08T20:51:37.5967728+05:30", "first_impact": {}}, "endpoints": {"\\"http://user-service:8081/users/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 23.59142857142857, "max_memory_mb": 23.757499999999997, "avg_cpu_percent": 0.3646428571428571, "max_cpu_percent": 0.8799999999999999}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://api-gateway:8080/api/users/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 23.59142857142857, "max_memory_mb": 23.757499999999997, "avg_cpu_percent": 0.3646428571428571, "max_cpu_percent": 0.8799999999999999}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://order-service:8082/orders/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 23.59142857142857, "max_memory_mb": 23.757499999999997, "avg_cpu_percent": 0.3646428571428571, "max_cpu_percent": 0.8799999999999999}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://api-gateway:8080/api/orders/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 23.59142857142857, "max_memory_mb": 23.757499999999997, "avg_cpu_percent": 0.3646428571428571, "max_cpu_percent": 0.8799999999999999}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://payment-service:8083/payments/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 23.59142857142857, "max_memory_mb": 23.757499999999997, "avg_cpu_percent": 0.3646428571428571, "max_cpu_percent": 0.8799999999999999}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://shipping-service:8085/shipping/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 23.59142857142857, "max_memory_mb": 23.757499999999997, "avg_cpu_percent": 0.3646428571428571, "max_cpu_percent": 0.8799999999999999}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://inventory-service:8084/inventory/A1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 23.59142857142857, "max_memory_mb": 23.757499999999997, "avg_cpu_percent": 0.3646428571428571, "max_cpu_percent": 0.8799999999999999}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://notification-service:8086/notifications/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 23.59142857142857, "max_memory_mb": 23.757499999999997, "avg_cpu_percent": 0.3646428571428571, "max_cpu_percent": 0.8799999999999999}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 23.59142857142857, "max_memory_mb": 23.757499999999997, "avg_cpu_percent": 0.3646428571428571, "max_cpu_percent": 0.8799999999999999}, "impact_order": 0, "requests_total": 7, "stability_score": 0}}, "cascade_depth": 0, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 63, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "isolated", "total_endpoints": 9, "blast_radius_percent": 0, "resilience_threshold": {"intensity_steps": [35, 53, 62, 66, 68, 69, 70], "breaking_intensity": 0, "max_stable_intensity": 70}, "fault_injection_history": [{"intensity": 62, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T20:50:57.5940225+05:30"}, {"intensity": 66, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T20:51:07.5947504+05:30"}, {"intensity": 68, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-08T20:51:19.2731259+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-08T20:51:19.2731259+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-08T20:51:19.2731259+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-08T20:51:19.2731259+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-08T20:51:19.2731259+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-08T20:51:19.2731259+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-08T20:51:19.2731259+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-08T20:51:19.2731259+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-08T20:51:19.2731259+05:30"}, "fault_started_at": "2026-04-08T20:51:17.5953133+05:30"}, {"intensity": 69, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T20:51:27.5959178+05:30"}, {"intensity": 70, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T20:51:37.5967728+05:30"}, {"intensity": 35, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-08T20:50:47.1399506+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-08T20:50:47.1399506+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-08T20:50:47.1399506+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-08T20:50:47.1399506+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-08T20:50:47.1399506+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-08T20:50:47.1399506+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-08T20:50:47.1399506+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-08T20:50:47.1399506+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-08T20:50:47.1399506+05:30"}, "fault_started_at": "2026-04-08T20:50:37.5926331+05:30"}, {"intensity": 53, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T20:50:47.593415+05:30"}], "fault_injection_history_v2": [{"impacts": {}, "anomalies": null, "intensity": 62, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T20:50:57.5940225+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 66, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T20:51:07.5947504+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:51:19.2731259+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:51:19.2731259+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:51:19.2731259+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:51:19.2731259+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:51:19.2731259+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:51:19.2731259+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:51:19.2731259+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:51:19.2731259+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:51:19.2731259+05:30"}}, "anomalies": null, "intensity": 68, "fault_cause": "network_delay", "cascade_path": ["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://inventory-service:8084/inventory/A1\\""], "fault_started_at": "2026-04-08T20:51:17.5953133+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 69, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T20:51:27.5959178+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 70, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T20:51:37.5967728+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:50:47.1399506+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:50:47.1399506+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:50:47.1399506+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:50:47.1399506+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:50:47.1399506+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:50:47.1399506+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:50:47.1399506+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:50:47.1399506+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T20:50:47.1399506+05:30"}}, "anomalies": null, "intensity": 35, "fault_cause": "network_delay", "cascade_path": ["\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://api-gateway:8080/api/users/1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://api-gateway:8080/api/orders/10\\""], "fault_started_at": "2026-04-08T20:50:37.5926331+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 53, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T20:50:47.593415+05:30"}]}	2026-04-08 15:21:52.605559
fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	completed	completed	0	0	isolated	0	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-08T22:43:18.7833441+05:30", "first_impact": {}}, "endpoints": {"\\"http://user-service:8081/users/1\\"": {"errors": {"total": 22, "rate_percent": 100, "max_failure_streak": 22}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.973113636363636, "max_memory_mb": 23.38625, "avg_cpu_percent": 0.09437499999999997, "max_cpu_percent": 1.9499999999999997}, "impact_order": 0, "requests_total": 22, "stability_score": 0}, "\\"http://api-gateway:8080/api/users/1\\"": {"errors": {"total": 22, "rate_percent": 100, "max_failure_streak": 22}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.973113636363636, "max_memory_mb": 23.38625, "avg_cpu_percent": 0.09437499999999997, "max_cpu_percent": 1.9499999999999997}, "impact_order": 0, "requests_total": 22, "stability_score": 0}, "\\"http://order-service:8082/orders/10\\"": {"errors": {"total": 22, "rate_percent": 100, "max_failure_streak": 22}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.973113636363636, "max_memory_mb": 23.38625, "avg_cpu_percent": 0.09437499999999997, "max_cpu_percent": 1.9499999999999997}, "impact_order": 0, "requests_total": 22, "stability_score": 0}, "\\"http://api-gateway:8080/api/orders/10\\"": {"errors": {"total": 22, "rate_percent": 100, "max_failure_streak": 22}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.973113636363636, "max_memory_mb": 23.38625, "avg_cpu_percent": 0.09437499999999997, "max_cpu_percent": 1.9499999999999997}, "impact_order": 0, "requests_total": 22, "stability_score": 0}, "\\"http://payment-service:8083/payments/10\\"": {"errors": {"total": 22, "rate_percent": 100, "max_failure_streak": 22}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.973113636363636, "max_memory_mb": 23.38625, "avg_cpu_percent": 0.09437499999999997, "max_cpu_percent": 1.9499999999999997}, "impact_order": 0, "requests_total": 22, "stability_score": 0}, "\\"http://shipping-service:8085/shipping/10\\"": {"errors": {"total": 22, "rate_percent": 100, "max_failure_streak": 22}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.973113636363636, "max_memory_mb": 23.38625, "avg_cpu_percent": 0.09437499999999997, "max_cpu_percent": 1.9499999999999997}, "impact_order": 0, "requests_total": 22, "stability_score": 0}, "\\"http://inventory-service:8084/inventory/A1\\"": {"errors": {"total": 22, "rate_percent": 100, "max_failure_streak": 22}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.973113636363636, "max_memory_mb": 23.38625, "avg_cpu_percent": 0.09437499999999997, "max_cpu_percent": 1.9499999999999997}, "impact_order": 0, "requests_total": 22, "stability_score": 0}, "\\"http://notification-service:8086/notifications/10\\"": {"errors": {"total": 22, "rate_percent": 100, "max_failure_streak": 22}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.973113636363636, "max_memory_mb": 23.38625, "avg_cpu_percent": 0.09437499999999997, "max_cpu_percent": 1.9499999999999997}, "impact_order": 0, "requests_total": 22, "stability_score": 0}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"errors": {"total": 22, "rate_percent": 100, "max_failure_streak": 22}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.973113636363636, "max_memory_mb": 23.38625, "avg_cpu_percent": 0.09437499999999997, "max_cpu_percent": 1.9499999999999997}, "impact_order": 0, "requests_total": 22, "stability_score": 0}}, "cascade_depth": 0, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 198, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "isolated", "total_endpoints": 9, "blast_radius_percent": 0, "resilience_threshold": {"intensity_steps": [40, 60, 70, 75, 78, 79, 80], "breaking_intensity": 0, "max_stable_intensity": 80}, "fault_injection_history": [{"intensity": 80, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T22:43:18.7833441+05:30"}, {"intensity": 40, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-08T22:42:28.3692909+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-08T22:42:28.3692909+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-08T22:42:28.3692909+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-08T22:42:28.3692909+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-08T22:42:28.3692909+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-08T22:42:28.3692909+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-08T22:42:28.3692909+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-08T22:42:28.3692909+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-08T22:42:28.3692909+05:30"}, "fault_started_at": "2026-04-08T22:42:18.7795588+05:30"}, {"intensity": 60, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-08T22:42:36.3907757+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-08T22:42:36.3907757+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-08T22:42:36.3907757+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-08T22:42:36.3907757+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-08T22:42:36.3907757+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-08T22:42:36.3907757+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-08T22:42:36.3907757+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-08T22:42:36.3907757+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-08T22:42:36.3907757+05:30"}, "fault_started_at": "2026-04-08T22:42:28.7806877+05:30"}, {"intensity": 70, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T22:42:38.7813044+05:30"}, {"intensity": 75, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T22:42:48.7814186+05:30"}, {"intensity": 78, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T22:42:58.7817215+05:30"}, {"intensity": 79, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-08T22:43:08.7820746+05:30"}], "fault_injection_history_v2": [{"impacts": {}, "anomalies": null, "intensity": 80, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T22:43:18.7833441+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:28.3692909+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:28.3692909+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:28.3692909+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:28.3692909+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:28.3692909+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:28.3692909+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:28.3692909+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:28.3692909+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:28.3692909+05:30"}}, "anomalies": null, "intensity": 40, "fault_cause": "kill", "cascade_path": ["\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://api-gateway:8080/api/users/1\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://notification-service:8086/notifications/10\\""], "fault_started_at": "2026-04-08T22:42:18.7795588+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:36.3907757+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:36.3907757+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:36.3907757+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:36.3907757+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:36.3907757+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:36.3907757+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:36.3907757+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:36.3907757+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-08T22:42:36.3907757+05:30"}}, "anomalies": null, "intensity": 60, "fault_cause": "kill", "cascade_path": ["\\"http://user-service:8081/users/1\\"", "\\"http://api-gateway:8080/api/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://api-gateway:8080/api/orders/10\\""], "fault_started_at": "2026-04-08T22:42:28.7806877+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 70, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T22:42:38.7813044+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 75, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T22:42:48.7814186+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 78, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T22:42:58.7817215+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 79, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-08T22:43:08.7820746+05:30"}]}	2026-04-08 17:13:34.776859
3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	completed	completed	0	0	isolated	0	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-13T22:04:04.4337728+05:30", "first_impact": {}}, "endpoints": {"\\"http://user-service:8081/users/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.291249999999998, "max_memory_mb": 22.36125, "avg_cpu_percent": 0.3617857142857142, "max_cpu_percent": 0.5749999999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://api-gateway:8080/api/users/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.291249999999998, "max_memory_mb": 22.36125, "avg_cpu_percent": 0.3617857142857142, "max_cpu_percent": 0.5749999999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://order-service:8082/orders/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.291249999999998, "max_memory_mb": 22.36125, "avg_cpu_percent": 0.3617857142857142, "max_cpu_percent": 0.5749999999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://api-gateway:8080/api/orders/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.291249999999998, "max_memory_mb": 22.36125, "avg_cpu_percent": 0.3617857142857142, "max_cpu_percent": 0.5749999999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://payment-service:8083/payments/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.291249999999998, "max_memory_mb": 22.36125, "avg_cpu_percent": 0.3617857142857142, "max_cpu_percent": 0.5749999999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://shipping-service:8085/shipping/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.291249999999998, "max_memory_mb": 22.36125, "avg_cpu_percent": 0.3617857142857142, "max_cpu_percent": 0.5749999999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://inventory-service:8084/inventory/A1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.291249999999998, "max_memory_mb": 22.36125, "avg_cpu_percent": 0.3617857142857142, "max_cpu_percent": 0.5749999999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://notification-service:8086/notifications/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.291249999999998, "max_memory_mb": 22.36125, "avg_cpu_percent": 0.3617857142857142, "max_cpu_percent": 0.5749999999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.291249999999998, "max_memory_mb": 22.36125, "avg_cpu_percent": 0.3617857142857142, "max_cpu_percent": 0.5749999999999998}, "impact_order": 0, "requests_total": 7, "stability_score": 0}}, "cascade_depth": 0, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 63, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "isolated", "total_endpoints": 9, "blast_radius_percent": 0, "resilience_threshold": {"intensity_steps": [50, 75, 88, 94, 97, 99, 100], "breaking_intensity": 0, "max_stable_intensity": 100}, "fault_injection_history": [{"intensity": 50, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-13T22:03:14.0011209+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-13T22:03:14.0011209+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-13T22:03:14.0011209+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-13T22:03:14.0011209+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-13T22:03:14.0011209+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-13T22:03:14.0011209+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-13T22:03:14.0011209+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-13T22:03:14.0011209+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-13T22:03:14.0011209+05:30"}, "fault_started_at": "2026-04-13T22:03:04.4322807+05:30"}, {"intensity": 75, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:03:14.4326619+05:30"}, {"intensity": 88, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:03:24.4330597+05:30"}, {"intensity": 94, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:03:34.4332506+05:30"}, {"intensity": 97, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-13T22:03:46.0766245+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-13T22:03:46.0766245+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-13T22:03:46.0766245+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-13T22:03:46.0766245+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-13T22:03:46.0766245+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-13T22:03:46.0766245+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-13T22:03:46.0766245+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-13T22:03:46.0766245+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-13T22:03:46.0766245+05:30"}, "fault_started_at": "2026-04-13T22:03:44.433529+05:30"}, {"intensity": 99, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:03:54.4336237+05:30"}, {"intensity": 100, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:04:04.4337728+05:30"}], "fault_injection_history_v2": [{"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:14.0011209+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:14.0011209+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:14.0011209+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:14.0011209+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:14.0011209+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:14.0011209+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:14.0011209+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:14.0011209+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:14.0011209+05:30"}}, "anomalies": null, "intensity": 50, "fault_cause": "network_delay", "cascade_path": ["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\""], "fault_started_at": "2026-04-13T22:03:04.4322807+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 75, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:03:14.4326619+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 88, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:03:24.4330597+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 94, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:03:34.4332506+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:46.0766245+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:46.0766245+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:46.0766245+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:46.0766245+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:46.0766245+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:46.0766245+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:46.0766245+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:46.0766245+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:03:46.0766245+05:30"}}, "anomalies": null, "intensity": 97, "fault_cause": "network_delay", "cascade_path": ["\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://payment-service:8083/payments/10\\""], "fault_started_at": "2026-04-13T22:03:44.433529+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 99, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:03:54.4336237+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 100, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:04:04.4337728+05:30"}]}	2026-04-13 16:34:19.454245
ce28f73b-57fc-45cf-9f60-36bfed57da8c	completed	completed	0	0	isolated	0	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-13T22:09:25.3248089+05:30", "first_impact": {}}, "endpoints": {"\\"http://user-service:8081/users/1\\"": {"errors": {"total": 60, "rate_percent": 100, "max_failure_streak": 60}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 14.174833333333334, "max_memory_mb": 25.16, "avg_cpu_percent": 0.6375, "max_cpu_percent": 12.61}, "impact_order": 0, "requests_total": 60, "stability_score": 0}, "\\"http://api-gateway:8080/api/users/1\\"": {"errors": {"total": 60, "rate_percent": 100, "max_failure_streak": 60}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 14.174833333333334, "max_memory_mb": 25.16, "avg_cpu_percent": 0.6375, "max_cpu_percent": 12.61}, "impact_order": 0, "requests_total": 60, "stability_score": 0}, "\\"http://order-service:8082/orders/10\\"": {"errors": {"total": 60, "rate_percent": 100, "max_failure_streak": 60}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 14.174833333333334, "max_memory_mb": 25.16, "avg_cpu_percent": 0.6375, "max_cpu_percent": 12.61}, "impact_order": 0, "requests_total": 60, "stability_score": 0}, "\\"http://api-gateway:8080/api/orders/10\\"": {"errors": {"total": 60, "rate_percent": 100, "max_failure_streak": 60}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 14.174833333333334, "max_memory_mb": 25.16, "avg_cpu_percent": 0.6375, "max_cpu_percent": 12.61}, "impact_order": 0, "requests_total": 60, "stability_score": 0}, "\\"http://payment-service:8083/payments/10\\"": {"errors": {"total": 60, "rate_percent": 100, "max_failure_streak": 60}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 14.174833333333334, "max_memory_mb": 25.16, "avg_cpu_percent": 0.6375, "max_cpu_percent": 12.61}, "impact_order": 0, "requests_total": 60, "stability_score": 0}, "\\"http://shipping-service:8085/shipping/10\\"": {"errors": {"total": 60, "rate_percent": 100, "max_failure_streak": 60}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 14.174833333333334, "max_memory_mb": 25.16, "avg_cpu_percent": 0.6375, "max_cpu_percent": 12.61}, "impact_order": 0, "requests_total": 60, "stability_score": 0}, "\\"http://inventory-service:8084/inventory/A1\\"": {"errors": {"total": 60, "rate_percent": 100, "max_failure_streak": 60}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 14.174833333333334, "max_memory_mb": 25.16, "avg_cpu_percent": 0.6375, "max_cpu_percent": 12.61}, "impact_order": 0, "requests_total": 60, "stability_score": 0}, "\\"http://notification-service:8086/notifications/10\\"": {"errors": {"total": 60, "rate_percent": 100, "max_failure_streak": 60}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 14.174833333333334, "max_memory_mb": 25.16, "avg_cpu_percent": 0.6375, "max_cpu_percent": 12.61}, "impact_order": 0, "requests_total": 60, "stability_score": 0}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"errors": {"total": 60, "rate_percent": 100, "max_failure_streak": 60}, "derived": {"error_delta": 0, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 14.174833333333334, "max_memory_mb": 25.16, "avg_cpu_percent": 0.6375, "max_cpu_percent": 12.61}, "impact_order": 0, "requests_total": 60, "stability_score": 0}}, "cascade_depth": 0, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 540, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "isolated", "total_endpoints": 9, "blast_radius_percent": 0, "resilience_threshold": {"intensity_steps": [50, 75, 88, 94, 97, 99, 100], "breaking_intensity": 0, "max_stable_intensity": 100}, "fault_injection_history": [{"intensity": 75, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:08:35.3215032+05:30"}, {"intensity": 88, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:08:45.3225586+05:30"}, {"intensity": 94, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:08:55.3230949+05:30"}, {"intensity": 97, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:09:05.3236544+05:30"}, {"intensity": 99, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:09:15.3247582+05:30"}, {"intensity": 100, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:09:25.3248089+05:30"}, {"intensity": 50, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:08:25.3202555+05:30"}], "fault_injection_history_v2": [{"impacts": {}, "anomalies": null, "intensity": 75, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:08:35.3215032+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 88, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:08:45.3225586+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 94, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:08:55.3230949+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 97, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:09:05.3236544+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 99, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:09:15.3247582+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 100, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:09:25.3248089+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 50, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:08:25.3202555+05:30"}]}	2026-04-13 16:39:40.342983
4ea99c95-1ae4-47db-90dd-715a5f8221c4	completed	completed	0	0	isolated	0	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-13T22:16:03.3377827+05:30", "first_impact": {}}, "endpoints": {"\\"http://user-service:8081/users/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 39.13767857142857, "max_memory_mb": 47.66374999999999, "avg_cpu_percent": 68.67660714285714, "max_cpu_percent": 132.5975}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://api-gateway:8080/api/users/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 39.13767857142857, "max_memory_mb": 47.66374999999999, "avg_cpu_percent": 68.67660714285714, "max_cpu_percent": 132.5975}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://order-service:8082/orders/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 39.13767857142857, "max_memory_mb": 47.66374999999999, "avg_cpu_percent": 68.67660714285714, "max_cpu_percent": 132.5975}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://api-gateway:8080/api/orders/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 39.13767857142857, "max_memory_mb": 47.66374999999999, "avg_cpu_percent": 68.67660714285714, "max_cpu_percent": 132.5975}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://payment-service:8083/payments/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 39.13767857142857, "max_memory_mb": 47.66374999999999, "avg_cpu_percent": 68.67660714285714, "max_cpu_percent": 132.5975}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://shipping-service:8085/shipping/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 39.13767857142857, "max_memory_mb": 47.66374999999999, "avg_cpu_percent": 68.67660714285714, "max_cpu_percent": 132.5975}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://inventory-service:8084/inventory/A1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 39.13767857142857, "max_memory_mb": 47.66374999999999, "avg_cpu_percent": 68.67660714285714, "max_cpu_percent": 132.5975}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://notification-service:8086/notifications/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 39.13767857142857, "max_memory_mb": 47.66374999999999, "avg_cpu_percent": 68.67660714285714, "max_cpu_percent": 132.5975}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 39.13767857142857, "max_memory_mb": 47.66374999999999, "avg_cpu_percent": 68.67660714285714, "max_cpu_percent": 132.5975}, "impact_order": 0, "requests_total": 7, "stability_score": 0}}, "cascade_depth": 0, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 63, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "isolated", "total_endpoints": 9, "blast_radius_percent": 0, "resilience_threshold": {"intensity_steps": [40, 60, 70, 75, 78, 79, 80], "breaking_intensity": 0, "max_stable_intensity": 80}, "fault_injection_history": [{"intensity": 70, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:15:23.3359661+05:30"}, {"intensity": 75, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:15:33.3364961+05:30"}, {"intensity": 78, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-13T22:15:44.9891905+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-13T22:15:44.9891905+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-13T22:15:44.9891905+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-13T22:15:44.9891905+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-13T22:15:44.9891905+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-13T22:15:44.9891905+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-13T22:15:44.9891905+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-13T22:15:44.9891905+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-13T22:15:44.9891905+05:30"}, "fault_started_at": "2026-04-13T22:15:43.3369961+05:30"}, {"intensity": 79, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:15:53.3372709+05:30"}, {"intensity": 80, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:16:03.3377827+05:30"}, {"intensity": 40, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-13T22:15:12.9115691+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-13T22:15:12.9115691+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-13T22:15:12.9115691+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-13T22:15:12.9115691+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-13T22:15:12.9115691+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-13T22:15:12.9115691+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-13T22:15:12.9115691+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-13T22:15:12.9115691+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-13T22:15:12.9115691+05:30"}, "fault_started_at": "2026-04-13T22:15:03.334847+05:30"}, {"intensity": 60, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-13T22:15:13.3353673+05:30"}], "fault_injection_history_v2": [{"impacts": {}, "anomalies": null, "intensity": 70, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:15:23.3359661+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 75, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:15:33.3364961+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:44.9891905+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:44.9891905+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:44.9891905+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:44.9891905+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:44.9891905+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:44.9891905+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:44.9891905+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:44.9891905+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:44.9891905+05:30"}}, "anomalies": null, "intensity": 78, "fault_cause": "cpu_stress", "cascade_path": ["\\"http://payment-service:8083/payments/10\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://api-gateway:8080/api/users/1\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://api-gateway:8080/api/orders/10\\""], "fault_started_at": "2026-04-13T22:15:43.3369961+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 79, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:15:53.3372709+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 80, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:16:03.3377827+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:12.9115691+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:12.9115691+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:12.9115691+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:12.9115691+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:12.9115691+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:12.9115691+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:12.9115691+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:12.9115691+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-13T22:15:12.9115691+05:30"}}, "anomalies": null, "intensity": 40, "fault_cause": "cpu_stress", "cascade_path": ["\\"http://shipping-service:8085/shipping/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://user-service:8081/users/1\\""], "fault_started_at": "2026-04-13T22:15:03.334847+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 60, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-13T22:15:13.3353673+05:30"}]}	2026-04-13 16:46:18.351849
ec680a5c-b06d-417e-b725-0a9545bc9e8a	completed	completed	0	0	isolated	0	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-14T16:32:52.6091234+05:30", "first_impact": {}}, "endpoints": {"\\"http://user-service:8081/users/1\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.4253125, "max_memory_mb": 22.737500000000004, "avg_cpu_percent": 0.18868749999999998, "max_cpu_percent": 1.8749999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://api-gateway:8080/api/users/1\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.4253125, "max_memory_mb": 22.737500000000004, "avg_cpu_percent": 0.18868749999999998, "max_cpu_percent": 1.8749999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://order-service:8082/orders/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.4253125, "max_memory_mb": 22.737500000000004, "avg_cpu_percent": 0.18868749999999998, "max_cpu_percent": 1.8749999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://api-gateway:8080/api/orders/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.4253125, "max_memory_mb": 22.737500000000004, "avg_cpu_percent": 0.18868749999999998, "max_cpu_percent": 1.8749999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://payment-service:8083/payments/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.4253125, "max_memory_mb": 22.737500000000004, "avg_cpu_percent": 0.18868749999999998, "max_cpu_percent": 1.8749999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://shipping-service:8085/shipping/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.4253125, "max_memory_mb": 22.737500000000004, "avg_cpu_percent": 0.18868749999999998, "max_cpu_percent": 1.8749999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://inventory-service:8084/inventory/A1\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.4253125, "max_memory_mb": 22.737500000000004, "avg_cpu_percent": 0.18868749999999998, "max_cpu_percent": 1.8749999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://notification-service:8086/notifications/10\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.4253125, "max_memory_mb": 22.737500000000004, "avg_cpu_percent": 0.18868749999999998, "max_cpu_percent": 1.8749999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"errors": {"total": 20, "rate_percent": 100, "max_failure_streak": 20}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 5.4253125, "max_memory_mb": 22.737500000000004, "avg_cpu_percent": 0.18868749999999998, "max_cpu_percent": 1.8749999999999998}, "impact_order": 0, "requests_total": 20, "stability_score": 0}}, "cascade_depth": 0, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 180, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "isolated", "total_endpoints": 9, "blast_radius_percent": 0, "resilience_threshold": {"intensity_steps": [50, 75, 88, 94, 97, 99, 100], "breaking_intensity": 0, "max_stable_intensity": 100}, "fault_injection_history": [{"intensity": 100, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-14T16:32:52.6091234+05:30"}, {"intensity": 50, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-14T16:32:02.2861952+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-14T16:32:02.2861952+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-14T16:32:02.2861952+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-14T16:32:02.2861952+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-14T16:32:02.2861952+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-14T16:32:02.2861952+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-14T16:32:02.2861952+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-14T16:32:02.2861952+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-14T16:32:02.2861952+05:30"}, "fault_started_at": "2026-04-14T16:31:52.6073537+05:30"}, {"intensity": 75, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-14T16:32:12.5943133+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-14T16:32:12.5943133+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-14T16:32:12.5943133+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-14T16:32:12.5943133+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-14T16:32:12.5943133+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-14T16:32:12.5943133+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-14T16:32:12.5943133+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-14T16:32:12.5943133+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-14T16:32:12.5943133+05:30"}, "fault_started_at": "2026-04-14T16:32:02.6074621+05:30"}, {"intensity": 88, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-14T16:32:12.6077137+05:30"}, {"intensity": 94, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-14T16:32:22.6080824+05:30"}, {"intensity": 97, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-14T16:32:32.6083008+05:30"}, {"intensity": 99, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-14T16:32:42.6088308+05:30"}], "fault_injection_history_v2": [{"impacts": {}, "anomalies": null, "intensity": 100, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-14T16:32:52.6091234+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:02.2861952+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:02.2861952+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:02.2861952+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:02.2861952+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:02.2861952+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:02.2861952+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:02.2861952+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:02.2861952+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:02.2861952+05:30"}}, "anomalies": null, "intensity": 50, "fault_cause": "kill", "cascade_path": ["\\"http://api-gateway:8080/api/users/1\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\""], "fault_started_at": "2026-04-14T16:31:52.6073537+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:12.5943133+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:12.5943133+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:12.5943133+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:12.5943133+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:12.5943133+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:12.5943133+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:12.5943133+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:12.5943133+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T16:32:12.5943133+05:30"}}, "anomalies": null, "intensity": 75, "fault_cause": "kill", "cascade_path": ["\\"http://user-service:8081/users/1\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\""], "fault_started_at": "2026-04-14T16:32:02.6074621+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 88, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-14T16:32:12.6077137+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 94, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-14T16:32:22.6080824+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 97, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-14T16:32:32.6083008+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 99, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-14T16:32:42.6088308+05:30"}]}	2026-04-14 11:03:07.619719
deccd3c1-17c5-4380-a1cb-961e2aef6502	completed	completed	0	0	isolated	0	{"frontend": null, "timeline": {"recovery": {}, "fault_start": "2026-04-14T20:19:47.3050763+05:30", "first_impact": {}}, "endpoints": {"\\"http://user-service:8081/users/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.33642857142857, "max_memory_mb": 22.541249999999998, "avg_cpu_percent": 0.4362499999999999, "max_cpu_percent": 0.69}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://api-gateway:8080/api/users/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.33642857142857, "max_memory_mb": 22.541249999999998, "avg_cpu_percent": 0.4362499999999999, "max_cpu_percent": 0.69}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://order-service:8082/orders/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.33642857142857, "max_memory_mb": 22.541249999999998, "avg_cpu_percent": 0.4362499999999999, "max_cpu_percent": 0.69}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://api-gateway:8080/api/orders/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.33642857142857, "max_memory_mb": 22.541249999999998, "avg_cpu_percent": 0.4362499999999999, "max_cpu_percent": 0.69}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://payment-service:8083/payments/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.33642857142857, "max_memory_mb": 22.541249999999998, "avg_cpu_percent": 0.4362499999999999, "max_cpu_percent": 0.69}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://shipping-service:8085/shipping/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.33642857142857, "max_memory_mb": 22.541249999999998, "avg_cpu_percent": 0.4362499999999999, "max_cpu_percent": 0.69}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://inventory-service:8084/inventory/A1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.33642857142857, "max_memory_mb": 22.541249999999998, "avg_cpu_percent": 0.4362499999999999, "max_cpu_percent": 0.69}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://notification-service:8086/notifications/10\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.33642857142857, "max_memory_mb": 22.541249999999998, "avg_cpu_percent": 0.4362499999999999, "max_cpu_percent": 0.69}, "impact_order": 0, "requests_total": 7, "stability_score": 0}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"errors": {"total": 7, "rate_percent": 100, "max_failure_streak": 7}, "derived": {"error_delta": 100, "latency_ratio": 1}, "latency": {"avg_ms": 0, "p50_ms": 0, "p95_ms": 0, "p99_ms": 0, "jitter_ms": 0, "stddev_ms": 0}, "degraded": true, "container": {"avg_memory_mb": 22.33642857142857, "max_memory_mb": 22.541249999999998, "avg_cpu_percent": 0.4362499999999999, "max_cpu_percent": 0.69}, "impact_order": 0, "requests_total": 7, "stability_score": 0}}, "cascade_depth": 0, "failsafe_index": {"mode": "backend_only", "score": 0, "status": "critical"}, "frontend_score": {"score": 100, "status": "no_data"}, "total_requests": 63, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "system_severity": "isolated", "total_endpoints": 9, "blast_radius_percent": 0, "resilience_threshold": {"intensity_steps": [50, 75, 88, 94, 97, 99, 100], "breaking_intensity": 0, "max_stable_intensity": 100}, "fault_injection_history": [{"intensity": 99, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-14T20:19:37.3045552+05:30"}, {"intensity": 100, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-14T20:19:47.3050763+05:30"}, {"intensity": 50, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-14T20:18:56.936844+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-14T20:18:56.936844+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-14T20:18:56.936844+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-14T20:18:56.936844+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-14T20:18:56.936844+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-14T20:18:56.936844+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-14T20:18:56.936844+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-14T20:18:56.936844+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-14T20:18:56.936844+05:30"}, "fault_started_at": "2026-04-14T20:18:47.2939972+05:30"}, {"intensity": 75, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-14T20:18:57.3032696+05:30"}, {"intensity": 88, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-14T20:19:07.3035402+05:30"}, {"intensity": 94, "recovery_at": {}, "first_impact": {}, "fault_started_at": "2026-04-14T20:19:17.3038087+05:30"}, {"intensity": 97, "recovery_at": {}, "first_impact": {"\\"http://user-service:8081/users/1\\"": "2026-04-14T20:19:29.018277+05:30", "\\"http://api-gateway:8080/api/users/1\\"": "2026-04-14T20:19:29.018277+05:30", "\\"http://order-service:8082/orders/10\\"": "2026-04-14T20:19:29.018277+05:30", "\\"http://api-gateway:8080/api/orders/10\\"": "2026-04-14T20:19:29.018277+05:30", "\\"http://payment-service:8083/payments/10\\"": "2026-04-14T20:19:29.018277+05:30", "\\"http://shipping-service:8085/shipping/10\\"": "2026-04-14T20:19:29.018277+05:30", "\\"http://inventory-service:8084/inventory/A1\\"": "2026-04-14T20:19:29.018277+05:30", "\\"http://notification-service:8086/notifications/10\\"": "2026-04-14T20:19:29.018277+05:30", "\\"http://recommendation-service:8087/recommendations/1\\"": "2026-04-14T20:19:29.018277+05:30"}, "fault_started_at": "2026-04-14T20:19:27.3042384+05:30"}], "fault_injection_history_v2": [{"impacts": {}, "anomalies": null, "intensity": 99, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-14T20:19:37.3045552+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 100, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-14T20:19:47.3050763+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:18:56.936844+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:18:56.936844+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:18:56.936844+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:18:56.936844+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:18:56.936844+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:18:56.936844+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:18:56.936844+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:18:56.936844+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:18:56.936844+05:30"}}, "anomalies": null, "intensity": 50, "fault_cause": "network_delay", "cascade_path": ["\\"http://inventory-service:8084/inventory/A1\\"", "\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://shipping-service:8085/shipping/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://user-service:8081/users/1\\""], "fault_started_at": "2026-04-14T20:18:47.2939972+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 75, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-14T20:18:57.3032696+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 88, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-14T20:19:07.3035402+05:30"}, {"impacts": {}, "anomalies": null, "intensity": 94, "fault_cause": "", "cascade_path": null, "fault_started_at": "2026-04-14T20:19:17.3038087+05:30"}, {"impacts": {"\\"http://user-service:8081/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:19:29.018277+05:30"}, "\\"http://api-gateway:8080/api/users/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:19:29.018277+05:30"}, "\\"http://order-service:8082/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:19:29.018277+05:30"}, "\\"http://api-gateway:8080/api/orders/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:19:29.018277+05:30"}, "\\"http://payment-service:8083/payments/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:19:29.018277+05:30"}, "\\"http://shipping-service:8085/shipping/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:19:29.018277+05:30"}, "\\"http://inventory-service:8084/inventory/A1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:19:29.018277+05:30"}, "\\"http://notification-service:8086/notifications/10\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:19:29.018277+05:30"}, "\\"http://recommendation-service:8087/recommendations/1\\"": {"duration_ms": -1, "recovery_at": "0001-01-01T00:00:00Z", "first_impact": "2026-04-14T20:19:29.018277+05:30"}}, "anomalies": null, "intensity": 97, "fault_cause": "network_delay", "cascade_path": ["\\"http://shipping-service:8085/shipping/10\\"", "\\"http://recommendation-service:8087/recommendations/1\\"", "\\"http://user-service:8081/users/1\\"", "\\"http://payment-service:8083/payments/10\\"", "\\"http://api-gateway:8080/api/users/1\\"", "\\"http://api-gateway:8080/api/orders/10\\"", "\\"http://notification-service:8086/notifications/10\\"", "\\"http://order-service:8082/orders/10\\"", "\\"http://inventory-service:8084/inventory/A1\\""], "fault_started_at": "2026-04-14T20:19:27.3042384+05:30"}]}	2026-04-14 14:50:02.3178
\.


--
-- Data for Name: experiment_summary; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.experiment_summary (experiment_id, blast_radius, cascade_depth, system_severity, total_requests) FROM stdin;
\.


--
-- Data for Name: experiments; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.experiments (id, fault_type, state, phase, created_at, updated_at, max_intensity, breaking_intensity, max_stable_intensity, baseline, dependency_graph, target_endpoint_map, api_key_id) FROM stdin;
cd7e2db1-d34d-450a-9807-ec10df222c9a	network_delay	failed	completed	2026-04-02 05:21:19.357436	2026-04-02 05:21:25.368664	0	0	0	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	\N
e3033efe-0f24-4d71-8f79-12ac4ba1f63e	kill	completed	completed	2026-04-02 10:56:52.325606	2026-04-02 11:33:04.542213	100	0	100	{"P95": 501, "ErrorRate": 100, "AvgLatency": 500.2857142857143}	{"http://user-service:8081/users/1": ["http://recommendation-service:8087/recommendations/1"], "http://api-gateway:8080/api/users/1": ["http://user-service:8081/users/1"], "http://order-service:8082/orders/10": ["http://payment-service:8083/payments/10", "http://inventory-service:8084/inventory/A1", "http://shipping-service:8085/shipping/10"], "http://api-gateway:8080/api/orders/10": ["http://order-service:8082/orders/10"], "http://payment-service:8083/payments/10": [], "http://shipping-service:8085/shipping/10": ["http://notification-service:8086/notifications/10"], "http://inventory-service:8084/inventory/A1": [], "http://notification-service:8086/notifications/10": [], "http://recommendation-service:8087/recommendations/1": ["http://inventory-service:8084/inventory/A1"]}	{"api-gateway": ["http://api-gateway:8080/api/users/1", "http://api-gateway:8080/api/orders/10"], "user-service": ["http://user-service:8081/users/1"], "order-service": ["http://order-service:8082/orders/10"], "payment-service": ["http://payment-service:8083/payments/10"], "shipping-service": ["http://shipping-service:8085/shipping/10"], "inventory-service": ["http://inventory-service:8084/inventory/A1"], "notification-service": ["http://notification-service:8086/notifications/10"], "recommendation-service": ["http://recommendation-service:8087/recommendations/1"]}	\N
9844a336-312d-43ce-a77a-061ff675df6b	kill	completed	completed	2026-04-02 10:56:52.324938	2026-04-02 11:33:04.542213	100	0	100	{"P95": 501, "ErrorRate": 100, "AvgLatency": 500.2857142857143}	{"http://user-service:8081/users/1": ["http://recommendation-service:8087/recommendations/1"], "http://api-gateway:8080/api/users/1": ["http://user-service:8081/users/1"], "http://order-service:8082/orders/10": ["http://payment-service:8083/payments/10", "http://inventory-service:8084/inventory/A1", "http://shipping-service:8085/shipping/10"], "http://api-gateway:8080/api/orders/10": ["http://order-service:8082/orders/10"], "http://payment-service:8083/payments/10": [], "http://shipping-service:8085/shipping/10": ["http://notification-service:8086/notifications/10"], "http://inventory-service:8084/inventory/A1": [], "http://notification-service:8086/notifications/10": [], "http://recommendation-service:8087/recommendations/1": ["http://inventory-service:8084/inventory/A1"]}	{"api-gateway": ["http://api-gateway:8080/api/users/1", "http://api-gateway:8080/api/orders/10"], "user-service": ["http://user-service:8081/users/1"], "order-service": ["http://order-service:8082/orders/10"], "payment-service": ["http://payment-service:8083/payments/10"], "shipping-service": ["http://shipping-service:8085/shipping/10"], "inventory-service": ["http://inventory-service:8084/inventory/A1"], "notification-service": ["http://notification-service:8086/notifications/10"], "recommendation-service": ["http://recommendation-service:8087/recommendations/1"]}	\N
e4863f11-8827-47b1-a421-17f11393a25d	network_delay	completed	completed	2026-04-02 05:23:21.295053	2026-04-02 05:23:50.372214	0	0	0	{"P95": 9, "ErrorRate": 33.33333333333333, "AvgLatency": 9.333333333333334}	\N	\N	\N
b6d7e13e-a6e0-4962-a621-5ab3a9870614	network_delay	completed	completed	2026-04-02 05:23:39.9546	2026-04-02 05:24:09.024514	0	0	0	{"P95": 8, "ErrorRate": 30, "AvgLatency": 3.15}	\N	\N	\N
6d2a49a5-05b8-43a1-a911-7e2f43595285	kill_app	completed	completed	2026-04-02 11:45:11.313185	2026-04-02 11:46:03.311211	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
3690a400-497b-4ff0-b610-d99446f687ea	network_delay	failed	completed	2026-04-02 05:24:20.41608	2026-04-02 05:24:26.4187	0	0	0	{"P95": 12, "ErrorRate": 28.57142857142857, "AvgLatency": 4.095238095238095}	\N	\N	\N
d3d661fa-6b7d-4545-9a34-03216065cac5	network_delay	completed	completed	2026-04-02 05:23:59.977126	2026-04-02 05:24:29.000945	0	0	0	{"P95": 14, "ErrorRate": 27.27272727272727, "AvgLatency": 5.681818181818182}	\N	\N	\N
8588d07f-20b7-41a0-a665-7e23280a3b70	kill_app	completed	completed	2026-04-02 11:45:13.084176	2026-04-02 11:46:04.661826	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
76db46e4-fcc7-4673-9478-1b1fe6ef564e	kill_app	completed	completed	2026-04-02 14:03:43.443747	2026-04-02 14:04:16.847282	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
d3ea29aa-9624-48a1-a23a-56ef1bdece10	kill_app	completed	completed	2026-04-02 11:57:25.882505	2026-04-02 11:58:17.499341	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
5ff7f176-044e-4c56-9b5e-1167c29960b7	kill_app	completed	completed	2026-04-02 12:43:26.763552	2026-04-02 12:44:18.716761	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
1db2288b-9922-4f25-9efa-f8558df70288	network_delay	completed	completed	2026-04-05 01:21:01.918117	2026-04-05 01:21:12.938667	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	8834a23a-c785-4b6e-92a5-67bf33677d8b
11b6a21e-0cc9-4cb5-9851-1045be41967e	kill_app	completed	completed	2026-04-02 12:55:41.015688	2026-04-02 12:56:32.988375	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
187f0f05-ede8-4ee7-bad2-2c74f000454d	kill_app	completed	completed	2026-04-02 14:04:29.636372	2026-04-02 14:05:03.046325	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
aa44532c-f2fe-4a82-b979-a32d0b6c9b57	kill_app	completed	completed	2026-04-02 12:57:28.585343	2026-04-02 12:58:20.211616	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
6ee39151-d68f-4696-a44f-1c4b77ed7702	kill_app	completed	completed	2026-04-02 13:02:42.52023	2026-04-02 13:03:34.733548	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
b0a86dd0-7712-4761-96a0-0b05b5fec1e8	kill_app	completed	completed	2026-04-02 13:22:31.242271	2026-04-02 13:23:23.481515	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
01bcff04-4d56-4a10-af21-a73da9ba3c05	kill_app	completed	completed	2026-04-02 14:05:36.778644	2026-04-02 14:06:10.133969	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
1d04ef77-8623-49d0-a808-957f1b55d29b	kill_app	completed	completed	2026-04-02 13:35:11.047011	2026-04-02 13:36:03.12163	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
83c88b42-1da4-4377-860c-b19318fadfbb	kill_app	completed	completed	2026-04-02 13:43:00.003518	2026-04-02 13:43:28.033025	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
9939ad8f-d9d3-4919-8551-6d740f32b3b0	kill_app	completed	completed	2026-04-02 13:52:55.278521	2026-04-02 13:53:27.847114	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
ca6f73c0-961e-4d80-aa17-6dff1d0917aa	kill_app	completed	completed	2026-04-02 14:06:51.49362	2026-04-02 14:07:23.196618	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
59c69cb1-734e-4fdd-8423-d4ead134e60d	kill_app	completed	completed	2026-04-02 13:59:50.223589	2026-04-02 14:00:23.685583	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
41431500-90b1-4726-9dd2-204adba26e21	kill_app	completed	completed	2026-04-02 14:01:51.513542	2026-04-02 14:02:24.998849	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
e6118e4c-ed74-436e-b79a-47fcef930087	latency	failed	completed	2026-04-04 23:47:36.633369	2026-04-04 23:59:05.42232	0	0	0	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	668557b2-65b0-44b5-88e5-77302a3ee848
a92c1648-d98d-49ef-adb1-0a1d14940945	kill_app	completed	completed	2026-04-02 14:02:59.080202	2026-04-02 14:03:32.467122	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	\N
f1a53060-f7f1-40f1-8078-c540eae49879	kill_app	completed	completed	2026-04-06 14:47:45.918917	2026-04-06 14:48:18.892133	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	19d0c37e-a6e3-4bd7-9311-6aa6477a26d8
1fe154e4-a5ef-4cb1-8b63-73fb815bd835	network_delay	failed	completed	2026-04-05 00:04:25.246615	2026-04-05 00:11:23.268916	0	0	0	{"P95": 500, "ErrorRate": 100, "AvgLatency": 500}	\N	\N	553cc189-f5b1-49b3-ac8f-c492c1e2bb5d
89bbde53-24f1-4d15-854a-7d3031a45875	network_delay	completed	completed	2026-04-06 14:58:14.515761	2026-04-06 14:58:25.548682	0	0	0	{"P95": 500, "ErrorRate": 100, "AvgLatency": 500}	\N	\N	19d0c37e-a6e3-4bd7-9311-6aa6477a26d8
503df375-a008-4806-ad52-52fb392d0f01	kill_app	failed	completed	2026-04-05 00:15:08.151312	2026-04-05 00:18:23.059384	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	553cc189-f5b1-49b3-ac8f-c492c1e2bb5d
1f1a4471-c672-4982-ba8d-e8a8ed79817e	kill_app	completed	completed	2026-04-05 01:18:07.078143	2026-04-05 01:18:39.438243	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	8834a23a-c785-4b6e-92a5-67bf33677d8b
aebb6dbb-b2c8-465e-89e9-2891f3ea8e7d	network_delay	completed	completed	2026-04-06 16:03:13.872283	2026-04-06 16:03:54.975089	100	0	0	{"P95": 501, "ErrorRate": 100, "AvgLatency": 500.125}	{"api-gateway": ["user-service", "order-service"], "user-service": ["recommendation-service"], "order-service": ["payment-service", "inventory-service", "shipping-service"], "payment-service": [], "shipping-service": ["notification-service"], "inventory-service": [], "notification-service": [], "recommendation-service": []}	{"api-gateway": ["http://api-gateway:8080/api/users/1", "http://api-gateway:8080/api/orders/10"], "user-service": ["http://user-service:8081/users/1"], "order-service": ["http://order-service:8082/orders/10"], "payment-service": ["http://payment-service:8083/payments/10"], "shipping-service": ["http://shipping-service:8085/shipping/10"], "inventory-service": ["http://inventory-service:8084/inventory/A1"], "notification-service": ["http://notification-service:8086/notifications/10"], "recommendation-service": ["http://recommendation-service:8087/recommendations/1"]}	19d0c37e-a6e3-4bd7-9311-6aa6477a26d8
a98a50a9-f656-4e82-970c-0b0b2165b36e	network_delay	completed	completed	2026-04-06 16:15:04.826951	2026-04-06 16:15:45.887995	100	0	0	{"P95": 500, "ErrorRate": 100, "AvgLatency": 500}	{"api-gateway": ["user-service", "order-service"], "user-service": ["recommendation-service"], "order-service": ["payment-service", "inventory-service", "shipping-service"], "payment-service": [], "shipping-service": ["notification-service"], "inventory-service": [], "notification-service": [], "recommendation-service": []}	{"api-gateway": ["http://api-gateway:8080/api/users/1", "http://api-gateway:8080/api/orders/10"], "user-service": ["http://user-service:8081/users/1"], "order-service": ["http://order-service:8082/orders/10"], "payment-service": ["http://payment-service:8083/payments/10"], "shipping-service": ["http://shipping-service:8085/shipping/10"], "inventory-service": ["http://inventory-service:8084/inventory/A1"], "notification-service": ["http://notification-service:8086/notifications/10"], "recommendation-service": ["http://recommendation-service:8087/recommendations/1"]}	19d0c37e-a6e3-4bd7-9311-6aa6477a26d8
6e6f82e4-fcf0-4922-a0cf-933c6f1bdceb	network_delay	completed	completed	2026-04-06 19:44:16.616065	2026-04-06 19:44:57.687725	100	0	0	{"P95": 501, "ErrorRate": 100, "AvgLatency": 500.125}	{"api-gateway": ["user-service", "order-service"], "user-service": ["recommendation-service"], "order-service": ["payment-service", "inventory-service", "shipping-service"], "payment-service": [], "shipping-service": ["notification-service"], "inventory-service": [], "notification-service": [], "recommendation-service": []}	{"api-gateway": ["http://api-gateway:8080/api/users/1", "http://api-gateway:8080/api/orders/10"], "user-service": ["http://user-service:8081/users/1"], "order-service": ["http://order-service:8082/orders/10"], "payment-service": ["http://payment-service:8083/payments/10"], "shipping-service": ["http://shipping-service:8085/shipping/10"], "inventory-service": ["http://inventory-service:8084/inventory/A1"], "notification-service": ["http://notification-service:8086/notifications/10"], "recommendation-service": ["http://recommendation-service:8087/recommendations/1"]}	19d0c37e-a6e3-4bd7-9311-6aa6477a26d8
50be69bb-0d99-4875-b756-eb541d3156cd	network_delay	completed	completed	2026-04-08 20:50:31.483313	2026-04-08 20:51:52.597247	70	0	70	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	b059fbe6-e785-4aea-adc2-b01a1ecc8f82
14a3dd03-24ad-42f0-8af9-2c94a52063aa	network_delay	completed	completed	2026-04-13 22:22:28.225743	2026-04-13 22:22:39.317425	0	0	0	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	453e0b48-12f4-47eb-9848-3fbabc828838
fcf3959e-9c5e-4e24-9ce0-7a83f256ea36	kill	completed	completed	2026-04-08 22:42:12.764035	2026-04-08 22:43:33.784611	80	0	80	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	b059fbe6-e785-4aea-adc2-b01a1ecc8f82
8ccb8c63-1dfb-4513-857a-62886761cec2	kill	completed	completed	2026-04-08 22:50:13.657915	2026-04-08 22:51:34.67459	100	0	100	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	b059fbe6-e785-4aea-adc2-b01a1ecc8f82
dac38b3c-afaf-4ac9-a68c-8f2b5e19d5cd	network	completed	completed	2026-04-14 09:41:48.432853	2026-04-14 09:41:59.484868	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	592fe716-0223-4f13-90f3-904ffb989cc2
d8d3507a-5fdc-4e5b-9b33-9d484c9c09e4	kill	completed	completed	2026-04-08 23:05:42.78195	2026-04-08 23:07:03.807417	100	0	100	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	b059fbe6-e785-4aea-adc2-b01a1ecc8f82
0c9159af-dbe7-4559-8610-0984750f18b8	network_delay	completed	completed	2026-04-13 22:23:25.529495	2026-04-13 22:23:36.547961	0	0	0	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	29568107-1e9b-48ef-8aa6-67a4967cd7b1
f3f5f610-171b-4c65-84e1-2d66e7226aed	network_delay	completed	completed	2026-04-13 21:52:28.927318	2026-04-13 21:53:49.967795	100	0	100	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	592fe716-0223-4f13-90f3-904ffb989cc2
3bcbdd76-ebeb-498d-be72-d9a0d6dbf355	network_delay	completed	completed	2026-04-13 22:02:58.414986	2026-04-13 22:04:19.434567	100	0	100	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	592fe716-0223-4f13-90f3-904ffb989cc2
ce28f73b-57fc-45cf-9f60-36bfed57da8c	kill	completed	completed	2026-04-13 22:08:19.303385	2026-04-13 22:09:40.340084	100	0	100	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	592fe716-0223-4f13-90f3-904ffb989cc2
7a2483a8-2988-4a21-b0f8-73c9e8533825	network_delay	completed	completed	2026-04-13 22:24:24.817372	2026-04-13 22:24:35.864491	0	0	0	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	107c7711-8404-4be1-a6a5-0710e11f5b00
4ea99c95-1ae4-47db-90dd-715a5f8221c4	cpu_stress	completed	completed	2026-04-13 22:14:57.313009	2026-04-13 22:16:18.339788	80	0	80	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	592fe716-0223-4f13-90f3-904ffb989cc2
dacebb05-5455-4e5a-ad98-c9d9217470a2	latency	completed	completed	2026-04-14 08:50:37.023886	2026-04-14 08:50:48.42386	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	592fe716-0223-4f13-90f3-904ffb989cc2
ecdf9170-7b71-493b-9644-39391b84cc3b	latency	completed	completed	2026-04-14 09:42:48.018461	2026-04-14 09:42:59.043523	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	592fe716-0223-4f13-90f3-904ffb989cc2
3f5ef8a2-b8c9-4faf-b26c-8cb498a82e4c	network_delay	completed	completed	2026-04-14 09:07:32.719761	2026-04-14 09:07:43.736481	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	592fe716-0223-4f13-90f3-904ffb989cc2
9391f66d-c2cf-442b-ba64-8e043fb22fa3	latency	completed	completed	2026-04-14 09:15:09.943808	2026-04-14 09:15:20.972361	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	66a4c29f-0007-4911-8275-a17be2ad76ef
ec680a5c-b06d-417e-b725-0a9545bc9e8a	kill	completed	completed	2026-04-14 16:31:46.585939	2026-04-14 16:33:07.610081	100	0	100	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	592fe716-0223-4f13-90f3-904ffb989cc2
7e39ec66-a1a0-43a1-bb27-64c99d1de31d	latency	completed	completed	2026-04-14 09:38:54.849062	2026-04-14 09:39:05.863295	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	5e557c81-5969-41ce-ad3a-bcaef736b999
2a78671b-30e9-4353-916c-546f92a2236f	network_disable	completed	completed	2026-04-14 10:42:44.921327	2026-04-14 10:43:43.009175	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	592fe716-0223-4f13-90f3-904ffb989cc2
deccd3c1-17c5-4380-a1cb-961e2aef6502	network_delay	completed	completed	2026-04-14 20:18:41.267578	2026-04-14 20:20:02.30666	100	0	100	{"P95": 0, "ErrorRate": 0, "AvgLatency": 0}	\N	\N	3a68e3f5-a4cc-4c35-a98f-73e36da0f31a
638f7e61-9cb6-4756-8bb4-57812cb1dfd7	latency	failed	completed	2026-04-14 12:12:49.465345	2026-04-14 21:18:59.849467	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	592fe716-0223-4f13-90f3-904ffb989cc2
82236e9d-a2e1-4f14-96b2-299903b79d97	network_disable	failed	completed	2026-04-14 10:14:27.73328	2026-04-14 21:29:48.501769	0	0	0	{"P95": 0, "ErrorRate": 100, "AvgLatency": 0}	\N	\N	592fe716-0223-4f13-90f3-904ffb989cc2
\.


--
-- Data for Name: frontend_experiments; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.frontend_experiments (experiment_id, fault_type, state, phase, base_url, metrics_endpoint, target_urls, targets, created_at, updated_at) FROM stdin;
e6118e4c-ed74-436e-b79a-47fcef930087	latency	failed	completed	http://127.0.0.1:3001	http://localhost:8000/frontend/metrics	["/api/fast", "/api/slow"]	null	2026-04-04 23:47:36.633369	2026-04-04 23:59:05.42232
1db2288b-9922-4f25-9efa-f8558df70288	network_delay	running	baseline	https://dhruvjain.xyz/	http://localhost:8000/frontend/metrics	["dhruvjain.xyz"]	["dhruvjain-portfolio"]	2026-04-05 01:21:01.918117	2026-04-05 01:21:01.918117
dacebb05-5455-4e5a-ad98-c9d9217470a2	latency	running	baseline	https://example.com	http://localhost:8000/frontend/metrics	["/"]	["example-frontend"]	2026-04-14 08:50:37.023886	2026-04-14 08:50:37.023886
3f5ef8a2-b8c9-4faf-b26c-8cb498a82e4c	network_delay	running	baseline	http://dhruvjain.xyz		null	null	2026-04-14 09:07:32.719761	2026-04-14 09:07:32.719761
9391f66d-c2cf-442b-ba64-8e043fb22fa3	latency	running	baseline	http://127.0.0.1:3001	http://localhost:8000/frontend/metrics	["/api/fast", "/api/slow"]	null	2026-04-14 09:15:09.943808	2026-04-14 09:15:09.943808
7e39ec66-a1a0-43a1-bb27-64c99d1de31d	latency	running	baseline	https://vcet.edu.in	http://localhost:8000/frontend/metrics	["/"]	null	2026-04-14 09:38:54.849062	2026-04-14 09:38:54.849062
dac38b3c-afaf-4ac9-a68c-8f2b5e19d5cd	network	running	baseline	https://vcet.edu.in	http://localhost:8000/frontend/metrics	["/", "/computer-engineering"]	["/", "/computer-engineering"]	2026-04-14 09:41:48.432853	2026-04-14 09:41:48.432853
ecdf9170-7b71-493b-9644-39391b84cc3b	latency	running	baseline	https://vcet.edu.in/	http://localhost:8000/frontend/metrics	["/computer-engineering"]	["/computer-engineering"]	2026-04-14 09:42:48.018461	2026-04-14 09:42:48.018461
\.


--
-- Data for Name: frontend_metrics_raw; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.frontend_metrics_raw (id, experiment_id, phase, page, lcp, cls, inp, long_tasks, errors, unhandled_rejections, api_calls, event_timestamp, created_at) FROM stdin;
1	e6118e4c-ed74-436e-b79a-47fcef930087	baseline	/	1234	0.03	88	1	0	0	[{"url": "/api/fast", "status": 200, "duration": 120}]	1775326656658	2026-04-04 18:17:36.66355
2	9391f66d-c2cf-442b-ba64-8e043fb22fa3	baseline	/	2132	0	0	0	0	0	[]	1776138317777	2026-04-14 03:45:22.77119
3	9391f66d-c2cf-442b-ba64-8e043fb22fa3	baseline	/	2132	0	0	0	0	0	[]	1776138322764	2026-04-14 03:45:27.778694
4	9391f66d-c2cf-442b-ba64-8e043fb22fa3	baseline	/	2132	0	0	0	0	0	[]	1776138327774	2026-04-14 03:45:32.780817
5	9391f66d-c2cf-442b-ba64-8e043fb22fa3	baseline	/	2132	0	0	0	0	0	[]	1776138332776	2026-04-14 03:45:37.776018
6	9391f66d-c2cf-442b-ba64-8e043fb22fa3	baseline	/	2132	0	0	0	0	0	[]	1776138337772	2026-04-14 03:45:42.77935
7	9391f66d-c2cf-442b-ba64-8e043fb22fa3	baseline	/	2132	0	0	0	0	0	[]	1776138342776	2026-04-14 03:45:47.773447
8	9391f66d-c2cf-442b-ba64-8e043fb22fa3	baseline	/	2132	0	0	0	0	0	[]	1776138347770	2026-04-14 03:45:52.766345
9	9391f66d-c2cf-442b-ba64-8e043fb22fa3	baseline	/	2132	0	0	0	0	0	[]	1776138352762	2026-04-14 03:45:57.767181
10	9391f66d-c2cf-442b-ba64-8e043fb22fa3	baseline	/	2132	0	0	0	0	0	[]	1776138357762	2026-04-14 03:46:02.772791
11	9391f66d-c2cf-442b-ba64-8e043fb22fa3	baseline	/	2132	0	0	0	0	0	[]	1776138362768	2026-04-14 03:46:07.766141
12	7e39ec66-a1a0-43a1-bb27-64c99d1de31d	baseline	/	0	0	0	0	0	0	[]	1776139738809	2026-04-14 04:09:02.292306
13	dac38b3c-afaf-4ac9-a68c-8f2b5e19d5cd	baseline	/	0	0	0	0	0	0	[]	1776139911343	2026-04-14 04:11:55.112969
14	ecdf9170-7b71-493b-9644-39391b84cc3b	baseline	/	0	0	0	0	0	0	[]	1776139971104	2026-04-14 04:12:54.711257
\.


--
-- Data for Name: frontend_status_metrics; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.frontend_status_metrics (experiment_id, state, phase, frontend_score, frontend_status, failsafe_score, status_payload, updated_at) FROM stdin;
e6118e4c-ed74-436e-b79a-47fcef930087	failed	completed	80.58	stable	80.58	{"phase": "completed", "state": "failed", "frontend": [{"page": "/", "phase": "baseline", "metrics": {"cls": 0.03, "inp": 88, "lcp": 1234, "errors": 0, "long_tasks": 1, "unhandled_rejections": 0}, "api_calls": [{"url": "/api/fast", "status": 200, "duration": 120}], "timestamp": 1775326656658, "experiment_id": "e6118e4c-ed74-436e-b79a-47fcef930087"}], "failsafe_index": {"mode": "frontend_only", "score": 80.58, "status": "stable"}, "frontend_score": {"score": 80.58, "status": "stable", "breakdown": {"cls": 0.03, "inp": 88, "lcp": 1234}}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-04 18:29:05.472657
1db2288b-9922-4f25-9efa-f8558df70288	completed	completed	100	no_data	100	{"frontend": null, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-04 19:51:12.95051
dacebb05-5455-4e5a-ad98-c9d9217470a2	completed	completed	100	no_data	100	{"frontend": null, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-14 03:20:48.436511
3f5ef8a2-b8c9-4faf-b26c-8cb498a82e4c	completed	completed	100	no_data	100	{"frontend": null, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-14 03:37:43.744146
9391f66d-c2cf-442b-ba64-8e043fb22fa3	completed	completed	100	no_data	100	{"frontend": null, "failsafe_index": {"mode": "no_data", "score": 100, "status": "unknown"}, "frontend_score": {"score": 100, "status": "no_data"}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-14 03:45:20.980405
7e39ec66-a1a0-43a1-bb27-64c99d1de31d	completed	completed	100	stable	100	{"frontend": [{"page": "/", "phase": "baseline", "metrics": {"cls": 0, "inp": 0, "lcp": 0, "errors": 0, "long_tasks": 0, "unhandled_rejections": 0}, "api_calls": [], "timestamp": 1776139738809, "experiment_id": "7e39ec66-a1a0-43a1-bb27-64c99d1de31d"}], "failsafe_index": {"mode": "frontend_only", "score": 100, "status": "stable"}, "frontend_score": {"score": 100, "status": "stable", "breakdown": {"cls": 0, "inp": 0, "lcp": 0}}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-14 04:09:05.868254
ecdf9170-7b71-493b-9644-39391b84cc3b	completed	completed	100	stable	100	{"frontend": [{"page": "/", "phase": "baseline", "metrics": {"cls": 0, "inp": 0, "lcp": 0, "errors": 0, "long_tasks": 0, "unhandled_rejections": 0}, "api_calls": [], "timestamp": 1776139971104, "experiment_id": "ecdf9170-7b71-493b-9644-39391b84cc3b"}], "failsafe_index": {"mode": "frontend_only", "score": 100, "status": "stable"}, "frontend_score": {"score": 100, "status": "stable", "breakdown": {"cls": 0, "inp": 0, "lcp": 0}}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-14 04:12:59.088785
dac38b3c-afaf-4ac9-a68c-8f2b5e19d5cd	completed	completed	100	stable	100	{"frontend": [{"page": "/", "phase": "baseline", "metrics": {"cls": 0, "inp": 0, "lcp": 0, "errors": 0, "long_tasks": 0, "unhandled_rejections": 0}, "api_calls": [], "timestamp": 1776139911343, "experiment_id": "dac38b3c-afaf-4ac9-a68c-8f2b5e19d5cd"}], "failsafe_index": {"mode": "frontend_only", "score": 100, "status": "stable"}, "frontend_score": {"score": 100, "status": "stable", "breakdown": {"cls": 0, "inp": 0, "lcp": 0}}, "aggregate_stats": {"total_failures": 0, "mean_recovery_ms": 0, "anomaly_endpoints": null, "total_downtime_ms": null, "median_recovery_ms": 0}, "fault_injection_history": null, "fault_injection_history_v2": null}	2026-04-14 04:11:59.497378
\.


--
-- Data for Name: metrics_aggregated; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.metrics_aggregated (id, experiment_id, endpoint, requests_total, p50_ms, p95_ms, p99_ms, avg_ms, stddev_ms, jitter_ms, error_rate, max_failure_streak, latency_ratio, error_delta, stability_score, impact_order, degraded, avg_cpu, max_cpu, avg_memory, max_memory) FROM stdin;
\.


--
-- Data for Name: metrics_raw; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.metrics_raw (id, experiment_id, endpoint, "timestamp", latency_ms, status, intensity, container_cpu, container_memory) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: failsafe
--

COPY public.users (id, email, name, password_hash, role, created_at) FROM stdin;
ee400ecd-cd98-43b7-b83d-6f6704719a03	alice@example.com	Alice	$2a$10$jP8oytVANmYmwoHf/EF1A.KQx1WgOpG7psBxVdN12jaQvBvfvi3xq	engineer	2026-04-14 17:57:26.001492
4a22ba21-25e8-418e-9e97-88e0a251647f	jaindhruv25006@gmail.com	Dhruv Jain	$2a$10$g5UjoRNuuy/z2R40fEXGKu/zL5FU1GbVmXdF6P0RFnleZnqVZpiGW	engineer	2026-04-14 17:57:31.320824
\.


--
-- Name: android_metrics_raw_id_seq; Type: SEQUENCE SET; Schema: public; Owner: failsafe
--

SELECT pg_catalog.setval('public.android_metrics_raw_id_seq', 119, true);


--
-- Name: backend_metrics_raw_id_seq; Type: SEQUENCE SET; Schema: public; Owner: failsafe
--

SELECT pg_catalog.setval('public.backend_metrics_raw_id_seq', 2086, true);


--
-- Name: frontend_metrics_raw_id_seq; Type: SEQUENCE SET; Schema: public; Owner: failsafe
--

SELECT pg_catalog.setval('public.frontend_metrics_raw_id_seq', 14, true);


--
-- Name: metrics_aggregated_id_seq; Type: SEQUENCE SET; Schema: public; Owner: failsafe
--

SELECT pg_catalog.setval('public.metrics_aggregated_id_seq', 1, false);


--
-- Name: metrics_raw_id_seq; Type: SEQUENCE SET; Schema: public; Owner: failsafe
--

SELECT pg_catalog.setval('public.metrics_raw_id_seq', 1, false);


--
-- Name: android_experiment_report android_experiment_report_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.android_experiment_report
    ADD CONSTRAINT android_experiment_report_pkey PRIMARY KEY (experiment_id);


--
-- Name: android_experiment_summary android_experiment_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.android_experiment_summary
    ADD CONSTRAINT android_experiment_summary_pkey PRIMARY KEY (experiment_id);


--
-- Name: android_experiments android_experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.android_experiments
    ADD CONSTRAINT android_experiments_pkey PRIMARY KEY (experiment_id);


--
-- Name: android_metrics_raw android_metrics_raw_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.android_metrics_raw
    ADD CONSTRAINT android_metrics_raw_pkey PRIMARY KEY (id);


--
-- Name: android_status_metrics android_status_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.android_status_metrics
    ADD CONSTRAINT android_status_metrics_pkey PRIMARY KEY (experiment_id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: backend_experiments backend_experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.backend_experiments
    ADD CONSTRAINT backend_experiments_pkey PRIMARY KEY (experiment_id);


--
-- Name: backend_metrics_raw backend_metrics_raw_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.backend_metrics_raw
    ADD CONSTRAINT backend_metrics_raw_pkey PRIMARY KEY (id);


--
-- Name: backend_status_metrics backend_status_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.backend_status_metrics
    ADD CONSTRAINT backend_status_metrics_pkey PRIMARY KEY (experiment_id);


--
-- Name: experiment_summary experiment_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.experiment_summary
    ADD CONSTRAINT experiment_summary_pkey PRIMARY KEY (experiment_id);


--
-- Name: experiments experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.experiments
    ADD CONSTRAINT experiments_pkey PRIMARY KEY (id);


--
-- Name: frontend_experiments frontend_experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.frontend_experiments
    ADD CONSTRAINT frontend_experiments_pkey PRIMARY KEY (experiment_id);


--
-- Name: frontend_metrics_raw frontend_metrics_raw_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.frontend_metrics_raw
    ADD CONSTRAINT frontend_metrics_raw_pkey PRIMARY KEY (id);


--
-- Name: frontend_status_metrics frontend_status_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.frontend_status_metrics
    ADD CONSTRAINT frontend_status_metrics_pkey PRIMARY KEY (experiment_id);


--
-- Name: metrics_aggregated metrics_aggregated_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.metrics_aggregated
    ADD CONSTRAINT metrics_aggregated_pkey PRIMARY KEY (id);


--
-- Name: metrics_raw metrics_raw_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.metrics_raw
    ADD CONSTRAINT metrics_raw_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: failsafe
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict qBAC38PmS4AVdvOIF99gYgAsL6y9X6WVVk39HxZQJmcdbMKIQVv9m8OUqjHo7gN

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict bgSQSPByu5Mf4wCGWVq2mW7Wf13sOIxRlzdYxHfFodj3D6J98IQKrhGH2zO0f4b

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict bgSQSPByu5Mf4wCGWVq2mW7Wf13sOIxRlzdYxHfFodj3D6J98IQKrhGH2zO0f4b

--
-- PostgreSQL database cluster dump complete
--

